CREATE package AAA2
  is
  type   mycur   is   ref   cursor   ;
  function   BBB(b   varchar2)  return mycur  ;
  end   ;


/
