CREATE package CO_BASIC_PKG as
   function SF_ALLOWBROW (READERS in varchar2,AUTHOR in number,USID in varchar2,ADMINVALUE in varchar) return number;
end CO_BASIC_PKG;


/
