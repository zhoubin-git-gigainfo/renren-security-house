CREATE TRIGGER TRG_APPMYCALEND
BEFORE INSERT
  ON APPMYCALEND
FOR EACH ROW
  declare
  -- local variables here
begin
  Delete appmycalend Where fromapp=:new.fromapp and author=:new.author and :new.FromApp!=0;
end trg_;
/
