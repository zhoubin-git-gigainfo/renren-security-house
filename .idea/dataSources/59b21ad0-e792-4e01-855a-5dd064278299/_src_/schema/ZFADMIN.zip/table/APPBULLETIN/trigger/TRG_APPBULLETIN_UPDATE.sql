CREATE TRIGGER TRG_APPBULLETIN_UPDATE
AFTER UPDATE
  ON APPBULLETIN
FOR EACH ROW
  declare
  num_apply  float;
  num_check  float;
  num_bx     float;
  num_syze   float;
  num_dbsye  float;
  num_detail_id number;
  num_sseq number;
  nextid number;
  res integer;
  num_dept number;
begin
If (:new.type=2000015) then
    --如果从草稿变成发布状态；在办业务数减1，发布数加1
    If ((:new.appstate=0) and (:new.appcatlog<>0) and (:old.appcatlog is null)) then
       select count(*) into res from appworkflow where hasapp>0 and appseq=:new.appseq;
       select appcredeptid  into num_dept from ta_bscommon where appseq=:new.appseq;
       --select appyear,appitemid,appdeptid from appsub_plan t
       if (res>0) then 
         update appsub_plan set appworking=appworking+1 where appyear=to_char(sysdate,'yyyy') and appitemid=:new.appcatlog and appdeptid=num_dept;
       end if;
 End If;
    If ((:new.appstate=1) and (:old.appstate=0)) then
       select appcredeptid  into num_dept from ta_bscommon where appseq=:new.appseq;
       --select appyear,appitemid,appdeptid from appsub_plan t
       update appsub_plan set appworking=appworking-1,appyfcount=appyfcount+1 where appyear=to_char(sysdate,'yyyy') and appitemid=:new.appcatlog and appdeptid=num_dept;
    End If;
    --从草稿变成失效；在办业务数减1；
    If ((:new.appstate=2) and (:old.appstate=0)) then
       select appcredeptid  into num_dept from ta_bscommon where appseq=:new.appseq;
       --select appyear,appitemid,appdeptid from appsub_plan t
       update appsub_plan set appworking=appworking-1 where appyear=to_char(sysdate,'yyyy') and appitemid=:new.appcatlog and appdeptid=num_dept;
    End If;
end if;
 End trg_appbulletin_Update;
/
