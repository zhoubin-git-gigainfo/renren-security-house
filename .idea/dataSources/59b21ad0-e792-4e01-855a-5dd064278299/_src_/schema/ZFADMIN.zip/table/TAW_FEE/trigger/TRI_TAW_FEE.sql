CREATE TRIGGER TRI_TAW_FEE
BEFORE INSERT
  ON TAW_FEE
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.fseq IS NULL or :new.fseq=0 THEN
    select seq_appseq_ids.nextval
    into nextid
    from sys.dual;
    :new.fseq:=nextid;
  end if;
end tri_taw_fee;
/
