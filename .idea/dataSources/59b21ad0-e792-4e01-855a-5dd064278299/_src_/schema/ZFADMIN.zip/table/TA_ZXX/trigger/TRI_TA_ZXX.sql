CREATE TRIGGER TRI_TA_ZXX
BEFORE INSERT
  ON TA_ZXX
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.zseq IS NULL or :new.zseq=0 THEN
    select seq_appseq_ids.nextval
    into nextid
    from sys.dual;
    :new.zseq:=nextid;
  end if;
end tri_ta_zxx;
/
