CREATE TRIGGER TRG_TAQ_TAXAPP_UPDATE
AFTER UPDATE
  ON TAQ_TAXAPP
FOR EACH ROW
  declare
  bill_number  number;
  res integer;
begin
      select count(*) into res from tfb_transfer where BILL_SEQ=:new.billseq;
      if ((res=0) and (:new.chargeflag=1)) then
        --update tfb_transfer set bill_number=:new.billnumber,sseq=:new.sseq,useq=0,uname=:new.tollcollector,change_date=:new.rechargedate,tag=:new.chargeflag,realrating=:new.realrating,bill_seq=:new.billseq where sseq=:new.sseq;
        insert into tfb_transfer (BILL_NUMBER,SSEQ,USEQ,UNAME,CHANGE_DATE,TAG ,REALRATING,ID,BILL_SEQ,BILL_BATCH,BILL_TYPE,BILL_STATE) 
        values(:new.billnumber,:new.sseq,:new.useq,:new.tollcollector,
        --(SELECT SYSDATE FROM DUAL),--
        :new.rechargedate,
        :new.chargeflag,:new.realrating,co_get_seq('BUDGET_ITEM_ID'),:new.billseq,
        (select BILL_BATCH from TFB_BILL where BILL_SEQ = :new.billseq),
        (select BILL_TYPE from TFB_BILL where BILL_SEQ = :new.billseq),
        (select distinct sstate from tfb_state where f_date is null and  bill_seq = :new.billseq));  
      end if;
      
      
      --select :new.billnumber,:new.sseq,0,:new.tollcollector,:new.rechargedate,:new.chargeflag,:new.realrating from taq_taxapp where  bill_number=:new.billnumber;
    
 End trg_taq_taxapp_update;
/
