CREATE TRIGGER TRI_TU_HOUSE_DEL
AFTER DELETE
  ON TU_HOUSE
FOR EACH ROW
  declare
begin
  Delete tu_subhouse where hid=:new.hid;
end tri_tu_house;
/
