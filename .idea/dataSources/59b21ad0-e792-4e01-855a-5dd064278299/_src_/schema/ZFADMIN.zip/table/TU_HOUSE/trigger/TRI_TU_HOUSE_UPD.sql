CREATE TRIGGER TRI_TU_HOUSE_UPD
AFTER UPDATE
  ON TU_HOUSE
FOR EACH ROW
  declare
begin
  update tu_subhouse set hpoint=:new.hpoint,barea=:new.barea where hid=:new.hid;
end tri_tu_house_upd;
/
