CREATE TRIGGER TRI_TU_HOUSE_INS
BEFORE INSERT
  ON TU_HOUSE
FOR EACH ROW
  declare
begin
  IF :new.hseq IS NULL or :new.hseq=0 THEN
    select seq_appseq_ids.nextval
    into :new.hseq from sys.dual;
  End if;
  If not nvl(:new.hpoint,1)=1 Then 
     Insert into tu_subhouse values(:new.hid,:new.hpoint,:new.barea,:new.xz_id);
  End if;
end tri_tu_house_ins;
/
