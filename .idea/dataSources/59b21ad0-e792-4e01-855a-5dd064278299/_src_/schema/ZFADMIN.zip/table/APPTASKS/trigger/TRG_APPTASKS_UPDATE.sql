CREATE TRIGGER TRG_APPTASKS_UPDATE
BEFORE UPDATE
  ON APPTASKS
FOR EACH ROW
  declare
begin
    --如果是将在办标志修改成办结就删除掉apptasks_pending表的这条记录
    If (:new.tstate<=0) and (:old.tstate>=1) then
       delete apptasks_pending where tseq=:new.tseq;
    End If;
    --退回到岗位
    If (:new.tuser!=0) and (:old.tuser=0) then
       update apptasks_pending set tuser=:new.tuser where tseq=:new.tseq;
    End If;


    If (:new.tuser=0) and (:old.tuser!=0) then
       update apptasks_pending set tuser=:new.tuser  where tseq=:new.tseq;
    End If;

    If (:new.tuser=0) and (:new.troleseq!=:old.troleseq) then
       update apptasks_pending set troleseq=:new.troleseq
         where tseq=:new.tseq;
    End If;

    ---更新任务开始时间
    If   (:new.tsdate!=:old.tsdate) then
       update apptasks_pending set tsdate=:new.tsdate
         where tseq=:new.tseq;
    End If;



    If (:new.tstate>=1) and (:old.tstate<=0) then
       Insert into apptasks_pending(tseq,tbid,tbname,tappseq,tstate,tsdate,tedate,tactseq,tactname,tactid,troleseq,trolename,tuser,tuname,preactseq,preactname,preuser,preuname,actmail,actsms,topendate,personalshow,idea,marking,plandate,actrtx,backidea,xz_id)
              values(:new.tseq,:new.tbid,:new.tbname,:new.tappseq,:new.tstate,:new.tsdate,:new.tedate,
              :new.tactseq,:new.tactname,:new.tactid,:new.troleseq,:new.trolename,:new.tuser,:new.tuname,
              :new.preactseq,:new.preactname,:new.preuser,:new.preuname,:new.actmail,:new.actsms,
              :new.topendate,:new.personalshow,:new.idea,:new.marking,:new.plandate,:new.actrtx,:new.backidea,:new.xz_id);
    End If;
    --如果是任务转移，将用户同步到apptasks_pending
    If (:new.tstate>=1) and (:old.tstate>=1) then
       update apptasks_pending set tuser=:new.tuser,tuname=:new.tuname where tseq=:new.tseq;
    End If;
End trg_apptasks_update;
/
