CREATE TRIGGER TRG_APPTASKS_INSERT
BEFORE INSERT
  ON APPTASKS
FOR EACH ROW
  declare
cur_batchtag number;
begin
select co_get_batchtag(:new.tactseq,:new.tbid) into cur_batchtag from dual;
       Insert into apptasks_pending(tseq,tbid,tbname,tappseq,tstate,tsdate,tedate,tactseq,tactname,tactid,troleseq,trolename,tuser,tuname,preactseq,preactname,preuser,preuname,actmail,actsms,topendate,personalshow,idea,marking,plandate,actrtx,backidea,batchtag)
              values(:new.tseq,:new.tbid,:new.tbname,:new.tappseq,:new.tstate,:new.tsdate,:new.tedate,
              :new.tactseq,:new.tactname,:new.tactid,:new.troleseq,:new.trolename,:new.tuser,:new.tuname,
              :new.preactseq,:new.preactname,:new.preuser,:new.preuname,:new.actmail,:new.actsms,
              :new.topendate,:new.personalshow,:new.idea,:new.marking,:new.plandate,:new.actrtx,:new.backidea,cur_batchtag);
End trg_apptasks_insert;
/
