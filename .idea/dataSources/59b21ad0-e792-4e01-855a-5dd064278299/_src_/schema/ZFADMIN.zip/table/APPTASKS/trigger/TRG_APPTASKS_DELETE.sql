CREATE TRIGGER TRG_APPTASKS_DELETE
AFTER DELETE
  ON APPTASKS
FOR EACH ROW
  declare
begin
    --如果是将在办标志修改成办结就删除掉apptasks_pending表的这条记录
       delete apptasks_pending where tseq=:old.tseq;
End trg_apptasks_delete;
/
