CREATE TRIGGER TRI_TAT_BANKRETURN
BEFORE INSERT
  ON TAT_BANKRETURN
FOR EACH ROW
  declare
  num_paccount varchar(50);
  num_sseq number;
  num_btype number;
  v_jsamount number(15,2);
  v_amount  number(15,2);
  v_jgyxh varchar(15);
  v_count number(1);
begin

----计算进出帐总金额

   select  nvl(sum(amount),0) jsamount,count(*) into v_jsamount,v_count 
   from tat_bankreturn where nseq=:new.nseq ;
   
   v_jsamount:=v_jsamount+:new.amount;

  
 
 
--    select  v_amount into  v_amount  from tat_data where  nseq=:new.nseq and f_date is null ;


select contract_no,sseq,btype,amount,jgxyh into num_paccount,num_sseq,num_btype,v_amount ,v_jgyxh
from tat_data  where nseq= :new.nseq;
--bankaccountname,bankaccount,openbank,ptag,memo,ttagcamount,cdatecamount,cdate,camount,cdate,accdid

--进帐
  if num_btype<=3 then

    insert into TAT_ACCOUNT_DETAIL(paccount,nseq,btype,ftype,credate,samount,bankno,accdid,Jgxyh,Prove)
    values(num_paccount,:new.nseq,:new.itype,1,:new.adate,:new.amount,:new.bankno,co_get_seq('ESF_ID'),v_jgyxh,:new.Prove);



----进帐金额
    if(v_jsamount>=v_amount) then

    insert into to_state(sid,bid,sbid,stype,v_date,modality,bseq,wfseq,st_name)
    select sd_id,:new.nseq,:new.nseq,'ESFZJYC',sysdate,0,1000,1000,'资金已存' from taq_sdlist where sseq=num_sseq;
    
      insert into to_state(sid,bid,sbid,stype,v_date,modality,bseq,wfseq,st_name)
    select sd_id,:new.nseq,:new.nseq,'ESFZJQR',sysdate,0,1000,1000,'监管确认' from taq_sdlist where sseq=num_sseq;
    
    
    end if;



  end if;
--出帐
  if num_btype>3 then


    insert into TAT_ACCOUNT_DETAIL(paccount,nseq,btype,ftype,credate,samount,bankno,accdid,Jgxyh,Prove)
    values(num_paccount,:new.nseq,:new.itype,2,:new.adate,:new.amount,:new.bankno,co_get_seq('ESF_ID'),v_jgyxh,:new.Prove);

   if(v_jsamount>=v_amount) then
    insert into to_state(sid,bid,sbid,stype,v_date,modality,bseq,wfseq,st_name)
    select sd_id,:new.nseq,:new.nseq,'ESFZJYFK',sysdate,0,1000,1000,'资金已放款' from  taq_sdlist where sseq=num_sseq;
    end if;

    end if;

 if(v_jsamount>=v_amount) then
update tat_data set NSTATE=2 where nseq=:new.nseq;

end if;

end tri_tat_bankreturn;
/
