CREATE TRIGGER TRG_STA_RSPROJPLAN_INSERT
AFTER INSERT
  ON STA_RSPROJPLAN
FOR EACH ROW
  declare
  
begin
 --更新累计投资--项目状态为开工 在建项目标志
 update sta_proj set (SUMINVES,ONSTATE,PSTATE)=(select sum(PADDINVEST+PHOUSEINVEST),1,'1S' from sta_rsprojplan where pid=:old.pid) where pid=:old.pid;
 --

end trg_sta_rsprojplan_insert;
/
