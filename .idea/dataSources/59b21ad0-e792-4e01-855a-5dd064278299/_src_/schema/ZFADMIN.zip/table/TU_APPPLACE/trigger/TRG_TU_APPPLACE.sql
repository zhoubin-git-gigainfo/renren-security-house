CREATE TRIGGER TRG_TU_APPPLACE
BEFORE INSERT OR UPDATE
  ON TU_APPPLACE
FOR EACH ROW
  declare
  -- local variables here
    v_IAID    number;
    v_IALoc   varchar2(20);
    v_IANo    number;
    Ia_Type   number;
Begin
    Select nvl(max(t2.iatype),650001) into Ia_Type From tu_applists t1,ts_state t2
     Where t1.st_code=t2.st_code and t1.bu_sseq=:new.sseq;
     
    If :new.IASEQ=-1 Then
       Select * Into v_IAID,v_IALoc,v_IANo From (
       Select iaseq,iadesc,maxid+1  From sys_daia 
        Where connect_by_isleaf=1 and usermark=1 and ycy<kcy and iatype=Ia_Type
        Start with IASEQ=8889 
      Connect by prior iaseq = iaparent order by iadesc) Where rownum<2;
       :new.iaseq:=v_IAID;
       :new.iadesc:=v_IALoc||'.'||substr('000'||to_char(v_IANo),-3);
       Update sys_daia Set maxid=v_IANo,ycy=ycy+1 Where iaseq=v_IAID;
     ELSIF :new.IASEQ=100002609352 then
        Select * Into v_IAID,v_IALoc,v_IANo From (
       Select iaseq,iadesc,maxid+1  From sys_daia 
        Where connect_by_isleaf=1 and usermark=1 and ycy<kcy 
        Start with IASEQ=100002609352
           Connect by prior iaseq = iaparent order by iadesc) Where rownum<2;
    --   :new.iaseq:=v_IAID;
    --   :new.iadesc:=v_IALoc||'.'||substr('000'||to_char(v_IANo),-3);
    --   Update sys_daia Set maxid=v_IANo,ycy=ycy+1 Where iaseq=v_IAID;
    Else
       If :new.IASEQ!=:old.IASEQ Then
          Select iadesc,maxid+1 into v_IALoc,v_IANo 
            From sys_daia Where iaseq=:new.IASEQ;
          Update sys_daia Set maxid=maxid-1,ycy=ycy-1 Where iaseq=:old.IASEQ;
          Update sys_daia Set maxid=v_IANo,ycy=ycy+1 Where iaseq=:new.IASEQ;
          :new.iadesc:=v_IALoc||'.'||substr('000'||to_char(v_IANo),-3);
       End if;
    End if;    
    Return;
end trg_tu_appplace;
/
