CREATE TRIGGER TRI_TA_RELATION
BEFORE INSERT
  ON TA_RELATION
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.tseq IS NULL or :new.tseq=0 THEN
    select co_seq_appseq_ids.nextval
    into nextid
    from sys.dual;
    :new.tseq:=nextid;
  end if;
end tri_ta_relation;
/
