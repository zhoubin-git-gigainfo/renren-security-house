CREATE TRIGGER TRG_TF_BUDGET_DETAIL
BEFORE INSERT OR UPDATE
  ON TF_BUDGET_DETAIL
FOR EACH ROW
  declare
--pragma autonomous_transaction;   
  -- local variables here
  num_apply  float;
  num_check  float;
  num_bx     float;
  num_syze   float;
  num_dbsye  float;
  num_detail_id number;
  num_sseq number;
  nextid number;
begin
    --commit;
    --如果是修改结束时间为空的将退出
    --if :new.year_budget_id is null then return;  end if;
     update tf_year_budget set budget_num= :new.budget_num where year_budget_id=:new.year_budget_id;
End trg_tf_fee_detail;
/
