CREATE TRIGGER TRG_TFB_SHIFTBILL
BEFORE INSERT OR UPDATE
  ON TFB_SHIFTBILL
FOR EACH ROW
  DECLARE
strtemp varchar(400);
BEGIN
  strtemp:=','||to_char(:new.nid)||',';
   update appworkflow set appres=strtemp where appseq=(select distinct appseq from sv_bulists where sseq=:new.sseq);
END;
/
