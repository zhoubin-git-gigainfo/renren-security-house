CREATE TRIGGER TRG_COREATTECH_INSERT
BEFORE INSERT
  ON TU_COREATTECH20150422
FOR EACH ROW
  declare

v_otype number(2);
v_optype number(2);
 v_count number;
 v_xzid number;
 v_blob blob;
 str_sql varchar2(1024);
begin

---检查分发下来的数据，如果是分发下来的数据则不再进行上传

/*
select  max(optype) , max(oxz_id),max(otype)   into   v_optype,v_xzid,v_otype from (
select optype, otype , oxz_id  from ts_synchro where nid=:old.nid
and optype=1
order by id desc ) where rownum=1;



if   v_xzid is not null  and v_xzid='430201'  then
  return;
  end if;

----如果不是分发下来的，则进行上传




select  otype into  v_otype from tu_coreaitem where aid=:new.aid;

insert into ts_synchro( id, nid, oxz_id, otype, optype,memo)
values(co_get_seq@zzfcall('synchro'),:new.nid,'430201',v_otype,1,'株洲市' );

   insert into attech_temp (nid, cdate,fole,fpath,fname,aid,
    faname, ordernum, f_date,modality, xz_id,utag)
 values
   (:new.nid,:new.cdate,:new.fole,:new.fpath,:new.fname,
    :new.aid, :new.faname, :new.ordernum, :new.f_date,    :new.modality,
    :new.xz_id, :new.utag);
 

insert into tu_allcoreattech (nid, cdate, fole,  fpath, fname, aid,
faname, ordernum, f_date, modality, xz_id, utag)
 select nid, cdate, fole,  fpath, fname, aid,
faname, ordernum, f_date, modality, xz_id, utag from attech_temp 
where nid=:new.nid;*/

--create table a111 as select * from attech_temp;


--CREATE GLOBAL TEMPORARY TABLE TMP_TEST ON COMMIT PRESERVE ROWS AS SELECT * FROM TEST;




--判断更新标记为0的才更新到总库
If (:new.utag=0) then 
   delete tu_coreattech_temp where nid=:new.nid; 
/*    --创建临时表
    str_sql:='CREATE GLOBAL TEMPORARY TABLE TU_COREATTECH_TEMP(nid number, cdate date, fole blob,  fpath varchar2(256), fname varchar2(60), aid number,
                    faname varchar2(60), ordernum number, f_date date, modality number, xz_id varchar2(10), utag number(1)) ON COMMIT PRESERVE ROWS'; 
    execute immediate str_sql; */
    insert into tu_coreattech_temp (nid, cdate, fole,  fpath, fname, aid,
                faname, ordernum, f_date, modality, xz_id, utag)
     values(:new.nid, :new.cdate, :new.fole,  :new.fpath, :new.fname, :new.aid,
                :new.faname, :new.ordernum, :new.f_date, :new.modality, '430225', :new.utag);
     
     insert into tu_coreattech@zzfcall(nid, cdate, fole,  fpath, fname, aid,
                faname, ordernum, f_date, modality, xz_id, utag)
     select nid, cdate, fole,  fpath, fname, aid,
                 faname, ordernum, f_date, modality, xz_id, 1 from tu_coreattech_temp 
     where nid=:new.nid;
     :new.utag:=1;
     insert into TU_COREATTECH_LOG@zzfcall(xz_id,OPERATETYPE,odate) values('430225','炎陵trg_coreattech_insert',sysdate);
End If;


End trg_coreattech_insert;
/
