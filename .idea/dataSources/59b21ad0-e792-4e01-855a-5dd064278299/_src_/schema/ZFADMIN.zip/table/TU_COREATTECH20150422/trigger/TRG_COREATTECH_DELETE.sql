CREATE TRIGGER TRG_COREATTECH_DELETE
AFTER DELETE
  ON TU_COREATTECH20150422
FOR EACH ROW
  declare
v_otype number(2);
v_optype number(2);
 v_count number;
 v_xzid number;
begin

/*---检查分发下来的数据，如果是分发下来的数据则不再进行上传


select  max(optype) , max(oxz_id),max(otype)   into   v_optype,v_xzid,v_otype from (
select optype, otype , oxz_id  from ts_synchro where nid=:old.nid
and optype=3
order by id desc ) where rownum=1;



if   v_xzid is not null  and v_xzid='430201'  then
  return;
end if;

----如果不是分发下来的，则进行上传

  select max( otype) into  v_otype from tu_coreaitem where aid=:old.aid;
  
  

 insert into ts_synchro@zzfcall( id, nid, oxz_id, otype, optype,memo)
values(co_get_seq@zzfcall('synchro'),:old.nid,'430201',v_otype,3,'株洲市' );

 --commit;--自治事务必须commit
 
 
     dbms_output.put_line(:old.nid);
      delete tu_allcoreattech where nid=:old.nid;*/
--end;
 -- 
If (:new.utag=1) then 
    delete tu_coreattech@zzfcall  where nid=:new.nid;
    insert into TU_COREATTECH_LOG@zzfcall(xz_id,OPERATETYPE,odate) values('430225','炎陵trg_coreattech_delete',sysdate);

End If;
 
 
End trg_coreattech_delete;
/
