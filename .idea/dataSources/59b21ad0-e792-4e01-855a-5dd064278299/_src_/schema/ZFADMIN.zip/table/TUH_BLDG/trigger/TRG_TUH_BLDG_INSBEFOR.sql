CREATE TRIGGER TRG_TUH_BLDG_INSBEFOR
BEFORE INSERT
  ON TUH_BLDG
FOR EACH ROW
  declare
  v_Sdid   number(12);
  vaild    date;
  v_mdxml  clob;
  v_recs   number;
  vh_ID    number(12);
  v_xz_id  varchar2(10);
  nextid number;
begin
  /*生成DSEQ*/
    IF nvl(:new.dseq,0)=0 THEN
      select seq_appseq_ids.nextval into nextid From sys.dual;
      :new.dseq:=nextid;
    End if;


end trg_tuh_bldg_insbefor;
/
