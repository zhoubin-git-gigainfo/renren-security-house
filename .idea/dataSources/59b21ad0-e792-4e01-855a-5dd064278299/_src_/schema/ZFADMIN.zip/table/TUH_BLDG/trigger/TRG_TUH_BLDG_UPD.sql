CREATE TRIGGER TRG_TUH_BLDG_UPD
BEFORE UPDATE
  ON TUH_BLDG
FOR EACH ROW
  declare
  -- local variables here
begin
  If ((:old.sd_flag=1) and (:old.f_date is null)) Then
  begin
       Update tu_bldg Set v_date=:new.v_date,metno=:new.metno,plotid=:new.plotid,distid=:new.distid,ddesc=:new.ddesc,lid=:new.lid,
                           lname=:new.lname,bno=:new.bno,bdesc=:new.bdesc,
                           spid=:new.spid,bstru=:new.bstru,btype=:new.btype,
                           buse=:new.buse,barea=:new.barea,garea=:new.garea,
                           parea=:new.parea,sarea=:new.sarea,uarea=:new.uarea,
                           bfete=:new.bfete,
                           lcout=:new.lcout,ucout=:new.ucout,memo=:new.memo,
                           bkind=:new.bkind,bqut=:new.bqut,
                           pbldg=:new.pbldg,parentid=:new.parentid,dq=:new.dq,
                           nq=:new.nq,xq=:new.xq,bq=:new.bq,
                           lucn=:new.lucn,ldcn=:new.ldcn,dm_cb=:new.dm_cb,
                           dm_yt=:new.dm_yt,dm_jg=:new.dm_jg,bstate=:new.bstate,
                           sstate=:new.sstate,gis_x=:new.gis_x,gis_y=:new.gis_y,
                           bstruname=:new.bstruname,husename=:new.husename,btypename=:new.btypename,
                           a_id=:new.a_id,a_name=:new.a_name,xz_id=:new.xz_id
         Where Sid=:old.sid;
           Insert into tum_bldg(sid,v_date,f_date,metno,plotid,distid, ddesc,lid,lname,
                      bno,bdesc,spid,bstru,btype,buse,barea,bpric,garea,parea,
                      sarea,uarea,bfete,lcout,ucout,memo,bkind,bqut,pbldg,
                      parentid,dq,nq,xq,bq,lucn,ldcn,dm_cb,dm_yt,
                      dm_jg,bstate,sstate,gis_x,gis_y,BSTRUNAME,HUSENAME,btypename,a_id,a_name,xz_id)
               values(:new.sid,:new.v_date,sysdate,:new.metno,:new.plotid,:new.distid, :new.ddesc,:new.lid,:new.lname,
                      :new.bno,:new.bdesc,:new.spid,:new.bstru,:new.btype,:new.buse,:new.barea,:new.bpric,:new.garea,:new.parea,
                      :new.sarea,:new.uarea,:new.bfete,:new.lcout,:new.ucout,:new.memo,:new.bkind,:new.bqut,:new.pbldg,
                      :new.parentid,:new.dq,:new.nq,:new.xq,:new.bq,:new.lucn,:new.ldcn,:new.dm_cb,:new.dm_yt,
                      :new.dm_jg,:new.bstate,:new.sstate,:new.gis_x,:new.gis_y,:new.BSTRUNAME,:new.HUSENAME,:new.btypename,:new.a_id,:new.a_name,:new.xz_id);

  end;

  End if;
  --:new.fx_info:=to_char(:new.sid);
  --:new.fx_info:='';
  --:new.fx_info:=:new.map_no||' 'to_char(:new.pbldg)||' '||to_char(:new.sid)||' '||:new.ddesc||:new.lanem||:new.bdesc;
end trg_tuh_bldg_upd;
/
