CREATE TRIGGER TRG_TUH_BLDG_DEL
AFTER DELETE
  ON TUH_BLDG
FOR EACH ROW
  declare
  -- local variables here
  v_recs  integer;
  nextid number;
begin

    --如果是修改结束时间为空的将退出
    if not :old.f_date is null then return;  end if;
    delete tu_bldg where sid=:old.sid;
/*    Select Count(*) into v_recs From tuh_house Where f_date is null and  Hid=:new.hid and v_date=;

    If v_recs=1 Then
       delete tu_house where hid=:new.hid;
    End if;*/

End trg_tuh_bldg_del;
/
