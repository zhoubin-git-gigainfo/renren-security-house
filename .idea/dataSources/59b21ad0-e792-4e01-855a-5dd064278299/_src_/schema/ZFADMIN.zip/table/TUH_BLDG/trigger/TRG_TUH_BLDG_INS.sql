CREATE TRIGGER TRG_TUH_BLDG_INS
AFTER INSERT
  ON TUH_BLDG
  declare
  v_Sdid   number(12);
  vaild    date;
  v_mdxml  clob;
  v_recs   number;
  vh_ID    number(12);
  v_xz_id  varchar2(10);
  nextid number;
begin
/*  \*生成DSEQ*\
    IF nvl(:new.dseq,0)=0 THEN
      select seq_appseq_ids.nextval into nextid From sys.dual;
      :new.dseq:=nextid;
    End if;  */
   DECLARE CURSOR MyBldg IS
           Select distinct SID,max(v_date),xz_id From tuh_bldg Where f_date is null and SD_Flag=0 group by SID,xz_id;
   BEGIN
       OPEN MyBldg;
       LOOP
           FETCH MyBldg INTO v_SDID,vaild,v_xz_id;
           EXIT WHEN MyBldg%NOTFOUND;
--一、维护现实数据表
--1、维护栋表tu_bldg
           Delete tu_bldg Where SID=v_Sdid;
           Insert into tu_bldg
               Select sid,v_date,f_date,metno,plotid,distid, ddesc,lid,lname,
                      bno,bdesc,spid,bstru,btype,buse,barea,bpric,garea,parea,
                      sarea,uarea,bfete,lcout,ucout,memo,bkind,bqut,pbldg,
                      parentid,dq,nq,xq,bq,lucn,ldcn,dm_cb,dm_yt,
                      dm_jg,bstate,sstate,gis_x,gis_y,BSTRUNAME,HUSENAME,btypename,null,null,a_id,a_name,xz_id
                 From tuh_bldg Where sid=v_Sdid and v_date=vaild ;
               Insert into tum_bldg
               --插入到多重属性表
               Select sid,v_date,sysdate,metno,plotid,distid, ddesc,lid,lname,
                      bno,bdesc,spid,bstru,btype,buse,barea,bpric,garea,parea,
                      sarea,uarea,bfete,lcout,ucout,memo,bkind,bqut,pbldg,
                      parentid,dq,nq,xq,bq,lucn,ldcn,dm_cb,dm_yt,
                      dm_jg,bstate,sstate,gis_x,gis_y,1,BSTRUNAME,HUSENAME,btypename,null,null,a_id,a_name,xz_id
                 From tuh_bldg Where sid=v_Sdid and v_date=vaild ;
            Update tuh_bldg set tuh_bldg.sd_flag=1 where sid=v_Sdid;

--二、维护全文索引信息
--1、维护栋
           Select count(*) into v_recs From tu_sdinfo Where sd_id=v_Sdid;
           v_mdxml:=co_get_sdinfo(v_SDID,1);
           If v_recs=0 Then
              Insert into tu_sdinfo(SD_ID,sd_info,sd_type,sd_parent,xz_id) values(v_Sdid,v_mdxml,1,-1,v_xz_id);
           Else
              Update tu_sdinfo set sd_Info=v_mdxml where sd_id=v_Sdid;
           End if;

--2、维护户
           Declare CURSOR Myhouse IS
                   Select distinct HID From tu_house Where sid=v_Sdid and v_date=vaild ;
           Begin
               OPEN Myhouse;
               LOOP
                   FETCH Myhouse INTO vh_ID;
                   EXIT WHEN Myhouse%NOTFOUND;
                   v_mdxml:=co_get_sdinfo(vh_ID,4);
                   Select count(*) into v_recs From tu_sdinfo Where sd_id=vh_ID;
                   If v_recs=0 then
                      Insert into tu_sdinfo(SD_ID,sd_info,sd_type,sd_parent,xz_id) values(vh_ID,v_mdxml,4,v_Sdid,v_xz_id);
                   Else
                      Update tu_sdinfo set sd_Info=v_mdxml where sd_id=vh_ID;
                   End if;
               End loop;
               CLOSE Myhouse;
           End;
       END loop;
       CLOSE MyBldg;
   End;

end trg_tuh_bldg_ins;
/
