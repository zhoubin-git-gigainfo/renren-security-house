CREATE TRIGGER TRI_TA_FUNCLIST
BEFORE INSERT
  ON TA_FUNCLIST
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.lseq IS NULL or :new.lseq=0 THEN
    select seq_appseq_ids.nextval
    into nextid
    from sys.dual;
    :new.lseq:=nextid;
  end if;
end tri_ta_funclist;
/
