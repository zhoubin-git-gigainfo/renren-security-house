CREATE TRIGGER TRG_TMH_MAINBODY
AFTER INSERT
  ON TMH_MAINBODY
  declare

begin
  co_cre_mdinfo;
 end trg_tmh_mainbody;
/
