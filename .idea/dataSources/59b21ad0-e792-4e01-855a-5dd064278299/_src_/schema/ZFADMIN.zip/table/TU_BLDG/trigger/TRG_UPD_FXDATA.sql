CREATE TRIGGER TRG_UPD_FXDATA
BEFORE INSERT OR UPDATE
  ON TU_BLDG
FOR EACH ROW
  declare
  -- local variables here
  vs varchar2(10) default ',''';
  l_sql           varchar2(3000);
  l_xml           clob;
  v_rec           integer;
  vm_date         date;
begin
   /*If (:new.lname!=:old.lname or :new.bdesc!=:old.bdesc) and :new.bno!='999' Then
       vm_date:=sysdate;
       Delete tuh_bldg Where sid=:old.sid and v_date=:old.v_date;
       Insert into tuh_bldg (sid,v_date,f_date,metno,plotid,distid,ddesc,lid,lname,bno,bdesc,spid,bstru,btype,buse,
                             barea,bpric,garea,parea,sarea,uarea,bfete,lcout,ucout,memo,bkind,bqut,pbldg,parentid,
                             dq,nq,xq,bq,lucn,ldcn,dm_cb,dm_yt,dm_jg,bstate,sstate,gis_x,gis_y,sd_flag,bstruname,
                             husename,btypename)
                     Values (:old.sid,:old.v_date,vm_date,:old.metno,:old.plotid,:old.distid,:old.ddesc,:old.lid,:old.lname,
                             :old.bno,:old.bdesc,:old.spid,:old.bstru,:old.btype,:old.buse,:old.barea,:old.bpric,:old.garea,
                             :old.parea,:old.sarea,:old.uarea,:old.bfete,:old.lcout,:old.ucout,:old.memo,:old.bkind,:old.bqut,
                             :old.pbldg,:old.parentid,:old.dq,:old.nq,:old.xq,:old.bq,:old.lucn,:old.ldcn,:old.dm_cb,:old.dm_yt,
                             :old.dm_jg,:old.bstate,:old.sstate,:old.gis_x,:old.gis_y,1,:old.bstruname,:old.husename,:old.btypename);
       :new.v_date:=vm_date;
   End if;*/
   :new.fx_info:=to_char(:new.sid)||' '||:new.metno||' '||:new.ddesc||:new.lname||:new.bdesc;
   l_Sql:='Select ''ID'||to_char(:new.sid)||''' 编号'||vs||:new.metno||''' 用户码'||vs||:new.ddesc||''' 区'||vs||:new.lname||''' 坐落'||vs||:new.bdesc||''' 栋名'||vs||:new.bstru||''' 结构'||vs||:new.buse||''' 用途'||vs||:new.lcout||''' 层数'||vs||:new.bfete||''' 建设年代 From dual';
   l_xml:=co_get_xml(l_sql,'房屋','栋');
      
   Select Count(*) into v_rec from tu_sdinfo where sd_id=:new.sid;
  If v_rec=0 Then
      insert into tu_sdinfo(sd_id,sd_info,sd_type,sd_parent,xz_id) values(:new.sid,l_xml,1,-1,:new.xz_id);
   Else
      update tu_sdinfo set sd_info=l_xml where sd_id=:new.sid;
   end if;
   return;
end trg_Upd_FxData;
/
