CREATE TRIGGER TRG_APAS_TIMES_INS
AFTER INSERT OR UPDATE
  ON APAS_TIMES
FOR EACH ROW
  declare

  v_sdate    date;
  v_actlimitdate   number;
  v_edate   date;
  v_tseq number;
begin

--恢复暂停情况
  if :NEW.sdatetime=' ' and length(:NEW.edatetime )>10 then
   select * into v_sdate,v_actlimitdate,v_tseq from (
                  select  tsdate,actlimitdate+1,tseq from apptasks t1,appwfactivity t2
                   where t1.tactseq=t2.actseq
                  and  tactseq=:NEW.actid order by tseq  ) where rownum=1;


   --查询限制结束时间
   select workday into v_edate from (select * from (select * from (
   select * from syscalendar t where workday>v_sdate and worktag=0  order by workday )
   where  rownum<=v_actlimitdate) order by  workday desc ) where rownum=1;
   
   --修改计划完成时间
   update apptasks  set plandate=v_edate  where tseq=v_tseq;

--暂停开始情况
  else
   
  update apptasks  set plandate= to_date('9998-12-31' ,'yyyy-mm-dd')  where tseq in
      ( select max(tseq ) from apptasks where tactseq=:NEW.actid);

  end if;
  
end trg_apas_times_ins;
/
