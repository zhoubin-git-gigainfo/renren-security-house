CREATE TRIGGER TRG_TO_STATE_DEL
AFTER DELETE
  ON TO_STATE_0805
FOR EACH ROW
  begin
   Delete to_relation Where bid=:new.bid and to_relation.sid=:new.sid;
end trg_to_state_del;
/
