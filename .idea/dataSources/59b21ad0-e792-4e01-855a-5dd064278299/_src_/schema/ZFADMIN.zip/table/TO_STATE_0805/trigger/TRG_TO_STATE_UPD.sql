CREATE TRIGGER TRG_TO_STATE_UPD
AFTER UPDATE
  ON TO_STATE_0805
FOR EACH ROW
  declare
  --v_BuInfo     clob;
  --v_DisBu      varchar2(1024);
  --v_point      number;
  v_recs       integer;
  --v_bucount    integer;
  --v_buyear     number;
  --v_bunos      number;
  v_bseq number;
begin
     Update to_relation set f_date=:new.f_date,modality=:new.modality
      Where v_date<>:new.f_date and bid=:new.bid and sid=:new.sid and :new.stype not in ('XMCJ','6A')  ;--and to_relation.stype=:new.stype;
     Update tu_applists Set bu_state=:new.modality Where bu_sseq=:new.bid;
     --失效证照,当是测量、预测量、价格公示变更的时候将不失效证照
     v_bseq:=0;
     If ((:new.disbuno is not null) and (:new.disbuno>0)) then
     begin
        select count(*) into v_recs from sv_bulists where sseq= :new.disbuno;
        IF (v_recs>0) Then
           select bseq  into v_bseq from sv_bulists where sseq= :new.disbuno;
        End If;
     end;
     End If;
     IF ((v_bseq<>22005) and (v_bseq<>1750000) and (v_bseq<>100000076945) and (v_bseq<>100000086945) ) then
        Update tu_card Set tu_card.cstate=Decode(:new.modality,9,-1,1) Where bid=:new.bid;
     End If;
   --Update tu_card Set tu_card.cstate=Decode(:new.modality,9,-1,1) Where bid=:new.bid;
 /** select bseq into v_bseq from sv_bulists where sseq=:new.bid;
     --不是因为楼盘变更而导致的证失效
     if ((v_bseq<>1750000) and (v_bseq<>22005) and (v_bseq<>100000003713) and (v_bseq<>100000000029)) then
        Update tu_card Set tu_card.cstate=Decode(:new.modality,9,-1,1) Where bid=:new.bid;
     end if;*/
--同步to_state_log的形态、失效时间
     If (:old.modality=0 and :new.modality=9 and :new.bid!=:new.disbuno) Then
        Update to_state_log Set staute=:new.modality,f_date=to_date(to_char(:new.f_date,'yyyy-mm-dd'),'yyyy-mm-dd')
         Where stype=:new.stype and sid=:new.sid and bid=:new.bid;
     End if;
/*
     --更改登记簿"注销"节点
     Select count(*) into v_recs From tu_applists Where bu_sseq=:new.bid;
     If v_Recs=1 and :new.modality=9 and :old.modality=0 then --注销业务
         v_buyear:=to_number(substr(to_char(:new.disbuno),1,4));
         v_bunos:=to_number(substr(to_char(:new.disbuno),5,7));
         If v_buyear>=2008 and v_buyear<9999 and v_bunos>=1000000 and v_bunos<5000000 Then
            Select count(*) into v_bucount from tu_applists where bu_sseq=:old.bid;
            Select v_bucount+count(*) into v_bucount From taq_enrol where sseq=:new.disbuno;
            If v_bucount=2 then
                Select '<注销><业务号>'||to_char(sseq)||'</业务号><业务名>'||bdesc||'</业务名><登簿日期>'||to_char(regbookdate,'yyyy.mm.dd')||'</登簿日期><登簿人>'||regbookerame||'</登簿人></注销>' into v_DisBu
                  From taq_enrol where sseq=:new.disbuno;
            End if;
         End if;
         If :new.disbuno=1009 Then
            v_DisBu:='<注销><业务号>1009</业务号><业务名>到期自动注销</业务名><登簿日期>'||to_char(sysdate,'yyyy.mm.dd')||'</登簿日期><登簿人>系统自动</登簿人></注销>';
         End if;
         Select substr(bu_info,1,Instr(bu_info,'</SD_Info>')-1)||chr(13)||v_DisBu||chr(13)||'</SD_Info>' into v_BuInfo
           from tu_applists where bu_sseq=:old.bid;
         Update tu_applists Set bu_state=9,bu_info=v_BuInfo where bu_sseq=:new.bid;
     End if;
     If v_Recs=1 and :new.modality=0 and :old.modality=9 then --将注销状态变为有效状态
        Select Instr(bu_info,'<注销>') into v_point From tu_applists where bu_sseq=:new.bid;
        If v_point>0 Then
            Select substr(bu_info,1,Instr(bu_info,'<注销>')-1)||chr(13)||'</SD_Info>' into v_BuInfo
              from tu_applists  where bu_sseq=:new.bid;
            Update tu_applists Set bu_state=0,bu_info=v_BuInfo where bu_sseq=:new.bid;
        End if;

     End if;
  */
  return;
end ;
/
