CREATE TRIGGER TRG_TO_STATE_INS
BEFORE INSERT
  ON TO_STATE_0805
FOR EACH ROW
  Declare
  v_recs       integer;
  v_uprice     number;
  v_pprice     number;
  v_Inv_no     number;

Begin
  



   if :new.modality=1 and :new.stype in('53','33','BA-DY')  then 
   insert into TAR_PUSHEDREC(TARPHID, SSEQ, MODALITY, STYPE, V_DATE, TFLAG, ptype,appseq)
select co_get_seq('tran_id'),:new.bid,:new.MODALITY,:new.STYPE,:new.v_date,'11',1,:new.wfseq from dual 
 ;
end if;

    
   

   If :new.modality!=0 Then return; end if;

    --Tprice=核准金额、签约金额 PPrice=抵押额
   Select max(uprice),max(upprice) into v_uprice,v_pprice From sv_sdlists Where sseq=:new.bid;

   --平均抵押额
   If :new.stype='41' or :new.stype='43' or :new.stype='45' or :new.stype='46' or :new.stype='49' or :new.stype='4A' Then
       Select round(v_pprice*barea,0) into :new.pprice From tu_house Where hid=:new.sid;
   End if;

   --签约金额
   If :new.stype='32' or :new.stype='33' or :new.stype='44' then
      Select count(*) into v_recs From tu_house Where hid=:new.sid;
      If v_recs>0 Then
         Select round(v_uprice*(t1.barea+nvl(t2.barea,0)),0) into :new.tprice From tu_house t1,mv_group_house t2
          Where t1.hid=t2.hpoint(+) and t1.hid=:new.sid;
         --Select round(v_uprice*barea,0) into :new.tprice From tu_house Where hid=:new.sid;
      End if;
   End if;

   --设置合同号
/*   If :new.stype='32' and :new.modality=0 Then
      v_Inv_no:=co_get_strlists('appseq',:new.wfseq,'to_number(contract_no)','sales_contract',null);
      v_pactnum:=co_get_strlists('appseq',:new.wfseq,'contract_no','sales_contract',null);
      v_Inv_no:=nvl(v_Inv_no,co_get_seq('INVOICE'));
      If v_Inv_no=0 Then
        begin
         v_Inv_no:=co_get_seq('INVOICE');
         Update tuh_house set pactnum=v_Inv_no Where f_date is null and hid=:new.sid;
         Update sales_contract set contract_no=to_char(v_Inv_no) where appseq=:new.wfseq;
        end;
      else
        begin
         Update tuh_house set pactnum=v_Inv_no Where f_date is null and hid=:new.sid;
         Update sales_contract set contract_no=v_pactnum where appseq=:new.wfseq;
        end;
      End if;
   End if;   */

   --设置合同号
   If :new.stype='32' and :new.modality=0 Then
      v_Inv_no:=co_get_strlists('appseq',:new.wfseq,'to_number(contract_no)','sales_contract',null);
      v_Inv_no:=nvl(v_Inv_no,co_get_seq('INVOICE'));
      If v_Inv_no=0 Then
         v_Inv_no:=co_get_seq('INVOICE');
      End if;
      Update tuh_house set pactnum=v_Inv_no Where f_date is null and hid=:new.sid;
      Update sales_contract set contract_no=to_char(v_Inv_no) where appseq=:new.wfseq;
   End if;

   --记录数据统计误差的情况
   If :new.modality=0 and (:new.stype<'20' or :new.stype>'30') then
      Select count(*) into v_recs From to_state_log
       Where bid=decode(:new.stype,'31',bid,'35',bid,:new.bid)
         and Stype=:new.stype and sid=:new.sid ;

/*      If :new.stype='31' or :new.stype='35' then
         Select count(*) into v_recs From to_state_log where stype=:new.stype and sid=:new.sid;
      Else
         Select count(*) into v_recs From to_state_log where stype=:new.stype and sid=:new.sid and bid=:new.bid;
      End if;*/

      If v_recs=0 Then
         Insert into to_state_log (bid,sid,stype,v_date,staute,f_date,tprice,pprice,uprice,upprice,xz_id)
                values (:new.bid,:new.sid,:new.stype,to_date(to_char(:new.v_date,'yyyy-mm-dd'),'yyyy-mm-dd'),0,to_date('9999-12-30','yyyy-mm-dd'),:new.tprice,:new.pprice,v_uprice,v_pprice,:new.xz_id);
      End if;
      Update to_state_log Set Tprice=:new.tprice,pprice=:new.pprice,uprice=v_uprice,upprice=v_pprice
       Where stype=:new.stype and sid=:new.sid and bid=:new.bid;
   End if;

End ;
/
