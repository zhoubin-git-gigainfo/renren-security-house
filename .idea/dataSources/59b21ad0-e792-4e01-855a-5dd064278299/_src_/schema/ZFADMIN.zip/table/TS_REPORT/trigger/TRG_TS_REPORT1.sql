CREATE TRIGGER TRG_TS_REPORT1
AFTER INSERT
  ON TS_REPORT
FOR EACH ROW
  declare
v_sid number(2);
  -- local variables here
begin
--select * from ts_report oseq='111'
select 1 into v_sid  from dual;
    --update ts_report set rpage='1111'  where oseq='5201314';

end trg_ts_report1;
/
