CREATE TRIGGER TRI_APPRECEIVE
AFTER INSERT OR UPDATE
  ON APPRECEIVE
FOR EACH ROW
  declare
  res integer;
  v_flag integer;
  vappseq number;
  vactionname varchar2(4000);
  vactionman varchar2(4000);
  vactiondate date;
begin
  select appseq into vappseq from ta_bscommon where sseq = :new.sseq;
  select max(tactname) into vactionname
  from apptasks_pending where tappseq=vappseq;
  select  to_char(wm_concat(tuname)), min(tsdate) into vactionman, vactiondate 
  from apptasks_pending where tappseq=vappseq and tactname=vactionname group by tactname;
  select count(*) into res from APPARCHIVES where sseq= :new.sseq;
  if (res=0) then
     insert into APPARCHIVES(sseq,appseq,bseq,bname,appsubject,sdate,ftag,memo,actionname, actionman, actiondate,appptype, appnumber, appdept, appdate, appno, SUPERVISORMEMO
     )
     values(:new.sseq,:new.appseq,:new.bseq,:new.bname,:new.appsubject,:new.APPARRIVE,0,:new.appmemo,vactionname,vactionman,vactiondate,:new.appptype,:new.appnumber,
     :new.appfrom,:new.apparrive, :new.appno, :new.SUPERVISORMEMO);
  else
    begin
      select ftag into v_flag from APPARCHIVES where sseq= :new.sseq;    
      if (v_flag=0) then 
        update APPARCHIVES set sseq=:new.sseq,appseq=:new.appseq,bseq=:new.bseq,bname=:new.bname,appsubject=:new.appsubject,sdate=:new.APPARRIVE,ftag=0,memo=:new.appmemo,
        appptype=:new.appptype, appnumber=:new.appnumber, appdept=:new.appfrom, appdate=:new.apparrive,appno=:new.appno,SUPERVISORMEMO=:new.SUPERVISORMEMO,
        actionname=vactionname,actionman=vactionman,actiondate=vactiondate
        where  sseq= :new.sseq;
      end if;
    end;
  end if;
end tri_appreceive;
/
