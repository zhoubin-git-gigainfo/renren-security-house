CREATE TRIGGER TRI_TA_FUNC
BEFORE INSERT
  ON TA_FUNC
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.fseq IS NULL or :new.fseq=0 THEN
    select seq_appseq_ids.nextval
    into nextid
    from sys.dual;
    :new.fseq:=nextid;
  end if;
/*update ta_funclist a set (funcid)=(select key from (select key,num_1,num_2 from  table (co_get_Public(:new.sseq,:new.area2))) b where to_char(to_number(a.house))=b.num_2 and to_char(to_number(a.layer))=b.num_1)
where exists (select 1 from (select key,num_1,num_2 from  table (co_get_Public(:new.sseq,:new.area2))) b where  to_char(to_number(a.house))=b.num_2 and to_char(to_number(a.layer))=b.num_1);
*/
/*  update ta_funclist set funcid=:new.area2;*/
/* update ta_funclist a set a.funcid=(select key from table (co_get_Public(:new.sseq,:new.area2)) b where  to_char(to_number(a.house))=b.num_2 and to_char(to_number(a.layer))=b.num_1);*/
/*  sp_funclistcon(:new.area3,:new.sseq,:new.ridgepoleno,:new.clh,'',:new.area2);*/
end tri_ta_func;
/
