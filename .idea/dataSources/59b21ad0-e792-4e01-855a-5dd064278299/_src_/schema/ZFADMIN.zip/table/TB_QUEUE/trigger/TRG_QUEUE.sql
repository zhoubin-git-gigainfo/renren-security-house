CREATE TRIGGER TRG_QUEUE
BEFORE INSERT
  ON TB_QUEUE
FOR EACH ROW
  Begin
   If Length(Trim(:new.MSG))>70 then
      :new.MSG:=trim(:new.MSG);
      SP_PROCSMS(:new.ID,:new.PNO,:new.SPNO,:new.LINKID,:new.PHONE,
                 :new.MSG,:new.FEE,:new.USERID,:new.PWD,:new.SID);
      :new.pwd:='1';
   End if;
End ;
/
