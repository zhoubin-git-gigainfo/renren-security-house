CREATE TRIGGER TRG_STA_RSBLDGSCHEDULE_INSERT
AFTER INSERT
  ON STA_RSBLDGSCHEDULE
FOR EACH ROW
  declare
  
begin
 
--首先将该栋所有的状态修改成一致
   update  sta_rsbldgschedule set type=:old.type where sid=:old.sid;
   --更新项目统计结果表中新开工、正施工、竣工面积
   update sta_proj set (NCAREA)=(select sum(barea) from sta_rsbldgschedule where type=1 and pid=:old.pid) where pid=:old.pid;
   update sta_proj set (ONCAREA)=(select sum(barea) from sta_rsbldgschedule where type=2 and pid=:old.pid) where pid=:old.pid;
   update sta_proj set (COMPAREA)=(select sum(barea) from sta_rsbldgschedule where type=3 and pid=:old.pid) where pid=:old.pid;
end trg_sta_rsbldgschedule_insert;
/
