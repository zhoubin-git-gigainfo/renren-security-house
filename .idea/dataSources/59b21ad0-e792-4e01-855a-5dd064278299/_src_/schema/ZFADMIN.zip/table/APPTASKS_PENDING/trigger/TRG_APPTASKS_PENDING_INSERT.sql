CREATE TRIGGER TRG_APPTASKS_PENDING_INSERT
AFTER INSERT
  ON APPTASKS_PENDING
FOR EACH ROW
  declare
begin
  
 -- If ((:new.tbid='WF101') or (:new.tbid='WF201') or (:new.tbid='WF102')  or (:new.tbid='WF202')) then
   If (:new.tbid in ('WF101','WF201','WF102','WF202')) then
   update apparchives set ACTIONNAME= :new.tactname,ACTIONMAN= :new.tuname,ACTIONDATE= :new.tsdate where appseq= :new.tappseq;
  End If;
End trg_apptasks_pending_insert;
/
