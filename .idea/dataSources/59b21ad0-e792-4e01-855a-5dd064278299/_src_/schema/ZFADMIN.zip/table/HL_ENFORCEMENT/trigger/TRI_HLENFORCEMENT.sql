CREATE TRIGGER TRI_HLENFORCEMENT
BEFORE INSERT OR UPDATE OR DELETE
  ON HL_ENFORCEMENT
FOR EACH ROW
  declare
  v_flag date;
begin
     if inserting then
        update tu_proj set gpercent = gpercent+(select count(*) from hl_house_bu where registertype<>2 and sseq =:new.sseq) where pid=:new.pid;
     elsif deleting then
       update tu_proj set gpercent = gpercent-(select count(*) from hl_house_bu where registertype<>2 and sseq =:old.sseq) where pid=:old.pid;
     elsif updating then
        select :new.fdate into v_flag from dual;
        if v_flag is not null then
           update tu_proj set gpercent = gpercent-(select count(*) from hl_house_bu where registertype<>2 and sseq =:new.sseq) where pid=:new.pid;
        end if;
  end if;
end tri_hlenforcement;
/
