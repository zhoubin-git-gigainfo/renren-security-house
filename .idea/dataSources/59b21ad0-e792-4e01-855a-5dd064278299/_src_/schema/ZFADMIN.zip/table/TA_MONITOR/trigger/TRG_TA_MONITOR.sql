CREATE TRIGGER TRG_TA_MONITOR
BEFORE INSERT OR UPDATE
  ON TA_MONITOR
FOR EACH ROW
  DECLARE
strtemp varchar(400);
BEGIN
  strtemp:=','||to_char(:new.userid)||',';
  update appworkflow set appres=strtemp where appseq=:new.appseq;
END;
/
