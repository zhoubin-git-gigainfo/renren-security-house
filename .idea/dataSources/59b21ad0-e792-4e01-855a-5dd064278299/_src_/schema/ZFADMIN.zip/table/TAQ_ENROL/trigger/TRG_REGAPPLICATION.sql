CREATE TRIGGER TRG_REGAPPLICATION
AFTER INSERT
  ON TAQ_ENROL
FOR EACH ROW
  declare
  -- local variables here
  v_bseq   number;
begin
/*
在建工程抵押权注销
预购商品房预告设立
预购商品房预告注销
预购商品房抵押注销
所有权转让预告注销
房地产抵押权预告注销
预购商品房预告设立(担保)
预购商品房抵押设立(担保)
异议注销
*/
  v_bseq:=:new.bseq;
  Insert into ta_datum
       Select :new.sseq,0,sysdate,min(dseq)-1,-1,1,null from ta_datum;
       
end trg_regapplication;
/
