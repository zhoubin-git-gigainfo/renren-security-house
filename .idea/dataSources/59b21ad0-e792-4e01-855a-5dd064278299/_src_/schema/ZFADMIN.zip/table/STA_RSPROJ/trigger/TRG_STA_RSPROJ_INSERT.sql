CREATE TRIGGER TRG_STA_RSPROJ_INSERT
AFTER INSERT
  ON STA_RSPROJ
FOR EACH ROW
  declare
  vm_pid number(15);
begin
  vm_pid := 0;
  select pid into vm_pid from sta_proj where pid = :old.pid;
  if vm_pid = 0 then
    --update
    update sta_proj set (tinvest,bcountarea,groundarea,barea,harea,sarea,oarea,otherarea)=
    (select sum(tinvest),sum(bcountarea),sum(groundarea),sum(barea),sum(harea),sum(sarea),sum(oarea),sum(otherarea) 
    from sta_rsproj where pid=vm_pid) where pid=vm_pid;
  else
    insert into sta_proj (mseq,pid,pdesc,sseq,tinvest,bcountarea,groundarea,barea,harea,sarea,oarea,otherarea,onstate,pstate)
     select co_get_seq('work_id'),pid,pdesc,sseq,tinvest,bcountarea,groundarea,barea,harea,sarea,oarea,otherarea,0,'XMCJ'
      from sta_rsproj where mseq= :old.mseq;
  end if;

end trg_sta_rsproj_insert;
/
