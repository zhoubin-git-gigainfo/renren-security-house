CREATE TRIGGER TRI_APPSEND
AFTER INSERT OR UPDATE
  ON APPSEND
FOR EACH ROW
  declare
  res integer;
  v_flag integer;
  vappseq number;
  vactionname varchar2(200);
  vactionman varchar2(30);
  vactiondate date;
begin
  select appseq into vappseq from ta_bscommon where sseq = :new.sseq;
  select tactname, to_char(wm_concat(tuname)), min(tsdate) into vactionname, vactionman, vactiondate 
  from apptasks_pending where tappseq=vappseq group by tactname;
  select count(*) into res from APPARCHIVES where sseq= :new.sseq;
  if (res=0) then
     insert into APPARCHIVES(sseq,appseq,bseq,bname,appsubject,sdate,ftag,memo,actionname, actionman, actiondate,appptype,appnumber,appdept,appdate,appno, SUPERVISORMEMO
     )
     values(:new.sseq,:new.appseq,:new.bseq,:new.bname,:new.appsubject,:new.appbuild,0,:new.appmemo,vactionname,vactionman,vactiondate,:new.appptype,:new.appnumber,
     :new.appmostly, :new.appbuild, :new.appno, null);
  else
    begin
      select ftag into v_flag from APPARCHIVES where sseq= :new.sseq;    
      if (v_flag=0) then 
        update APPARCHIVES set sseq=:new.sseq,appseq=:new.appseq,bseq=:new.bseq,bname=:new.bname,appsubject=:new.appsubject,sdate=:new.appbuild,ftag=0,memo=:new.appmemo,
        appptype=:new.appptype,appnumber=:new.appnumber, appdept=:new.appmostly, appdate=:new.appbuild, appno=:new.appno,SUPERVISORMEMO=null,
        actionname=vactionname,actionman=vactionman,actiondate=vactiondate
        where  sseq= :new.sseq;
      end if;
    end;
  end if;
end tri_appsend;
/
