CREATE TRIGGER TC_OLDTONEW
AFTER INSERT
  ON TC_OLDNEW
  declare

begin

  --直接写存储过程名称+;

  tc_oldtonew(0,0);

end tc_oldtonew;
/
