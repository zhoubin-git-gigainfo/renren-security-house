CREATE TRIGGER TRI_TA_CXX
BEFORE INSERT
  ON TA_CXX
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.cseq IS NULL or :new.cseq=0 THEN
    select seq_appseq_ids.nextval
    into nextid
    from sys.dual;
    :new.cseq:=nextid;
  end if;
end tri_ta_cxx;
/
