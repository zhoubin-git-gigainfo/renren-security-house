CREATE TRIGGER TRI_TAT_BANKCHECKINFO
BEFORE INSERT
  ON TAT_BANKCHECKINFO
FOR EACH ROW
  declare
  num_paccount varchar(50);
  num_sseq number;
  num_btype number;
  
  max_adate date;
  curdate_count number(5);
  num_ftype number(2);
  num_lpamount number(15,2);
  num_lnamount number(15,2);
  
begin
--select contract_no into num_paccount from tat_data  where nseq= :new.nseq;
--bankaccountname,bankaccount,openbank,ptag,memo,ttagcamount,cdatecamount,cdate,camount,cdate,accdid
--insert into TAT_ACCOUNT_DETAIL(paccount,nseq,btype,ftype,credate,samount,bankno)
--values(num_paccount,:new.nseq,:new.itype,:new.ntag,:new.adate,:new.amount,:new.bankno);  

select contract_no,sseq,btype  into num_paccount,num_sseq,num_btype from tat_data  
where nseq= :new.nseq;

if num_btype<=3 then 
  num_ftype:=1;
elsif num_btype>3 then
  num_ftype:=2;
end if;

update TAT_ACCOUNT_DETAIL set ramount=:new.amount,adate=:new.adate,PTAG=1   where nseq=:new.nseq 
and Prove=:new.Prove and SAMOUNT=:new.amount;
/*
 汇总 ： 银行对帐总金额，入对帐总金额， 本日未对上的=银行入对帐总金额-入对帐总金额，
 上次未对上累计总金额， 未对上累计总金额
 
 SRAMOUNT	NUMBER	Y			本日银行对帐总金额
SCAMOUNT	NUMBER	Y			本日监管机构对帐总金额
FTYPE	NUMBER	Y			
DAMOUNT	NUMBER	Y			本日未对上总金额
PAMOUNT	NUMBER	Y			上次未对上累计总金额
NAMOUNT	NUMBER	Y			未对上累计总金额
 */
 ---取最大日期，
  select  max(adate) into max_adate from TAT_ACCOUNT_sum where FTYPE=num_ftype and  bankno=:new.bankno ;  
 ---最大日期大于对帐日期 ,则数据有问题，返回
  if to_char( max_adate,'yyyy-mm-dd')>to_char( :new.ADATE,'yyyy-mm-dd')  then    
    return;
  end if; 
    
 ---是否已经上传对帐过
 select  count(*) into curdate_count from TAT_ACCOUNT_sum where  
 to_char(adate,'yyyy-mm-dd')=to_char( :new.ADATE,'yyyy-mm-dd') and FTYPE=num_ftype  and  bankno=:new.bankno; 
 --- 是
 if curdate_count>0 then 
 
    update TAT_ACCOUNT_SUM set SRAMOUNT=SRAMOUNT+:new.amount, 
    DAMOUNT=DAMOUNT+:new.amount,NAMOUNT=NAMOUNT+:new.amount
    where   FTYPE=num_ftype and to_char(adate,'yyyy-mm-dd')=to_char( :new.ADATE,'yyyy-mm-dd')
     and  bankno=:new.bankno   
    ; 
---否
   else 
      ---取上次未对上累计总金额，和 未对上累计总金额
      
      if max_adate is not null then
   select  pamount,namount into num_lpamount,num_lnamount from TAT_ACCOUNT_sum 
   where   FTYPE=num_ftype and adate=max_adate  and  bankno=:new.bankno ;
   
   else
     num_lpamount:=0;
     num_lnamount:=0;
   end if;
   

    insert into tat_account_sum(id,adate,SRAMOUNT,SCAMOUNT,ftype,damount,pamount,namount,bankno)
    
    SELECT co_get_seq('ESF_ID') id,:new.ADATE,:new.amount,0,num_ftype,:new.amount
    ,num_lnamount,num_lnamount+:new.amount,:new.bankno
    from dual;
     
 end if;
 
end tri_tat_bankcheckinfo;
/
