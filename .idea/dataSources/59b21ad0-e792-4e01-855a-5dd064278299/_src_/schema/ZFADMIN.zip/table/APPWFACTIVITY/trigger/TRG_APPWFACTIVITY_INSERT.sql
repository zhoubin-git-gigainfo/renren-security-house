CREATE TRIGGER TRG_APPWFACTIVITY_INSERT
BEFORE INSERT
  ON APPWFACTIVITY
FOR EACH ROW
  declare
begin
       Insert into appwfactivity_pending(actseq,actid,wfseq,actmod,actname,assgnmonth,assgnscope,assgnrole,actfunc,actdocfunc, 
actread,acthidden,acttype,actmonth,actprocval,actpool,actpoolval,actfall,actfallval,actstate,actx,acty,actmail,actsms, 
actcalendar,callback,espsend,espaccept,actlimitdate,actionclass,actionmethod,actionarg,actrtx,actpage,actparam,actsmsnotice,actord,actionbackarg)
              values(:new.actseq,:new.actid,:new.wfseq,:new.actmod,:new.actname,:new.assgnmonth,:new.assgnscope,:new.assgnrole,:new.actfunc,:new.actdocfunc, 
:new.actread,:new.acthidden,:new.acttype,:new.actmonth,:new.actprocval,:new.actpool,:new.actpoolval,:new.actfall,:new.actfallval,:new.actstate,:new.actx,:new.acty,:new.actmail,:new.actsms, 
:new.actcalendar,:new.callback,:new.espsend,:new.espaccept,:new.actlimitdate,:new.actionclass,:new.actionmethod,:new.actionarg,:new.actrtx,:new.actpage,:new.actparam,:new.actsmsnotice,:new.actord,:new.actionbackarg);
End trg_appwfactivity_insert;
/
