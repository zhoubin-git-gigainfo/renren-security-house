CREATE TRIGGER TRG_APPWFACTIVITY_UPDATE
AFTER UPDATE
  ON APPWFACTIVITY
FOR EACH ROW
  declare
begin
if (:new.acttype=9) and (:new.actstate=0) then 
   delete appwfactivity_pending where wfseq=:new.wfseq;
else
   update appwfactivity_pending set actseq=:new.actseq,actid=:new.actid,wfseq=:new.wfseq,actmod=:new.actmod,actname=:new.actname,assgnmonth=:new.assgnmonth,assgnscope=:new.assgnscope,assgnrole=:new.assgnrole,actfunc=:new.actfunc,actdocfunc=:new.actdocfunc, 
actread=:new.actread,acthidden=:new.acthidden,acttype=:new.acttype,actmonth=:new.actmonth,actprocval=:new.actprocval,actpool=:new.actpool,actpoolval=:new.actpoolval,actfall=:new.actfall,actfallval=:new.actfallval,actstate=:new.actstate,actx=:new.actx,acty=:new.acty,actmail=:new.actmail,actsms=:new.actsms, 
actcalendar=:new.actcalendar,callback=:new.callback,espsend=:new.espsend,espaccept=:new.espaccept,actlimitdate=:new.actlimitdate,actionclass=:new.actionclass,actionmethod=:new.actionmethod,actionarg=:new.actionarg,actrtx=:new.actrtx,actpage=:new.actpage,actparam=:new.actparam,actsmsnotice=:new.actsmsnotice,actord=:new.actord,actionbackarg=:new.actionbackarg  where actseq=:new.actseq;
end if;
End trg_appwfactivity_update;
/
