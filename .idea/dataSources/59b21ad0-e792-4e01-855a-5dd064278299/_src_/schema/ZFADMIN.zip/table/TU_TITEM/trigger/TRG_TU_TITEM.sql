CREATE TRIGGER TRG_TU_TITEM
BEFORE INSERT OR UPDATE
  ON TU_TITEM
FOR EACH ROW
  declare
  -- local variables here
  v_icode varchar2(50);
  recs integer;
  v_kmid varchar2(50);
begin
  If :new.prjno='04330204' or :new.prjno='04330205' or :new.prjno='04330206' or :new.prjno='07990204' or :new.prjno='07990205' then
     Select distinct ver_name into :new.name From ts_price Where icode=:new.prjno;
  End if;
  select count(*) into recs from ts_titem_cz where KMID=:new.prjno;
  if (recs>0) then
       select kmid into :new.cz_itemname from ts_titem_cz where KMID=:new.prjno;
        else 
       
       :new.cz_itemname:=:new.name;
  end if;
  --If (:new.prjno is not null) then 
   -- If :new.prjno='04330204' or :new.prjno='04330205' or :new.prjno='04330206' or :new.prjno='07990204' or :new.prjno='07990205' then
       --Select distinct ver_name into :new.cz_itemname From ts_price Where icode=:new.prjno;
  --End If;
/*    If :new.prjno='04330204' or :new.prjno='04330205' or :new.prjno='04330206' or :new.prjno='07990204' or :new.prjno='07990204' then
     Select distinct ver_name into :new.cz_itemname From ts_price Where icode=:new.prjno;
  End if;*/
  Return;
end trg_tu_titem;
/
