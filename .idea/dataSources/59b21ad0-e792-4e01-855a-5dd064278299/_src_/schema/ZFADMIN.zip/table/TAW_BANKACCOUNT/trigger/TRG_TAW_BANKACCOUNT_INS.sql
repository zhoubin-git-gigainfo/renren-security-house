CREATE TRIGGER TRG_TAW_BANKACCOUNT_INS
BEFORE INSERT
  ON TAW_BANKACCOUNT
FOR EACH ROW
  declare
v_note varchar2(200);
begin
  if :new.note='' or :new.note is null then
    select note into v_note from taw_payinfo where nseq=:new.nseq and bankno=:new.bankno and bankseq=:new.bankseq;
   :new.note:=v_note;
  
    end if;
  if :new.atype='缴存' then
 update taw_bankaccount set xz_id=9 where nseq=:new.nseq and bankno=:new.bankno and bankseq=:new.bankseq and note=:new.note;
 end if;

end trg_taw_bankaccount_ins;
/
