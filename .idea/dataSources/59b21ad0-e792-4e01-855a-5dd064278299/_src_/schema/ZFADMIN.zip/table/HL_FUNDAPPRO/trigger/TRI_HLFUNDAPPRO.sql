CREATE TRIGGER TRI_HLFUNDAPPRO
BEFORE INSERT OR DELETE
  ON HL_FUNDAPPRO
FOR EACH ROW
  declare
  v_flag date;
begin
     if inserting then
        update tu_proj set percent = percent+(select max(bcsbbfje) from hl_fundappro_bu where sseq =:new.sseq) where pid=:new.pid;
     elsif deleting then
       update tu_proj set percent = percent-(select max(bcsbbfje) from hl_fundappro_bu where  sseq =:old.sseq) where pid=:old.pid;
  end if;
end tri_hlfundappro;
/
