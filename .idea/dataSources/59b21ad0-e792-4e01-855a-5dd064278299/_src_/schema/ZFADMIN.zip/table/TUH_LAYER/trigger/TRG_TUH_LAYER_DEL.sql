CREATE TRIGGER TRG_TUH_LAYER_DEL
BEFORE DELETE
  ON TUH_LAYER
FOR EACH ROW
  declare
 -- local variables here
  v_recs  integer;
  nextid number;
begin

    --如果是修改结束时间为空的将退出
    if not :old.f_date is null then return;  end if;
    delete tu_layer where lid=:old.lid;
/*    Select Count(*) into v_recs From tuh_layer Where f_date is null and  Lid=:new.lid;

    If v_recs=1 Then
       delete tu_layer where lid=:new.lid;
    End if;*/

End trg_tuh_layer_del;
/
