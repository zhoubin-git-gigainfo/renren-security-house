CREATE TRIGGER TRG_TUH_LAYER
BEFORE INSERT OR UPDATE
  ON TUH_LAYER
FOR EACH ROW
  declare
  -- local variables here
  v_recs  integer;
begin
    --如果是修改结束时间为空的将退出
    if not :old.f_date is null then return;  end if;

    Select Count(*) into v_recs From tu_Layer Where Lid=:new.lid;

    If v_recs=1 Then
       Update tu_Layer Set v_date=:new.v_date,ldesc=:new.ldesc,lstru=:new.lstru,
                           luse=:new.luse,barea=:new.barea,bpric=:new.bpric,garea=:new.garea,parea=:new.parea,
                           sarea=:new.sarea,uarea=:new.uarea,issan=:new.issan,slay=:new.slay,lno=:new.lno,
                           bstruname=:new.bstruname,husename=:new.husename,xz_id=:new.xz_id
             Where lid=:new.lid;
    Else
        Insert into tu_Layer
               values(:new.sid,:new.v_date,null,:new.ldesc,
                      :new.lstru,:new.luse,:new.barea,:new.bpric,:new.garea,
                      :new.parea,:new.sarea,:new.uarea,:new.issan,:new.slay,
                      :new.lno,:new.lid,:new.bstruname,:new.husename,:new.xz_id);
    End if;
    --插入多重属性
        Insert into tum_Layer
               values(:new.sid,:new.lid,:new.v_date,:new.f_date,:new.ldesc,
                      :new.lstru,:new.luse,:new.barea,:new.bpric,:new.garea,
                      :new.parea,:new.sarea,:new.uarea,:new.issan,:new.slay,
                      :new.lno,:new.bstruname,:new.husename,:new.xz_id);
end trg_tuh_Layer;
/
