CREATE TRIGGER TRG_TFB_BILL_BU
BEFORE INSERT OR UPDATE
  ON TFB_BILL_BU
FOR EACH ROW
  DECLARE
strtemp varchar(400);
BEGIN
  strtemp:=','||to_char(:new.ruseq)||',';
   update appworkflow set appres=strtemp where appseq=(select distinct appseq from sv_bulists where sseq=:new.sseq);
END;
/
