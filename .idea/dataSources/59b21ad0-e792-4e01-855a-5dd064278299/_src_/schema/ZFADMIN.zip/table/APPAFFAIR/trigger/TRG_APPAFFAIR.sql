CREATE TRIGGER TRG_APPAFFAIR
BEFORE INSERT OR UPDATE
  ON APPAFFAIR
FOR EACH ROW
  DECLARE
strtemp varchar(400);
BEGIN
  strtemp:=','||to_char(:new.appdouserid)||',';
  update appworkflow set appres=strtemp where appseq=:new.appseq;
END;
/
