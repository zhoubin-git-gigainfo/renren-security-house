CREATE TRIGGER TRG_TA_SCALE
BEFORE INSERT OR UPDATE
  ON TA_SCALE
FOR EACH ROW
  DECLARE
strtemp varchar(400);
BEGIN
  strtemp:=','||to_char(:new.mainid)||','||to_char(:new.assistid)||',';
  update appworkflow set appres=strtemp where appseq=:new.appseq;
END;
/
