CREATE TRIGGER TRG_TA_SCALE_INSERT
AFTER INSERT
  ON TA_SCALE
FOR EACH ROW
  DECLARE
strdate varchar(20);
stryhm varchar(60);
BEGIN
   select to_char(sysdate,'yymmdd') into strdate from dual;
   stryhm := to_char(:new.ridgepoleno)||'-'||strdate;
   update TA_SCALE set yhm=stryhm where sseq=:new.sseq;
END;
/
