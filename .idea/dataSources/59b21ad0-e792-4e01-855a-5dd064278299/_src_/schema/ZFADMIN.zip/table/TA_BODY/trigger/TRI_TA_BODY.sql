CREATE TRIGGER TRI_TA_BODY
AFTER INSERT
  ON TA_BODY
FOR EACH ROW
  declare
  counts number;
begin
counts:=0;
  select count(*) into counts  from ta_bscommon where cbid='MB06' and sseq=:new.sseq and sseq like '2015%';
  IF counts>0 THEN
    update tm_corpyearcheck set ycstate=0 where y_date=2015 and md_id not in (
    select md_id  from ta_corpyearcheck where sseq in (
           SELECT sseq FROM TA_BSCOMMON WHERE     sseq like '%2015%' and  bseq=2811006
           )
    );
  end if;
end tri_ta_body;
/
