CREATE TRIGGER TRI_TA_LOG
BEFORE INSERT
  ON TA_LOG
FOR EACH ROW
  declare
  nextid number;
begin
  IF :new.LOGID IS NULL or :new.LOGID=0 THEN
    select CO_SEQ_LOGID.nextval
    into nextid
    from sys.dual;
    :new.LOGID:=nextid;
  end if;
end tri_TA_LOG;
/
