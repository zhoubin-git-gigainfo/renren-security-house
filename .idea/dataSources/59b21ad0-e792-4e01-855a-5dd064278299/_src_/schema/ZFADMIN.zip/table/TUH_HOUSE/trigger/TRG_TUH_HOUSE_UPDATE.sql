CREATE TRIGGER TRG_TUH_HOUSE_UPDATE
BEFORE UPDATE
  ON TUH_HOUSE
FOR EACH ROW
  declare
  -- local variables here
  v_recs  integer;
  nextid number;
begin
  /*生成HSEQ*/
    --如果是修改结束时间为空的将退出
    if not :old.f_date is null then return;  end if;
    Select Count(*) into v_recs From tu_house Where Hid=:new.hid;
    --If ((:new.f_date is not null) and (:old.f_date is null)) Then return;  end if;
    If v_recs=1 Then
       --Select sattribute into :new.sattribute From tu_house Where Hid=:new.hid;
       Update tu_house Set v_date=:new.v_date,metno=:new.metno,hno=:new.hno,hdesc=:new.hdesc,utid=:new.utid,lid=:new.lid,
                           htype=:new.htype,bstru=:new.bstru,huse=:new.huse,
                           barea=:new.barea,garea=:new.garea,parea=:new.parea,
                           sarea=:new.sarea,uarea=:new.uarea,dq=:new.dq,
                           nq=:new.nq,xq=:new.xq,bq=:new.bq,hparent=:new.hparent,
                           hseq=:new.hseq,bpric=:new.bpric,sattribute=:new.sattribute,pactnum=:new.pactnum,plotid=:new.plotid,
                           bstruname=:new.bstruname,husename=:new.husename,rseq=:new.rseq,hkind=:new.hkind,hpoint=:new.hpoint,fx=:new.fx,cx=:new.cx,xz_id=:new.xz_id,ohno=:new.ohno
             Where Hid=:new.hid;
     End if;
    --插入多重属性表
       Insert into tum_house
              values(:new.sid,:new.hid,:new.v_date,:new.f_date,:new.metno,
                     :new.hno,:new.hdesc,:new.utid,:new.lid,:new.htype,:new.bstru,
                     :new.huse,:new.barea,:new.garea,:new.parea,:new.sarea,:new.uarea,
                     :new.dq,:new.nq,:new.xq,:new.bq,:new.hparent,:new.hseq,
                     :new.bpric,:new.sattribute,:new.pactnum,:new.plotid,:new.bstruname,:new.husename,:new.rseq,:new.hkind,:new.hpoint,:new.xz_id,:new.ohno);

End trg_tuh_house_update;
/
