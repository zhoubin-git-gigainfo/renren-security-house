CREATE TRIGGER TRG_TAQ_SDLIST
BEFORE INSERT OR UPDATE
  ON TAQ_SDLIST
FOR EACH ROW
  declare
  -- local variables here
begin
  :new.buseid:=nvl(:new.buseid,'110');
  If :new.buseid!=:old.buseid Then
     Update tu_house Set huse=to_number(:new.buseid) Where hid=:new.sd_id;
  End if;
end trg_taq_sdlist;
/
