CREATE TRIGGER TRI_TAT_ACCOUNT_DETAIL
BEFORE UPDATE
  ON TAT_ACCOUNT_DETAIL
FOR EACH ROW
  declare
  num_paccount number;
   max_adate date;
  curdate_count number(5);
  num_ftype number(2);
  num_lpamount number(15,2);
  num_lnamount number(15,2);
begin
select contract_no into num_paccount from tat_data  where nseq= :new.nseq;
--bankaccountname,bankaccount,openbank,ptag,memo,ttagcamount,cdatecamount,cdate,camount,cdate,accdid
/*insert into TAT_ACCOUNT_DETAIL(paccount,nseq,btype,ftype,credate,samount,bankno)
values(num_paccount,:new.nseq,:new.itype,:new.ntag,:new.adate,:new.amount,:new.bankno);  */

 
if (:old.TTAG=0 or :old.TTAG is null) and :new.ttag=1 then
  
 
/*

select  max(adate) into max_adate from TAT_ACCOUNT_sum where FTYPE=:new.ftype 
 and to_char(adate,'yyyy-mm-dd')<to_char( :new.ADATE,'yyyy-mm-dd')  ;  
 
  select  pamount,namount into num_lpamount,num_lnamount from TAT_ACCOUNT_sum 
   where   FTYPE=num_ftype and adate=max_adate ;

ID	NUMBER	Y			
ADATE	DATE	Y			
SRAMOUNT	NUMBER	Y			本日银行对帐总金额
SCAMOUNT	NUMBER	Y			本日监管机构对帐总金额
FTYPE	NUMBER	Y			
DAMOUNT	NUMBER	Y			本日未对上总金额
PAMOUNT	NUMBER	Y			上次未对上累计总金额
NAMOUNT	NUMBER	Y			未对上累计总金额

*/

 update TAT_ACCOUNT_SUM set SCAMOUNT=SCAMOUNT+:new.CAMOUNT, 
    DAMOUNT=DAMOUNT-:new.CAMOUNT
    
    ,namount=NAMOUNT-:new.CAMOUNT
  where   FTYPE=:new.FTYPE and to_char(adate,'yyyy-mm-dd')=to_char( :new.ADATE,'yyyy-mm-dd'); 

end if;

end tri_tat_account_detail;
/
