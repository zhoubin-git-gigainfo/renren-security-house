CREATE TRIGGER TEST_TRIGGER
AFTER INSERT
  ON DEPT2
  declare
  -- local variables here
begin
    update dept2 set deptno=19 where deptno=15;
    
end Test_trigger;
/
