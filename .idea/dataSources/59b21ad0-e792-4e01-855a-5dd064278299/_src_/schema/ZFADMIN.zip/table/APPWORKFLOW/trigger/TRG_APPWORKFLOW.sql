CREATE TRIGGER TRG_APPWORKFLOW
BEFORE INSERT OR UPDATE
  ON APPWORKFLOW
FOR EACH ROW
  DECLARE Recs Integer;
n_wfseq Number;
BEGIN
 --更新完成时间
/* if ((:new.wfstate=0) and (:old.wfstate=1)) then
 begin
    --update APPWORKFLOW set wfinishdate=sysdate() where appseq=:new.WFSEQ;
    --select wfseq into n_wfseq  from appworkflow where relation<>0;
    --if (n_wfseq is not null) then 
      update APPWORKFLOW set ismonitor=2  where  appseq=:new.appseq and ismonitor=1 and relation<>0;
   --end if;
 end;
 end if;*/
 --如果废弃业务，更新待监察业务列表
 if ((:new.wfstate=-1) and (:old.wfstate=1)) then
 begin
      --update APPWORKFLOW set ismonitor=2  where  appseq=n_wfseq and ismonitor=1 and relation<>0;
   --end if;
   update appsupervise set sstate=-1 where appseq=:new.appseq;
 end;
 end if; 
/* Select Count(*) into Recs From APP_DAITEM Where APPSEQ=:new.WFSEQ;
 If Recs=0 Then
 Insert into APP_DAITEM (APPSEQ,ITEMTYPE) VALUES(:new.WFSEQ,:new.WFNAME) ;
 Else
 Update APP_DAITEM set itemname=:new.APPSUBJECT where APPSEQ=:new.WFSEQ;
 End if;

 If :new.wfstate=-1 then
 Delete APP_DAITEM Where APPSEQ=:new.wfseq ;
 End if;*/
 --Delete appmycalend Where Fromapp=:new.wfseq ;

/*设置流程的状态
-1:废弃,1:在办,0:完结*/
--select count(*) into Recs from appdefine where apptype=1;
--if Recs=0 then
  --co_Set_State(:new.WFSEQ,:new.WFSTATE,:new.APPDATE,0);
--end if;
/*完成*/


END;
/
