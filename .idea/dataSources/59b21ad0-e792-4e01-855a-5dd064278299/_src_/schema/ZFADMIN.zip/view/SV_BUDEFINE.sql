CREATE VIEW SV_BUDEFINE AS select 0 Type,bseq,bname,t2.str_1 stcode,apptype from appdefine t1,table(co_get_split(t1.needs)) t2
 where btype=8 or btype=20
union all
select 1,bseq,bname,t2.str_1,apptype from appdefine t1,table(co_get_split(t1.unneeds))
 t2 where btype=8 or btype=20
/
