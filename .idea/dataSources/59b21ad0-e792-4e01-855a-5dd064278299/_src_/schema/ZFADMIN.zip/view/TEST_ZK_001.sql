CREATE VIEW TEST_ZK_001 AS select aid,pdesc,pid from(
select max(a3.nid) aid,a0.pdesc,a0.pid
from zfadmin.tu_proj a0,zfadmin.tu_pubproj a1,zfadmin.tu_aitem a2,zfadmin.tu_attech a3,
(select a0.pid,max(a2.p_date) rdate from ZFADMIN.tu_proj a0,ZFADMIN.to_cration a1,ZFADMIN.tu_prjcard a2
where a1.f_date is null and a1.rtype=1 and a2.ic_type=90052 and a2.f_date is null
and a0.pid=a1.cid1 and a1.cid2=a2.card_id and a2.p_date is not null group by a0.pid) a4
where a0.pid=a1.pid and a1.lpstate=1 and a2.oid=a0.pid and a2.atype=1183126 and a2.aid=a3.aid and a0.pid=a4.pid(+)
group by a0.pdesc,a0.pid,a4.rdate,a1.fb_xh order by a1.fb_xh asc,a4.rdate desc)
--where rownum<19


/
