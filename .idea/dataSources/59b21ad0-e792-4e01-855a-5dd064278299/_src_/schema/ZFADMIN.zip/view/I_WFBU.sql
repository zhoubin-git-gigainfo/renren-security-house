CREATE VIEW I_WFBU AS select sseq,appseq  from sv_bulists


/
