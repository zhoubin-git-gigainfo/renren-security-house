CREATE VIEW TU_STATE AS Select sid,wfseq,bid,v_date,stype,st_name,droits as MDList,tprice,pprice from to_state Where modality=0


/
