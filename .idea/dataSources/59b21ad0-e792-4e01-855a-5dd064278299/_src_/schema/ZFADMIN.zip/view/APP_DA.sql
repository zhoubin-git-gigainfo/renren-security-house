CREATE VIEW APP_DA AS Select t2.wfname,t1.appcredept,t1.appnumber,t1.appsubject,to_char(t1.appcredate,'yyyy-mm-dd') credate,t3.aurl
  From appsend t1,appworkflow t2,appattech t3
 Where t1.appseq=t2.wfseq and t1.appseq=t3.tseq(+) and t3.atype=1 and t2.wfstate=0
union
Select t2.wfname,t1.appcredept,t1.appnumber,t1.appsubject,to_char(t1.appcredate,'yyyy-mm-dd') credate,t3.aurl
  From appreceive t1,appworkflow t2,appattech t3
 Where t1.appseq=t2.wfseq and t1.appseq=t3.tseq(+) and t3.atype=1 and t2.wfstate=0
union
Select t2.wfname,t1.appcredept,null,t1.appsubject,to_char(t1.appcredate,'yyyy-mm-dd') credate,t3.aurl
  From appreport t1,appworkflow t2,appattech t3
 Where t1.appseq=t2.wfseq and t1.appseq=t3.tseq(+) and t3.atype=1 and t2.wfstate=0


/
