CREATE VIEW GF_RENTVIEW_ALL AS select u1.sseq,u1.yymm,u1.byys-nvl(u3.byjm,0) byys,u2.bysh,u2.notesno,u2.memo,u2.ftype,u5.ycjy,u6.ymjy from
(select sseq,yymm,sum(ffee) byys  from u_account where vflag=0 and ftype=1 group by sseq,yymm) u1,
(select sseq,yymm,notesno,memo,ftype,sum(sfee) bysh  from u_account where vflag=0 and ftype=3 group by sseq,yymm,notesno,memo,ftype) u2,
(select sseq,yymm,sum(sfee) byjm   from u_account where vflag=0 and ftype=5 group by sseq,yymm) u3,
(select sseq,yymm,sum(sfee) ycjy from u_accsum where vflag=0 and ftype=11 group by sseq,yymm) u5,
(select sseq,yymm,sum(sfee) ymjy from u_accsum where vflag=0 and ftype=12 group by sseq,yymm) u6
where u1.sseq=u3.sseq(+) and u1.yymm=to_number(u3.yymm(+)) and u1.sseq=u2.sseq(+) and u1.yymm=to_number(u2.yymm(+))
and u1.sseq=u5.sseq and u1.yymm=to_number(u5.yymm) and u1.sseq=u6.sseq and u1.yymm=to_number(u6.yymm)
union
select u1.sseq,u1.yymm,u1.byys-nvl(u3.byjm,0) byys,u2.bysh,'' notesno,u2.memo,u2.ftype,u5.ycjy,u6.ymjy from
(select sseq,yymm,sum(ffee) byys  from u_account where vflag=0 and ftype=1 group by sseq,yymm) u1,
(select sseq,yymm,memo,ftype,sum(sfee) bysh  from u_account where vflag=0 and ftype=6 group by sseq,yymm,memo,ftype) u2,
(select sseq,yymm,sum(sfee) byjm   from u_account where vflag=0 and ftype=5 group by sseq,yymm) u3,
(select sseq,yymm,sum(sfee) ycjy from u_accsum where vflag=0 and ftype=11 group by sseq,yymm) u5,
(select sseq,yymm,sum(sfee) ymjy from u_accsum where vflag=0 and ftype=12 group by sseq,yymm) u6
where u1.sseq=u3.sseq(+) and u1.yymm=to_number(u3.yymm(+)) and u1.sseq=u2.sseq and u1.yymm=to_number(u2.yymm)
and u1.sseq=u5.sseq and u1.yymm=to_number(u5.yymm) and u1.sseq=u6.sseq and u1.yymm=to_number(u6.yymm)


/
