CREATE VIEW SV_BUTOTALSDLIST AS select sseq,sd_id hid,barea,0 huseid,husename from taq_sdlist
union
---测量
select sseq,sd_id hid,barea,0 huseid,buse from tac_sdlist
union
---预售许可
select sseq,hid,barea,huseid,huse from tas_changepslist
union
select sseq,hseq,to_number(jzmj),useid,yt from ta_hxx
union
--进度管理
select sseq,t2.hid,t2.barea,0 huseid,t2.husename  from tas_bldgschedule t1,tu_house t2
where t1.sid=t2.sid
union
--资本金监控
select sseq,t2.hid,t2.barea,0 huseid,t2.husename  from tas_housemonitor t1,tu_house t2
where t1.sid=t2.sid
union
--联合验收、性能鉴定
select sseq,t2.hid,t2.barea,0 huseid,t2.husename  from tas_bldg t1,tu_house t2
where t1.sid=t2.sid
/
