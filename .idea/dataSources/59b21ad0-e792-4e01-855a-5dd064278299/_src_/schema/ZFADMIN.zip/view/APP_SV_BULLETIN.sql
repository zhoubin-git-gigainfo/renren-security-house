CREATE VIEW APP_SV_BULLETIN AS select b.appseq,b.sseq,(select cddisc from appcode where cdid=b.appcatlog) btype,b.appsubject,b.appcredate,b.appshowdate,b.appinvalidate,
b.appactsdate,b.appactedate,to_char(b.appauthor) appauthor,b.appname,b.appcredept,b.appreaders,b.appmemo appcontent
from appbulletin b where b.appcatlog in (select cdid from appcode where cdparent = 1737000) and appstate ='1'
union all
select s.appseq,s.sseq,'会议通知' btype,s.appsubject,s.appcredate,s.appshowdate,s.appinvalidate,
s.appstart appactsdate,s.append appactedate,to_char(s.appauthor) appauthor,s.appname,s.appcredept,s.appreaders ,s.appcontent appcontent
 from appsynod s where s.type in(2000019,2000128) and appstate=1
 order by appshowdate desc


/
