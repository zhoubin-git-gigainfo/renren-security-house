CREATE VIEW SV_COMP_PROJ_BLDG AS select -oseq id,oname name,-1 parentid,3 ttype from sysorgan
union
select PID id,pdesc name,bcompid parentid,2 ttype  from tu_proj
union
select tu_bldg.sid id, lname name,tu_proj.pid parentid,1 ttype  from tu_proj,tu_pbldg,tu_bldg where tu_proj.pid=tu_pbldg.pid and tu_pbldg.sid=tu_bldg.sid


/
