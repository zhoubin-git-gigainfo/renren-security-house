CREATE VIEW GF_NOTESNO_ALL AS select mseq,osseq,yymm,notesno from u_tasks where rtype=1 and notesno is not null
union
select distinct mseq,osseq,yymm,notesno from ua_tasks where rtype=0 and notesno is not null


/
