CREATE VIEW TU_ATTECH AS select  t1.NID,t1.CDATE,t1.FOLE,t1.FPATH,t1.FNAME,t1.AID,t1.FANAME,t1.ORDERNUM,t1.TAG,t1.TID,t1.OPTYPE,
t1.FDATE,t1.XZ_ID from tu_attech_BS t1,tu_attechr t2
where t1.nid=t2.nid and t2.flag=1
/
