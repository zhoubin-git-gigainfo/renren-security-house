CREATE VIEW V_TEST AS select oseq from a1 union select bid from a


/
