CREATE VIEW STA_PROVOLIST_V AS select  t1."MSEQ",t1."SSEQ",t1."HID",extract(year from t1.v_date)*100+extract(month from t1.v_date),t1."V_DATE",t1."STYPE",t1."BAREA",t1."SG_AREA",
t1."PAREA",t1."HUSE",t1."HKIND",t1."UPPRICE",t1."SG_UPRICE",t1."HTYPE",t1."BSTRU",t1."DECORATIONID",
t1."SPRICE",t1."STAG",t1."F_DATE",t1."XZ_ID",t1."BSTATE",t1."BTAG",t2.bseq,t2.PID,t2.mid,t2.lid,t1.sg_areaid,t1.sg_upriceid ,
t1.useid

 from sta_provolist_incr t1 ,sta_provsum_incr t2
   where t1.sseq=t2.sseq
  -- and t1.btag=t2.btag
   and t2.btag <>'00'
/
