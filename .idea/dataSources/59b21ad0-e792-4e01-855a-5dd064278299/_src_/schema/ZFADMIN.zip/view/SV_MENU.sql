CREATE VIEW SV_MENU AS Select  distinct USEQ,USERID,UNAME,UPWD,FSEQ,FID,FNAME,FTYPE,FPARENT,FPARAM,IMAGE,FPUBLC,mobiletag,validtag,fmemo from (
SELECT SysUser.USEQ, SysUser.userid, SysUser.UNAME, SysUser.UPWD,
      SysOrgan.OSEQ, SysOrgan.ONAME, SysFunction.FSEQ,
      SysFunction.FID, SysFunction.FNAME, SysFunction.FTYPE,
      SysFunction.FPARENT, SysFunction.FPARAM,SysFunction.IMAGE,
      SysFunction.FPUBLC,sysfunction.mobiletag,sysfunction.validtag,sysfunction.fmemo
FROM SysFunction ,SysOrgan,SysUserOrg,SysUser,
SysOrgFunc where SysFunction.FSEQ = SysOrgFunc.FSEQ and  SysOrgFunc.OSEQ = SysOrgan.OSEQ and
 SysOrgFunc.OSEQ = SysUserOrg.OSEQ and  SysUserOrg.USEQ = SysUser.Useq
UNION
SELECT -1 USEQ, '' "UID", '' UNAME, '' UPWD, CAST('-1' AS NUMBER(10,0)) OSEQ, '*' ONAME,
      FSEQ,FID,FNAME,FTYPE,FPARENT,FPARAM,IMAGE,FPUBLC,mobiletag,sysfunction.validtag,fmemo FROM SysFunction
WHERE (FPUBLC = 1) AND(FTYPE = 1)  )
/
