CREATE VIEW SV_BUORGAN AS SELECT oseq oseq_id,ocode,oname oseq_oname, isleaf OSEQ_ISEAF,co_get_spelev(dimid_path,1)  oseq_l1,
 co_get_spelev(dimid_path,2)  oseq_l2,co_get_spelev(dimid_path,3)  oseq_l3,lev

    FROM (
    select oseq  ,oname  ,oparent  ,SYS_CONNECT_BY_PATH (oname, '/') dimname_path,
     SYS_CONNECT_BY_PATH (oseq, '/')||'/' dimid_path,connect_by_isleaf isleaf,level lev,otype,ocode
     from ( select * from SYSORGAN where otype not in(4)
 and vr=1 and ocode like '100%' ) where vr=1
     --and connect_by_isleaf=1
     and ocode like '100%'
Start with oparent=-1 CONNECT BY oparent=prior oseq
order by ocode
)
/
