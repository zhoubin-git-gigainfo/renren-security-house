CREATE VIEW SV_AGENT AS select sseq,maintypeid,agentname from ta_agent
union
select sseq,apptype,md_name from ta_mainbody
/
