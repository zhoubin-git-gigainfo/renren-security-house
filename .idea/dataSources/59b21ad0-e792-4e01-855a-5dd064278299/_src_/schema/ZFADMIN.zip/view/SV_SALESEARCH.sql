CREATE VIEW SV_SALESEARCH AS select pid,bcompid,compdesc,pdesc,state,count(*) scount,sstate from (
select '在办' as state,d.pid,d.pdesc,a.title,a.contract_no,a.sseq,d.bcompid,compdesc,
(case when (trunc(sysdate)>trunc(createdate,'dd')+2) then  '超时' else '正常' end) as sstate from sales_contract a,taq_sdlist b,to_state c,tu_proj d,tu_pbldg e,tu_house f,apptasks g where g.tappseq=a.appseq and  a.sseq=b.sseq
and b.sd_id=c.sid and d.pid=e.pid and e.sid=f.sid and b.sd_id=f.hid and a.sseq=c.bid and c.modality=1 and c.stype='33'
union
select '已签' as state,d.pid,d.pdesc,a.title,a.contract_no,a.sseq,d.bcompid,compdesc,
(case when (trunc(sysdate)>trunc(c.v_date,'dd')+3) then  '超时' else '正常' end) as sstate from sales_contract a,taq_sdlist b,to_state c,tu_proj d,tu_pbldg e,tu_house f,apptasks g where g.tappseq=a.appseq and a.sseq=b.sseq
and b.sd_id=c.sid and d.pid=e.pid and e.sid=f.sid and b.sd_id=f.hid and a.sseq=c.bid and c.modality=0 and c.stype='32'
union
select '已备' as state,d.pid,d.pdesc,a.title,a.contract_no,a.sseq,d.bcompid,compdesc,'正常' as sstate from sales_contract a,taq_sdlist b,to_state c,tu_proj d,tu_pbldg e,tu_house f where a.sseq=b.sseq
and b.sd_id=c.sid and d.pid=e.pid and e.sid=f.sid and b.sd_id=f.hid and a.sseq=c.bid and c.modality=0 and c.stype='33' )
group by pid,bcompid,compdesc,pdesc,state,sstate
order by compdesc,pdesc


/
