CREATE VIEW TAW_FEE_INIT AS select distinct paccount,payer,t1.sid, sum(ftype*bamount) bamount from to_state t1,to_relation t2,taw_fee t3 where
            t1.sid=t2.sid and t1.stype='64' and t2.sid=t3.paccount and ptype=1
            and t1.modality=0 and t1.f_date is null
            group by  paccount,t1.sid,payer


/
