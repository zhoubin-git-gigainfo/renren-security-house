CREATE VIEW MV_MARKETSELL AS select s.sid,s.bid,s.stype,s.v_date,s.f_date,h.v_date as hv_date,h.f_date as hf_date,h.metno,h.sid as dsid,h.barea,h.bstru,h.huse,s.pprice,h.distid,h.ddesc,h.lname,h.pid,--p.pid,b.distid,h.bstru,h.huse,s.pprice,
decode(lag(h.barea,1,-1) over(PARTITION BY s.sid,s.bid order by h.v_date ),-1,decode(sign(s.v_date-h.v_date),1,s.v_date,-1,h.v_date,0,s.v_date),h.v_date) as xdate,
decode(lead(h.barea,1,-1) over(PARTITION BY s.sid,s.bid order by h.v_date ),-1,decode(sign(nvl(s.f_date,to_date('9999-12-31','yyyy-mm-dd'))-nvl(h.f_date,to_date('9999-12-31','yyyy-mm-dd'))),1,h.f_date,-1,s.f_date,0,s.f_date),h.f_date) as ndate
 from to_state s,
 (select m.hid,m.v_date,m.f_date,m.metno,m.sid,m.barea,m.bstru,m.huse,b.distid,b.ddesc,b.lname,p.pid from
          tuh_house m
          ,tuh_bldg b,tu_pbldg p where m.sid=b.sid(+) and m.sid=p.sid(+)
           and to_char(b.v_date,'YYYY-MM-DD hh24:mi')<=to_char(m.v_date,'YYYY-MM-DD hh24:mi')
          and nvl(b.f_date,to_date('9999-12-31','yyyy-mm-dd'))>m.v_date)
           h
where s.sid=h.hid and (s.modality='0' or s.modality='9') and s.stype='33' -- and s.bid>2009100000 and h.sid=p.sid(+) and h.sid=b.sid and h.hid=r.hid
and nvl(h.f_date,to_date('9999-12-31','yyyy-mm-dd'))>s.v_date
and h.v_date<nvl(s.f_date,to_date('9999-12-31','yyyy-mm-dd')) --and (s.sid=200001210651 or s.sid=  200001227960 )s.sid=200001127311
 order by s.v_date,h.v_date
/
