CREATE VIEW SV_MONITOR AS select 1 as ord,101 as id,'在监察事务' as bname,-1 as parentid,'0' as bid from appdefine where rownum=1
union  select distinct 1 as ord,b.bseq as id,bname,101 as parentid,bid from appdefine b, sysorgbu a,sysuserorg c where a.bseq=b.bseq and a.oseq=c.oseq and c.useq=212061
union  select 0 as ord,201 as id,'待监察事务' as bname,-1 as parentid,'0' as bid  from appdefine where rownum=1
union  select distinct 0 as ord,b.bseq as id,bname,201 as parentid,bid from appdefine b, sysorgbu a,sysuserorg c where a.bseq=b.bseq and a.oseq=c.oseq and c.useq=212061
union  select 2 as ord,301 as id,'已监察事务' as bname,-1 as parentid,'0' as bid  from appdefine where rownum=1
union  select distinct 2 as ord,b.bseq as id,bname,301 as parentid,bid from appdefine b, sysorgbu a,sysuserorg c where a.bseq=b.bseq and a.oseq=c.oseq and c.useq=212061


/
