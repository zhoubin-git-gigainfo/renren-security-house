CREATE VIEW SV_APPTYPE AS select "FSEQ","FNAME","FPARENT","FPATH","TORDER","BSEQ","BID" from (
select fseq,fname,fparent, SYS_CONNECT_BY_PATH (fseq, '/')  fpath ,torder from (
select ''fid,  1  ftype,tname fname ,tparent fparent,  tseq fseq ,torder
 from ts_type
union
select bid, btype ftype,bname,     b.tseq,c.bseq ,a.torder
  from appdefine c,ts_type a,ts_type_app b  where a.tseq=b.tseq and b.bseq=c.bseq

  ) Start with fseq IN ( select tseq from ts_type where stype=1 ) CONNECT BY fparent=prior fseq order by fpath) t1
  , (select bseq ,bid from appdefine) t2 where t1.fseq=t2.bseq


/
