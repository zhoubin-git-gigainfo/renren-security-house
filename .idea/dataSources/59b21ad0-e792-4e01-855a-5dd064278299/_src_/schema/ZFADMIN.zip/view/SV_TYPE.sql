CREATE VIEW SV_TYPE AS select distinct t1.fseq,t1.fname,t2.tseq parentid,t2.tname,t1.torder,fpath  from
(

select fseq,fname,fparent, SYS_CONNECT_BY_PATH (fname, '/')  fpath ,torder from (
select ''fid,''fparam,'1' ftype,tname fname ,tparent fparent,  tseq fseq ,torder
 from ts_type  where  ttype=1 and ismemu=0
union
select fid,  fparam,   ftype,  fname,     b.tseq,c.fseq ,a.torder
  from sysfunction c,ts_type a,ts_type_func b  where a.tseq=b.tseq and b.fseq=c.fseq and ttype=1

  ) Start with fseq IN(  select distinct tseq from ts_type_func ) CONNECT BY fparent=prior fseq order by fpath

   )  t1
  , (   select tseq,tname from ts_type where tparent<>-1 and ismemu=0  order by tseq) t2 where
  instr(t1.fpath,  '/'||t2.tname||'/' )>0 order by t1.torder,t1.fpath


/
