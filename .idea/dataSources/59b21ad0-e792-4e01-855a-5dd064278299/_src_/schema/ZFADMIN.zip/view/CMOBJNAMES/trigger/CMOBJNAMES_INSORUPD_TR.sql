-- Cannot generate trigger CMOBJNAMES_INSORUPD_TR: the table is unknown
/
