CREATE VIEW SV_STA_STOCK_M AS select s_month as h_month,xz_id,a_id,huse as useid,bstru,sg_area,htype,sg_stime,hcount,barea from sta_stock_m
/
