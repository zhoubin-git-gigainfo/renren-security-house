CREATE VIEW SV_TM_CORP_DETAIL AS select a.md_id,a.md_name,a.md_tel,a.md_raddr ,a.md_atype,a.mp_mobil,a.mo_type,nvl(a1.mo_kind,a2.mo_kind) mo_kind,a1.ic_no org_no,a2.ic_no license_no,
a3.ic_no apti_no,a3.qualitype,a3.qualigrade,to_char(a3.md_issdate,'yyyy-mm-dd') md_issdate,to_char(a3.s_date,'yyyy-mm-dd')  s_date,to_char(a3.e_date,'yyyy-mm-dd') e_date,a3.md_regcapital,a4.emps,
a5.md_name boss_name,a5.md_tel boss_tel,a6.md_name manager_name,a6.md_tel manager_tel,a7.md_name link_name,a7.md_tel link_tel,
a8.ycstate,a9.rank_level
from tm_body a,(select md_id,ic_no,mo_kind  from tm_mbodycard where md_type=1 and f_date is null and ic_type=54131) a1,
(select md_id,ic_no,mo_kind  from tm_mbodycard where md_type=1 and f_date is null and ic_type=54132) a2,
(select md_id,ic_no,b.qualitype,b.qualigrade,b.md_issdate,b.s_date,b.e_date,b.md_regcapital
  from tm_mbodycard b where md_type=1 and f_date is null and ic_type=90008) a3,
  (select mo_id,count(distinct mp_id) emps from tm_orgman where f_date is null group by mo_id) a4,
  (select a.mo_id,b.md_id,b.md_name,nvl(b.mp_mobil,b.md_tel) md_tel  from tm_orgman a,tm_body b where a.f_date is null and instr(md_postion,'法定代表人')>0
  and b.f_date is null and b.md_type=2 and a.mp_id=b.md_id) a5,
   (select a.mo_id,concatstr(b.md_name) md_name,concatstr(nvl(b.mp_mobil,b.md_tel)) md_tel  from tm_orgman a,tm_body b where a.f_date is null and (instr(md_postion,'总经理')=1 or instr(md_postion,',总经理')=1)
  and b.f_date is null and b.md_type=2 and a.mp_id=b.md_id group by a.mo_id) a6,
     (select a.mo_id,concatstr(b.md_name) md_name,concatstr(nvl(b.mp_mobil,b.md_tel)) md_tel  from tm_orgman a,tm_body b where a.f_date is null and instr(md_postion,'联系人')>0
  and b.f_date is null and b.md_type=2 and a.mp_id=b.md_id group by a.mo_id) a7,
  (select md_id,y_date||'年度:'||decode(nvl(ycstate,0),0,'未分配',1,'已分配',2,'初审结果',3,'审批中','最终结果') ycstate,mo_type
  from (select md_id,ycstate,mo_type,y_date,row_number() over (partition by md_id order by ycstate desc ) dd  from tm_corpyearcheck
  where y_date=to_char(add_months(sysdate,-12),'yyyy')) where dd=1 ) a8,
  (select md_id,max(rank_year||'年度:'||rank_level) over (partition by md_id ) rank_level  from tm_credit_rank) a9
where a.ismart=1 and md_type=1 and f_date is null and a.md_id=a1.md_id(+)  and a.md_id=a2.md_id(+)  and a.md_id=a3.md_id(+)
and a.md_id=a4.mo_id(+)  and a.md_id=a5.mo_id(+)  and a.md_id=a6.mo_id(+)  and a.md_id=a7.mo_id(+) and a.md_id=a8.md_id(+) and a.md_id=a9.md_id(+)
/
