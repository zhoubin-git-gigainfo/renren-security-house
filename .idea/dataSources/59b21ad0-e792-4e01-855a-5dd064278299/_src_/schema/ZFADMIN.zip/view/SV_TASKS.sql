CREATE VIEW SV_TASKS AS select a.WORKDAY,sseq,
SF_Get_TASKS(a.WORKDAY,b.startdate,b.enddate,'AM') as AMT,
SF_Get_TASKS(a.WORKDAY,b.startdate,b.enddate,'PM') as PMT
from SYSCALENDAR a,ta_scale b
Where b.bseq=22005 and a.WORKDAY between to_date(to_char(b.startdate,'yyyy/mm/dd'),'yyyy/mm/dd') and to_date(to_char(b.enddate,'yyyy/mm/dd'),'yyyy/mm/dd')


/
