CREATE VIEW SV_PROJ AS select p2.pid, p2.pdesc, p2.compdesc,p2.plocal,p2.lid,p2.pkname,p2.groundarea,p2.barea,p2.tinvest,p2.gpercent,p2.percent,
p2.startdate,p3.tmod,p4.pgid,(select count(sid) from tu_pbldg t1 where t1.pid=p1.pid ) as zd,(select count(hid) from tu_pbldg t1,tu_house t2 where t1.pid=p1.pid and t1.sid=t2.sid ) as zh
 from tu_proj p1,tas_proj p2,tas_tandacard p3,tas_landcard p4 where p1.pid=p2.pid and p2.pid=p3.pid(+) and p2.pid=p4.pid(+)


/
