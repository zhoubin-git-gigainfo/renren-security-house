CREATE VIEW I_SMSMESSAGE AS select ruid,runame,rmobile,message,stime,sendtag from sysmessage where suid=100009199548
/
