CREATE VIEW SV_TTTT AS Select t1.appseq,t1.sseq,t2.tedate from sv_bulists t1,apptasks t2
 where t1.appseq=t2.tappseq and
       t1.bseq=1903000 and tstate=0 and tactname='签定合同'


/
