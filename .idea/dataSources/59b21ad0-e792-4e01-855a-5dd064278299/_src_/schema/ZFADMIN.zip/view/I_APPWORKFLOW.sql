CREATE VIEW I_APPWORKFLOW AS select  wfseq,wfid,wfname,wfstate,wfadmin,appbid,appseq,appname,appcomp,appdept,actname,appsubject,
hasapp,maxrut,appres,wflimitdate,isurge,ismonitor,relation,apparchives,wplandate,wfinishdate,wfmid,appdate,
orgid,appfileno,f_date,owfseq,xz_id,accdate,acc_commitdate,finishdate
from appworkflow
/
