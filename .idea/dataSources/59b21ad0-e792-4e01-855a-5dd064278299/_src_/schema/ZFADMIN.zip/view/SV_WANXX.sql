CREATE VIEW SV_WANXX AS select "MESSAGE","COMPID","APPSEQ" from
(select tu_proj.pdesc||b.bdesc||'预售申报已批('||d.cdno||')' as message, t.applycompanyid as compid,appseq
    from tas_pslist t,tu_card d,tu_bldg b,tu_pbldg,tu_proj where d.bid=t.sseq and t.sid=b.sid
     and b.sid=tu_pbldg.sid and tu_pbldg.pid=tu_proj.pid
  UNION
  select tas_proj.pdesc||'项目已备案' as message,tas_proj.bcompid as compid,appseq from tas_proj,appworkflow where sseq=appseq and appworkflow.wfstate=0
  UNION
   select   t3.lname||bname||'预售许可信息申报不实，将启动不良信用信息征集。',t1.appcredeptid,t1.appseq
    from ta_bscommon t1,   tu_pplan t2,tu_bldgschedule t3
  where  t1.sseq=t2.sseq and t2.sseq=t3.sseq
  and t3.AFLOORS<LNUM
  and t1.state=9
 and t1.bseq=100010153995
 /*and not exists(
 select 1 from to_state t4 where t3.sid=t4.sid
 and t4.stype='XMZDGC' )*/


 union
 select   t3.lname||bname||'审批通过。' ,t1.appcredeptid,t1.appseq from ta_bscommon t1,   tu_pplan t2,tu_bldgschedule t3
  where  t1.sseq=t2.sseq and t2.sseq=t3.sseq
  and t3.afloors>=t3.psfloors
  and t1.state=9
 and t1.bseq=100010153995

 union

    select  to_char( t2.pdesc||(
   select wm_concat(t5.bdesc) from tu_bldg t5 ,tas_bldgschedule t3 where t5.sid=t3.sid
   and t3.sseq=t2.sseq
   ) ||t2.filldate ||'月未按时报送进度信息，将启动不良信用信息征集。') title ,t1.appcredeptid,t1.appseq from ta_bscommon t1,
    tas_pplan t2, ta_credit_detail t4
  where  t1.sseq=t2.sseq
 and  t2.sseq=t4.osseq
  and t1.state=11
 and t1.bseq=100000003017

  )order by appseq desc
/
