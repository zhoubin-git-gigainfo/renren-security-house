CREATE VIEW DIM_HUSE AS select id,name,parentid,'所有用途' as parentname from ts_code where parentid=998
/
