CREATE VIEW I_USER AS select useq,userid,uname,umobil,umail from sysuser
/
