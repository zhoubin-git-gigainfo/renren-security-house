CREATE VIEW VT_ALLBS AS Select bu.vdate,bu.yy,bu.yq,bu.ym,bu.bseq,
state.st_code,
 state.st_name stype,bu.bname,bu.sseq,st.stype stcode,
       hr.sid,hr.hid,hr.counts,hr.ddesc, co_conv_code(huse,null) huse,co_conv_code(bstru,null) bstru,hr.barea,hr.sbarea,
       st.tprice,co_get_segment(2248250,st.tprice/decode(hr.barea,0,null,hr.barea)) sprice,pprice
  from ts_state state,appdefine bd,mv_bulist bu,mv_room hr,to_state st

 Where bd.bseq=bu.bseq and bu.sseq=st.bid(+) and hr.hid(+)=st.sid and state.st_code=st.stype
   and nvl(hr.barea,0)*nvl(st.tprice,0)>0
   and  st.modality in (0,9)


/
