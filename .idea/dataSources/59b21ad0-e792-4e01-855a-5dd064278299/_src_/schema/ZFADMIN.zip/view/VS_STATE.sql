CREATE VIEW VS_STATE AS select v_date,to_char(v_date,'yyyy') yy,to_char(v_date,'yyyy-mm') ym,stype,sid,bid
    from to_state


/
