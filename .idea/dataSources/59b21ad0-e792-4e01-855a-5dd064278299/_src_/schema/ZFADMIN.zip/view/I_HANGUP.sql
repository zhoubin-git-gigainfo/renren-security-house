CREATE VIEW I_HANGUP AS select bname,APPWFHANG.appseq,useq,uname,htype,accdate,acc_commitdate,htime,hlimit,hmemo,appsubject  from APPWFHANG,appworkflow,appdefine where APPWFHANG.appseq=appworkflow.appseq
and appworkflow.appbid=appdefine.bid


/
