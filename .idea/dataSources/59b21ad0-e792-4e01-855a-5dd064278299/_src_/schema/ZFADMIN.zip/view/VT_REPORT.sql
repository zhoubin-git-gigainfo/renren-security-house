CREATE VIEW VT_REPORT AS Select connect_by_root T_BM as rpt_No,t_ord,level Lays,t_bm,
       T_NAME Item_name,t_pbm,connect_by_isleaf isleaf,bu_seq,t_code
From TS_BUTREE Where t_pbm>0
start with T_PBM=-1
connect by prior T_BM = T_PBM order by t_ord


/
