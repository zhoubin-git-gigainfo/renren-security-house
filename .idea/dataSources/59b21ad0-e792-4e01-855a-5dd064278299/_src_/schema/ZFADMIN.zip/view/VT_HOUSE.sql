CREATE VIEW VT_HOUSE AS Select b1.sseq,b1.bseq,decode(b1.protype,230,'SF','GF') cb,
       sum(decode(b1.protype,230,t1.barea,0)) sf_zmj, --私房总面积
       sum(decode(b1.protype,230,decode(instr(co_get_codepath(huse),'/110'),0,0,t1.barea),0)) sf_zzmj, --私房住宅面积
       sum(decode(b1.protype,230,0,t1.barea)) gf_zmj, --公房总面积
       sum(decode(b1.protype,230,0,decode(instr(co_get_codepath(huse),'/110'),0,0,t1.barea))) gf_zzmj, --公房住宅面积
       sum(decode(instr(co_get_codepath(huse),'/110'),0,t1.barea)) t_zzmj, --住宅面积
       sum(decode(instr(co_get_codepath(huse),'/130'),0,t1.barea)) t_symj, --商业面积
       sum(decode(instr(co_get_codepath(huse),'/160'),0,t1.barea)) t_bgmj, --办公面积
       sum(nvl(t1.barea,0)) tot_mj,
       max(to_char(t2.v_date,'yyyy.mm')) ym --年月
  From taq_enrol b1, tu_house t1,to_state t2
 Where b1.sseq=t2.bid and t1.hid=t2.sid
   and t2.stype>'40' and modality!=1
  Group by b1.sseq,b1.bseq,decode(b1.protype,230,'SF','GF')


/
