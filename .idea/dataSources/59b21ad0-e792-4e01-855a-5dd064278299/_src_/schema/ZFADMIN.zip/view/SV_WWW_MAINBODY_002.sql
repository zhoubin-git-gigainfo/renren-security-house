CREATE VIEW SV_WWW_MAINBODY_002 AS select
       t1.ic_no,
       t1.md_name,
       t1.md_tel,

       t1.md_addr,
       ZFADMIN.co_convert_code(t1.mo_kind, null) mo_kind,

       t1.md_bossname boss_name,
       t3.qualigrade
  from ZFADMIN.tm_mbodycard t1,
       zfadmin.tm_body t2,
       (select md_id,
               mseq,
               md_name,
               ZFADMIN.co_convert_code(qualigrade, null) qualigrade
          from zfadmin.tm_mbodycard
         where ic_type = 90008
           and f_date is null) t3
 where t1.md_type = 1
   and t2.md_id = t1.md_id
   and t1.f_date is null
   and t2.f_date is null
   and t1.ic_type = 54132
   and t1.md_id = t3.md_id(+)
/
