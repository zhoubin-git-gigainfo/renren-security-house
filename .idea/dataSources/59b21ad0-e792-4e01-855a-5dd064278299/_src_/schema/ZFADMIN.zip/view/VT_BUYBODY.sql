CREATE VIEW VT_BUYBODY AS select 1 rcount,sid, md_id, co_conv_code(t1.MD_ATYPE,null) MD_ATYPE ,
 decode(t1.mp_sex,0,'女',1,'男', '不详') mp_sex
 from tm_mainbody t1,to_relation t2
where t1.f_date is null and t2.f_date is null and
t1.md_id=t2.mid and t2.f_date is null and  mo_type is  null


/
