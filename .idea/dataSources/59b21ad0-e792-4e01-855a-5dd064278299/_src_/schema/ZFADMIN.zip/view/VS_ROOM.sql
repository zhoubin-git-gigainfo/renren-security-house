CREATE VIEW VS_ROOM AS Select b.sid,h.hid,b.v_date,b.distid,b.btype,b.bstate,b.BFETE,h.huse,h.bstru,h.barea,
       sum(nvl(sh.barea,0)) addarea,
       count(*) counts
  From tu_subhouse sh,tu_bldg b,Tu_house h
 Where h.hid=sh.hpoint(+) and h.sid=b.sid
   and h.hpoint=1
 group by b.sid,h.hid,b.v_date,b.distid,b.btype,b.bstate,b.BFETE,h.huse,h.bstru,h.barea


/
