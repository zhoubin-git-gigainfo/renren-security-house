CREATE VIEW SV_CEHUIORG AS select md_id,md_name,md_tel,md_bossname,  aptno,qualigradeid,qualigrade,empcc,ycsids,ycbareas,scsids,scbareas, rownum rnid from
(select a.md_id,md_name,md_tel,md_bossname,b.ic_no aptno,b.qualigrade qualigradeid,zfadmin.co_convert_code(b.qualigrade,null) qualigrade,c.empcc,e.sids ycsids,e.bareas ycbareas,f.sids scsids,f.bareas scbareas  from tm_mbodycard  a,
(select md_id,ic_no,qualigrade from tm_mbodycard where mo_type=155008 and ic_type=90008) b,
(select mo_id,count(*) empcc from tm_orgman where mo_type=155008 and f_date is null group by mo_id) c,
(select md_id,count(sid) sids,sum(barea) bareas from tu_recordinfo where bseq in (130101522282) group by md_id) e,
(select md_id,count(sid) sids,sum(barea) bareas from tu_recordinfo where bseq in (130101522291) group by md_id) f
where a.mo_type=155008 and f_date is null and exists (select md_name from tm_body where md_id=a.md_id)
and a.ic_type in (54132,54131) and a.md_id=b.md_id(+) and a.md_id=c.mo_id(+) and a.md_id=e.md_id(+) and a.md_id=f.md_id(+)
order by a.v_date)
/
