CREATE VIEW VT_REGVOL AS select t1.appname,to_char(t1.appcredate,'YYYY-MM-DD') appcredate,
to_char(t1.appcredate,'YYYY-MM') appcremoth,
t3.bdesc,1 vcount
 from ta_common  T1,appworkflow t2, taq_enrol t3 where
   t1.appseq=t2.appseq and t2.wfseq=t1.appseq  and t1.appseq=t3.appseq
   and t3.regbookerid is not null


/
