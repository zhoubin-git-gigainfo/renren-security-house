CREATE VIEW SV_ALL_SYSUSER AS select 225||c.useq useq,userid,uname,430225 xz_id,1 ustste,0 logintype,sex from (select oseq,oname,oparent  from sysorgan@ylorcl  start with oseq=201 connect by  prior oseq = oparent) a,
sysuserorg@ylorcl b,sysuser@ylorcl c
where a.oseq=b.oseq  and b.useq=c.useq
union
select 224||c.useq useq,userid,uname,430224 xz_id,1 ustste,0 logintype,sex from (select oseq,oname,oparent  from sysorgan@clorcl  start with oseq=201 connect by  prior oseq = oparent) a,
sysuserorg@clorcl b,sysuser@clorcl c
where a.oseq=b.oseq  and b.useq=c.useq
/
