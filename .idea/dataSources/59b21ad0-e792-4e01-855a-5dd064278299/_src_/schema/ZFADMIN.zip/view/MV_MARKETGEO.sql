CREATE VIEW MV_MARKETGEO AS select m.hid,m.v_date,m.f_date,m.metno,m.sid,m.barea,m.bstru,m.huse,b.distid,b.ddesc,b.lname,p.pid,j.pdesc from
          tuh_house m
          ,tuh_bldg b,tu_pbldg p,tu_proj j where m.sid=b.sid(+) and m.sid=p.sid(+) and p.pid=j.pid(+)
           and to_char(b.v_date,'YYYY-MM-DD hh24:mi')<=to_char(m.v_date,'YYYY-MM-DD hh24:mi')
          and nvl(b.f_date,to_date('9999-12-31','yyyy-mm-dd'))>m.v_date
/
