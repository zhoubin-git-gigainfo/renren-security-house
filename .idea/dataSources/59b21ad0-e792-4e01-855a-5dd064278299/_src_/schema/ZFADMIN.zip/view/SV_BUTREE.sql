CREATE VIEW SV_BUTREE AS Select t1.t_ord||t2.t_ord BM,t1.t_bm bm1,t1.t_name Type1,t2.t_bm bm2,t2.t_name TYpe2,t3.bu_seq,t3.t_name
  From ts_butree t1,ts_butree t2,ts_butree t3
 Where t1.t_bm=t2.t_pbm and t2.t_bm=t3.t_pbm and t1.t_pbm=-1
 order by t1.t_ord,t2.t_ord


/
