CREATE VIEW SV_TARBODY_BU AS select  t2.sseq,t2.bseq,t2.ano,t2.maintypeid, t2.ic_no,t2.agentname,t2.ic_typeid,t2.md_tel,t2.agenttelephone,
t2.gpart,t2.agentaddress,t2.md_addr,
t2.AGENTWHOID ,t2.agentwhoname ,t2.md_id,t2.mseq from ta_agent t2
union
select  t1.sseq,null  bseq,t1.ano,t1.apptype, t1.ic_no,t1.md_name,t1.ic_type,t1.md_tel,t1.mp_mobil
,null gpart, t1.md_addr,t1.md_raddr ,t1.AGENTWHOID
,t1.agentwhoname  ,t1.md_id,t1.mseq   from  ta_mainbody t1
/
