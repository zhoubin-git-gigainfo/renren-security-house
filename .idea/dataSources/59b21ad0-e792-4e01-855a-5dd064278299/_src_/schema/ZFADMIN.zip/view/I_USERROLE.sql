CREATE VIEW I_USERROLE AS select useq,oseq from sysuserorg


/
