CREATE VIEW VT_EARNING AS select t1.sseq,
       sum(ROUND(decode(tid,75000,t1.apprating,0))) tot_fw ,--服务费性收费
       sum(ROUND(decode(tid,185015,t1.apprating,0))) tot_qs ,--契税
       sum(ROUND(decode(tid,185022,t1.apprating,0))) tot_zhs ,--综合税
       sum(ROUND(decode(tid,185023,t1.apprating,0))) tot_xz --行政事业性收费
from taq_taxapp t1,ts_ticket t2 where t1.tid=t2.id
 and t1.tollcollector is not null
Group by t1.sseq


/
