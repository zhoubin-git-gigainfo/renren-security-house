CREATE VIEW TEST_SYSUSER2 AS select t1.uname,t1.useq,t2.oseq from sysuser t1,sysuserorg  t2 where t1.useq=t2.useq


/
