CREATE VIEW VT_SALES AS Select to_char(st.v_date,'yyyy-mm-dd') vdate,bu.yy,bu.yq,to_char(st.v_date,'yyyy-mm') ym,
bu.bseq, state.st_name stype,bu.bname,bu.sseq,st.stype stcode,
       hr.sid,hr.hid,hr.counts,co_conv_code(huse,null) huse,co_conv_code(bstru,null) bstru,hr.barea,hr.sbarea,
       st.tprice,co_get_segment(2248250,st.tprice/decode(hr.barea,0,null,hr.barea)) sprice,HR.DDESC
  from ts_state state,appdefine bd,mv_bulist bu,mv_room hr,to_state st
 Where bd.bseq=bu.bseq and bu.sseq=st.bid and hr.hid=st.sid and state.st_code=st.stype
   and bd.apptype=3 and st.modality in(0,9) and st.stype between '31' and '39'
   and hr.pactnum>'9000000000' and nvl(hr.barea,0)>0


/
