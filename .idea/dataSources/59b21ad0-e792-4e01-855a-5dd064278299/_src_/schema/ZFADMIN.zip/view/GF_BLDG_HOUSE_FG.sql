CREATE VIEW GF_BLDG_HOUSE_FG AS select u1.bldgid,u1.street,u1.areaname,u1.lname,u1.bkind,u1.arch,u1.areaid,u1.sarea,u1.barea,u1.bstru,u1.byear,u1.origincode,
u1.lcount,u2.hid,u2.hdesc,u2.ucount,u2.buse,u2.deptid,u2.useq,u2.barea hbarea,u2.parea,u2.hstand,u2.STANDNAME,u3.sseq,u3.tno,u3.tnum,u3.tunit, u3.chgtype,
to_char(u3.sdate,'yyyy-mm-dd') sdate,to_char(u3.edate,'yyyy-mm-dd') edate,u4.sfee,u5.md_name,u5.ic_no,u5.md_type,
u4.remitInfo,u3.uprice,u4.yymm,u5.md_id,u12.fgdate,u12.farea,u12.housetotal,u12.lessman,u12.lman_no,u12.memo
from u_bldg u1,(select * from u_house where hstate=7) u2,u_rentchange u12,
(select a1.hid,a1.sseq,a1.tno,a1.tnum,a1.tunit,a1.sdate,a1.edate,a1.vflag,a1.chgtype,a1.uprice from u_tenancy a1 where a1.vflag=0) u3,
(select sseq,sum(sfee) sfee,wm_concat(distinct memo) remitInfo,wm_concat(distinct yymm) yymm from u_account where ftype=2 and vflag=0 group by sseq) u4,
(select sseq,md_name,ic_no,md_type,md_id from u_relation where vflag=0 and ptype=1001001) u5
where  u1.u_flag=6 and u1.bstate=0 and u2.hstate=7 and u2.u_flag=3  and u3.sseq=u5.sseq(+)
and exists (select hid from u_tenancy t1,u_relation t2 where t1.vflag=0 and t2.vflag=0 and t2.ptype=1001001 and t1.sseq=t2.sseq and t1.hid=u2.hid)
and u12.bseq=100001000442 and u2.hid=u12.hid
and u1.bldgid=u2.bldgid and u2.hid=u3.hid and u3.sseq=u4.sseq(+)

--空置房屋
union
select g1.bldgid,g1.street,g1.areaname,g1.lname,g1.bkind,g1.arch,g1.areaid,g1.sarea,g1.barea,g1.bstru,g1.byear,g1.origincode,
g1.lcount,g2.hid,g2.hdesc,g2.ucount,g2.buse,g2.deptid,g2.useq,g2.barea hbarea,g2.parea,g2.hstand,g2.standname,0,'',0,0,0,'','',0,'','',0,'',0,'',0,u12.fgdate,u12.farea,u12.housetotal,u12.lessman,u12.lman_no,u12.memo
from u_bldg g1,u_house g2,u_rentchange u12 where  g1.u_flag=6 and g2.hstate=7 and g2.u_flag=3 and g1.bldgid=g2.bldgid and u12.bseq=100001000442 and g2.hid=u12.hid
and not exists (select hid from u_tenancy where vflag=0 and hid=g2.hid)


/
