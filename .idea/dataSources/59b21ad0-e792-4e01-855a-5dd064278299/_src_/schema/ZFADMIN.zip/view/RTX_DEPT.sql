CREATE VIEW RTX_DEPT AS Select C.RTX_DEPTID AS DeptID,
       C.ONAME AS DeptName,
       P.RTX_DEPTID AS PDeptID,
       C.OORDER AS SortID,
       '0' AS Version
  from sysorgan p,sysorgan c
 where p.oseq=c.oparent and c.otype!=4 and p.rtx_deptid>0 and c.rtx_deptid>0
union
Select RTX_DEPTID,ONAME,0 AS PDeptID, OORDER, '0'
  from sysorgan
 where oparent=-1


/
