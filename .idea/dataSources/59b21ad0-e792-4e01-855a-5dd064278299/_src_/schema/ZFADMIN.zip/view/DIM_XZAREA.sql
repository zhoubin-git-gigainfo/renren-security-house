CREATE VIEW DIM_XZAREA AS select id,name,parentid,'所有行政区域' as parentname from ts_code where parentid=999
/
