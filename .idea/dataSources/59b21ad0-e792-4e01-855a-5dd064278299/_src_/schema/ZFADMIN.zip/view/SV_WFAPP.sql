CREATE VIEW SV_WFAPP AS Select Appseq,0 as APPSECRECY,null as appfileno,AppSubject||' '||to_char(appcredate,'yyyy.mm.dd')||' '||AppName||' '||sf_convert_code(AppCatlog) as remark
     from APPBULLETIN
    union --知识
    Select Appseq,0,null,AppSubject||' '||to_char(AppCreDate,'yyyy.mm.dd')||' '||AppName||' '||sf_convert_code(AppCatlog)
     from APPDATUM
    union --领导信箱
    Select Appseq,586,null,AppSubject||' '||to_char(AppCreDate,'yyyy.mm.dd')||' '||AppName||' '||sf_convert_code(AppCatlog)
     from APPMAILBOX
    union --信访
    Select Appseq,586,null,AppSubject||' '||to_char(visitdate,'yyyy.mm.dd')||' '||AppName||' '||to_char(RECEIVEDATE,'yyyy.mm.dd')||' '||VISITNAME||' '||VISITDEPT||' '||VISITADRESS
     from APPLETTER
    union  --流程的发布信息
    Select Appseq,586,null,AppSubject||' '||AppName||' '||to_char(AppCreDate,'yyyy.mm.dd')
     from AppFlowPublish
--4、公文
    union --部门收文
    Select Appseq,APPSECRECY,appnumber,appnumber||' '||appsubject||' '||to_char(appcredate,'yyyy.mm.dd')||' '||sf_convert_code(appsecrecy)||' '||sf_convert_code(appurgent)||' '||sf_convert_code(apptype)||' '||appkey||' '||appname
      from APPDEPTRECEIVE

    union --部门发文
    Select Appseq,to_number(APPSECRECY),appnumber,appnumber||' '||appsubject||' '||to_char(appcredate,'yyyy.mm.dd')||' '||sf_convert_code(appsecrecy)||' '||sf_convert_code(appurgent)||' '||sf_convert_code(apptype)||' '||appkey||' '||appname
      from appdeptsend

    union --单位收文
    Select Appseq,APPSECRECY,appnumber,appnumber||' '||appsubject||' '||to_char(appcredate,'yyyy.mm.dd')||' '||sf_convert_code(appsecrecy)||' '||sf_convert_code(appurgent)||' '||sf_convert_code(apptype)||' '||appkey||' '||appname
      from APPRECEIVE

    union --单位发文
    Select Appseq,to_number(APPSECRECY),appnumber,appnumber||' '||appsubject||' '||to_char(appcredate,'yyyy.mm.dd')||' '||sf_convert_code(appsecrecy)||' '||sf_convert_code(appurgent)||' '||sf_convert_code(apptype)||' '||appkey||' '||appname
      from APPSEND

    union --请示报告
    Select Appseq,586,null,appsubject||' '||to_char(appcredate,'yyyy.mm.dd')||' '||sf_convert_code(appsecrecy)||' '||sf_convert_code(appurgent)||' '||sf_convert_code(apptype)||' '||appkey||' '||appname
      from APPREPORT

--5、事务
    union --请假
    Select Appseq,586,null,appsubject||' '||to_char(appcredate,'yyyy.mm.dd')||' '||appkey||' '||appname
      from APPLEAVE
    Union --文件传阅
    Select Appseq,586,null,AppName||' '||to_char(AppCreDate,'yyyy.mm.dd')||' '||AppSubject||' '||AppKey||' '||AppName
      from AppRead
    union --用车
    Select Appseq,586,null,AppName||' '||to_char(AppCreDate,'yyyy.mm.dd')||' '||AppSubject||' '||AppKey
     from APPCAR
    union --会议
    Select Appseq,586,null,AppName||' '||to_char(AppCreDate,'yyyy.mm.dd')||' '||AppSubject||' '||AppKey||' '||AppStart
     from AppSynod
    union --用章
    Select Appseq,586,null,AppSubject||' '||AppName||' '||AppPrintName||' '||to_char(AppCreDate,'yyyy.mm.dd')
     from APPPRINT
    union
    Select Appseq,586,null,to_char(AppCreDate,'yyyy.mm.dd')||' '||AppName||' '||AppSubject
      from APPCOMMON


/
