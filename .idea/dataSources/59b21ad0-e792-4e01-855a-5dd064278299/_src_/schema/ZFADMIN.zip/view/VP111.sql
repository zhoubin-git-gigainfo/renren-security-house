CREATE VIEW VP111 AS Select stype,sum(1) totl
              From (Select distinct t2.sid,t2.stype from tu_house t1,tu_state t2,table(co_split(200000422697))
                     Where t1.hid=t2.sid and nvl(t1.sattribute,0)!=145001
                       and (t1.sid=200000422697 or t1.lid=200000422697 or t1.hid=200000422697))
             Group by stype


/
