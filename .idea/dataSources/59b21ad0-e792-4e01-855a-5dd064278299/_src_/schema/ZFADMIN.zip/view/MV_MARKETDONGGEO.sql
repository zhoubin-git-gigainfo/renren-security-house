CREATE VIEW MV_MARKETDONGGEO AS select b.sid,b.distid,b.ddesc,b.lname,p.pid,j.pdesc from
          tu_bldg b,tu_pbldg p,tu_proj j where b.sid=p.sid(+) and p.pid=j.pid(+)
/
