CREATE VIEW VT_PRJSELCARD AS select cname,cdno,to_char(pdate,'YYYY-MM-DD') PDATE FROM tu_card where cid=101


/
