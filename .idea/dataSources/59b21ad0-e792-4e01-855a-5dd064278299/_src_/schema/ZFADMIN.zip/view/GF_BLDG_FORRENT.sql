CREATE VIEW GF_BLDG_FORRENT AS select u1.bldgid,u1.street,u1.areaname,u1.lname,u1.bkind,u1.arch,u1.areaid,u1.sarea,u1.barea,u1.bstru,u1.byear,u1.origincode,
u1.lcount,u2.hid,u2.hdesc,u2.ucount,u2.buse,u2.deptid,u2.useq,u2.barea hbarea,u2.parea,u2.hstand,u2.STANDNAME,u3.sseq,u3.tno,u3.tnum,u3.tunit, u3.chgtype,
to_char(u3.sdate,'yyyy-mm-dd') sdate,to_char(u3.edate,'yyyy-mm-dd') edate,u4.sfee,u5.md_name,u5.ic_no,u5.md_type,
CO_compareDate(to_char(edate,'yyyy-mm-dd')) state,u4.remitInfo,u3.uprice,u4.yymm,u5.md_id
from u_bldg u1,u_house u2,
(select a1.hid,a1.sseq,a1.tno,a1.tnum,a1.tunit,a1.sdate,a1.edate,a1.vflag,a1.chgtype,a1.uprice from u_tenancy a1 where a1.vflag=0 and sdate<sysdate and tno is not null) u3,
(select sseq,sum(sfee) sfee,wm_concat(distinct memo) remitInfo,wm_concat(distinct yymm) yymm from u_account where ftype=2 and vflag=0 group by sseq) u4,
(select sseq,md_name,ic_no,md_type,md_id from u_relation where vflag=0 and ptype=1001001) u5
where u1.bstate=0 and u1.u_flag=6 and u2.hstate=0 and u2.u_flag=3  and u3.sseq=u5.sseq(+)
and exists (select hid from u_tenancy t1,u_relation t2 where t1.vflag=0 and t2.vflag=0 and t2.ptype=1001001 and t1.sseq=t2.sseq and t1.hid=u2.hid)
and u1.bldgid=u2.bldgid and u2.hid=u3.hid and u3.sseq=u4.sseq(+)


/
