CREATE VIEW SV_PROJECTSORT AS select t2.pdesc,t2.pid,t5.name area,t1.memo,t2.rdate
from tas_proj t1,tu_proj t2,tu_aitem t3,tu_attech t4,ts_code t5
where t1.pid=t2.pid and t1.lid=t5.id and t1.fbmode=1
and t3.oid=t1.pid and t3.atype=1183126 and t3.aid=t4.aid


/
