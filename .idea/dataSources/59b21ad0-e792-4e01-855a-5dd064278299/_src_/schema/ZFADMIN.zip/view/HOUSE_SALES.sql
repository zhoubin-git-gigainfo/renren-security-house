CREATE VIEW HOUSE_SALES AS select st.sid,st.bid,b.dprice,b.cprice
  from tu_state st,sales_contract b
  where  st.bid=b.sseq and st.stype='33'
/
