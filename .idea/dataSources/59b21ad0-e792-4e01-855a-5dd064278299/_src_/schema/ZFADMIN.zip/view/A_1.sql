CREATE VIEW A_1 AS Select he.sid,st.bid,to_char(st.v_date,'yyyy-mm-dd') v_date,he.hid,he.hdesc,st.stype,st.modality,st.droits
  From to_state st,tu_house he
 Where st.sid=he.hid and he.sid=200000327862


/
