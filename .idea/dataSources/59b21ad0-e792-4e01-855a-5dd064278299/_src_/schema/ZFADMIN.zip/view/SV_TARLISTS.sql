CREATE VIEW SV_TARLISTS AS Select t2.bname,t1.bseq,t1.appseq,t1.sseq,t1.mortconno contract_no, 0.00 cprice,0 CHARGE, subject subject,
state_id,null osseq,t1.protype
,t1.startdate,t1.enddate,t1.pawnmoney,t1.informno,  max(t3.v_date) v_date,t1.recodername,t1.xz_id
 from tar_recode t1
, appdefine t2,to_state t3 where t1.bseq=t2.bseq
and t1.sseq=t3.bid
group by
 t2.bname,t1.bseq,t1.appseq,t1.sseq, subject,
state_id, t1.protype
,t1.startdate,t1.enddate,t1.pawnmoney,t1.informno,t1.mortconno,t1.recodername,t1.xz_id
union

Select t2.bname,t1.bseq,t1.appseq,t1.sseq,t1.mortconno contract_no ,0.00 cprice,0 CHARGE,subject subject,
state_id,null osseq,t1.protype
,t1.startdate,t1.enddate,t1.pawnmoney,t1.informno, max(t3.f_date) v_date,t1.recodername,t1.xz_id
 from tar_recode t1
, appdefine t2,to_state t3 where t1.bseq=t2.bseq
and t1.sseq=t3.disbuno
and t2.optmod='10'
group by
 t2.bname,t1.bseq,t1.appseq,t1.sseq, subject,
state_id, t1.protype
,t1.startdate,t1.enddate,t1.pawnmoney,t1.recodername,t1.mortconno,t1.informno,t1.xz_id

--销售合同
union  select bname,t1.bseq,appseq,t1.sseq,t1.Contract_No, t1.cprice,   CHARGE ,title ,state_id,Osseq,
null,null ,null ,null ,informno,max(t3.v_date) v_date, max(t4.tuname)tuname , t1.xz_id
from tar_salescontract t1,appdefine t2,to_state t3,apptasks t4
where t1.bseq=t2.bseq
and t1.sseq=t3.bid
and t1.appseq=t4.tappseq
and (t4.tactname like '%备案%' or t4.tactname like '%审批%' )
group by bname,t1.bseq,appseq,t1.sseq,t1.Contract_No, t1.cprice, CHARGE,t1.bdesc,title, state_id,Osseq,
 informno, t1.xz_id

union
select bname,t1.bseq,appseq,t1.sseq,t1.Contract_No,t1.cprice, CHARGE,title ,state_id,Osseq,
null,null ,null ,null ,informno,max(t3.v_date) v_date, max(t4.tuname)tuname, t1.xz_id
from tar_salescontract t1,appdefine t2,to_state t3,apptasks t4
where t1.bseq=t2.bseq
and t1.sseq=t3.disbuno
and t2.optmod='10'
and t1.appseq=t4.tappseq
--and (t4.tactname like '%备案%' or t4.tactname like '%审批%')
group by bname,t1.bseq,appseq,t1.sseq,t1.Contract_No, t1.cprice, CHARGE,t1.bdesc,title, state_id,Osseq,
 informno, t1.xz_id




--二手房
union all Select t2.bname,t1.bseq,t1.appseq,t1.sseq,t1.contract_no,t1.cprice ,CHARGE,t1.title  ,state_id,0,
t1.osseq ,null,
null  ,null,t1.informno, t1.createdate, max(t3.tuname) tuname,
t1.xz_id from tat_contract t1,appdefine t2,apptasks t3

 where t1.bseq=t2.bseq
 and t1.appseq=t3.tappseq
 and (t3.tactname like '%备案%' or t3.tactname like '%审核%')
 group by
 t2.bname,t1.bseq,t1.appseq,t1.sseq,t1.contract_no,t1.cprice,CHARGE,t1.osseq,t1.title ,t2.bname ,state_id, t1.informno, t1.createdate,
t1.xz_id

union all Select t2.bname,t1.bseq,t1.appseq,t1.sseq,t1.contract_no ,t1.cprice,CHARGE,t1.title ,state_id,0,t1.osseq,null,
null  ,null,t1.informno,t1.createdate,max(t3.tuname) tuname,
t1.xz_id from tat_contract t1,appdefine t2,apptasks t3

 where t1.bseq=t2.bseq
 and t1.appseq=t3.tappseq
 and (t3.tactname like '%备案%' or t3.tactname like '%审核%')
 and t2.optmod='10'
 group by
 t2.bname,t1.bseq,t1.appseq,t1.sseq,t1.contract_no, t1.cprice,CHARGE,t1.osseq,t1.title, t2.bname ,state_id, t1.informno, t1.createdate,
t1.xz_id
/
