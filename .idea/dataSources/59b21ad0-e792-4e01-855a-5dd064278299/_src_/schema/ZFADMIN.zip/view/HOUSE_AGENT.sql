CREATE VIEW HOUSE_AGENT AS select st.sid,st.bid,b.agentname,b.ic_no,b.md_id
  from tu_state st,ta_agent b
  where  st.bid=b.sseq and st.stype='33' and b.maintypeid=1
/
