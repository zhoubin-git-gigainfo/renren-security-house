CREATE VIEW SV_QRY_REAL AS Select 1 otype,sid oseq,lname||decode(instr(lname,nvl(bdesc,lname)),0,'［'||bdesc||'］',null) lname,metno,barea,0 pactnum,decode(sstate,'20','清理','21','预测','22','实测','24','手工','其他') Sstate,husename as huse,1 as hpoint
         from tu_bldg
union all
Select 3,t2.lid,lname||decode(instr(lname,nvl(bdesc,lname)),0,'［'||bdesc||'］',null)||lno||'层' lname,t1.metno,t2.barea,0,decode(t1.sstate,'20','清理','21','预测','22','实测','24','手工','其他'),t2.luse as huse,1 as hpoint
         from tu_layer t2, tu_bldg t1 where t1.sid=t2.sid
 union all
Select 4 otype,hid,lname||decode(instr(lname,nvl(bdesc,lname)),0,'［'||bdesc||'］',null)||Decode(hno,hdesc,hno,hno||'('||hdesc||')') lname,t1.metno,t2.barea,pactnum,decode(t1.sstate,'20','清理','21','预测','22','实测','24','手工','其他'),co_convert_code(t2.huse,null) as huse,t2.hpoint
  from tu_house t2,tu_bldg t1 where t1.sid=t2.sid
/
