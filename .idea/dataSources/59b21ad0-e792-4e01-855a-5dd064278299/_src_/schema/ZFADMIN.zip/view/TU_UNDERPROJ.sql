CREATE VIEW TU_UNDERPROJ AS select DISTINCT t.pid,t.pdesc,t.plocal,t1.mid  from tu_proj t,to_relation t1,tu_pbldg t2,tu_house t3
where t1.rtype=90 and t1.f_date is null and t3.hid=t1.sid and t2.sid=t3.sid and t2.f_date is null
and t.pid=t2.pid
union
select t1.pid,t1.pdesc,t1.plocal,t.mid from to_relation t,tu_proj t1 where t.f_date is null and t.rtype=2 and t1.pid=t.sid
and t1.property=100001106401
/
