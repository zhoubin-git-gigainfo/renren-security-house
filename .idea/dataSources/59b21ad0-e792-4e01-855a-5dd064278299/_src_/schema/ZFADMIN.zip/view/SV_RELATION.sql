CREATE VIEW SV_RELATION AS Select a.oseq as pid,a.oname as pname,a.otype as Ptype,b.oseq as sid,b.oname as cname,b.otype as ctype from Sysorgan a,sysorgan b where a.ocode!=b.ocode and b.ocode like a.ocode||'%'
 Union
Select Sysorgan.oseq,sysorgan.oname,sysorgan.otype,sysuser.useq,sysuser.uname,9 from sysorgan,sysuserorg,sysuser where sysuser.useq=sysuserorg.useq and sysuserorg.oseq=sysorgan.oseq


/
