CREATE VIEW STA_BU_MV AS select  to_date(bu_date,'yyyymm')v_date,t1.bseq,   t1.bname,deptid oseq,  accept_count,finish_count, unit_count,
                                        barea,tcharge,outtime_count, back_count
from sta_bu_mn t1 ,sta_deptbs t2
where t1.bseq=t2.bseq and ishostbs=1
/
