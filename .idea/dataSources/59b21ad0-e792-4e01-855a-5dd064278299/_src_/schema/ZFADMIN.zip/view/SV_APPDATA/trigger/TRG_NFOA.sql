-- Cannot generate trigger TRG_NFOA: the table is unknown
/
