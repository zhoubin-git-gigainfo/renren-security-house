CREATE VIEW BLDG_HOUSE AS select b.lname,b.bdesc,h.hdesc,h.hid,b.sid,h.metno,pb.pid,h.barea
  from tu_pbldg pb,tu_bldg b,tu_house h
  where b.sid=h.sid and  pb.sid=b.sid order by sid,hdesc
/
