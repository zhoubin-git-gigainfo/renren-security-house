CREATE VIEW TU_RELATION AS Select Distinct bid,mid,md_name From to_relation,tm_mainbody where modality=0 and mid=md_id(+)


/
