CREATE VIEW HOUSE_AGENT_JOIN AS select st.sid,st.bid,concatstr(b.agentname) agentname,concatstr(b.ic_no) ic_no,concatstr(b.md_id) md_id
  from tu_state st,ta_agent b
  where  st.bid=b.sseq and st.stype='33' and b.maintypeid=1 group by st.sid,st.bid
/
