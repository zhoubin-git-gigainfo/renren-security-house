CREATE VIEW SV_GIS AS select sid,pbldg,metno,gis_x,gis_y,lname,v_date from tu_bldg
where pbldg=0 and bno<>'999' and sstate=22 and gis_x<>0


/
