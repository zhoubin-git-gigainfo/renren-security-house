CREATE VIEW VT_PRICE AS Select t1.sseq,max(round(nvl(pawnmoney,0))) dk,sum(round(nvl(t2.hprice,0))) jz
  from taq_enrol t1,taq_sdlist t2
 where t1.sseq=t2.sseq group by t1.sseq


/
