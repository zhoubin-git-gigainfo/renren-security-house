CREATE VIEW STA_SELLOLIST_V AS select t1.mseq,t1.sseq,t1.hid,t1.v_date,t1.stype,t1.barea,sg_area,parea,huse,hkind,t1.upprice,sg_uprice,htype,bstru,
t1.decorationid,sprice,stag,t1.xz_id,bstate,bseq,t1.pid,lid,buymancount,loanmode,
LOANMONEY,t1.useid,sg_areaid,sg_upriceid
  from sta_sellolist_incr t1 ,sta_sellsum_incr t2
   where t1.sseq=t2.sseq
  -- and t1.btag=t2.btag
   and t2.btag <>'00'
/
