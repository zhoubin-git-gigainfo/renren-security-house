CREATE VIEW I_WFDEFINE AS select syswfdefine.wfseq,syswfdefine.wfname,syswfactivity.actseq,syswfactivity.actname,syswfactivity.assgnrole,syswfactivity.assignrolename,syswfactivity.actlimitdate,syswfactivity.actx,syswfactivity.acty from syswfdefine,syswfactivity where syswfdefine.wfseq=syswfactivity.wfseq


/
