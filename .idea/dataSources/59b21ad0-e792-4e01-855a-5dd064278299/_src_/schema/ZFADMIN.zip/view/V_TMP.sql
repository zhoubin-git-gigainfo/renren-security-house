CREATE VIEW V_TMP AS Select sid,count(*) ts  From tu_house where not exists (select 1 from tu_regdata where sd_id=hid) group by sid


/
