CREATE VIEW GF_BLDG_HOUSE_PAST AS select u1.bldgid,u1.street,u1.areaname,u1.lname,u1.bkind,u1.arch,u1.areaid,u1.sarea,u1.barea,u1.bstru,u1.byear,u1.origincode,
u1.lcount,u2.hid,u2.hdesc,u2.ucount,u2.buse,u2.deptid,u2.useq,u2.barea hbarea,u2.parea,u2.hstand,u2.STANDNAME,u3.sseq,u3.tno,
u4.sfee,u5.md_name,u5.ic_no,u5.md_type,u5.md_id,u4.yymm,u4.remitinfo
from (select * from u_bldg where bstate=0 and u_flag=6) u1,(select * from u_house where (hstate=0 or hstate=6 or hstate=7) and u_flag=3) u2,
(select * from u_tenancy where vflag=9) u3,
(select sseq,sum(sfee) sfee, wm_concat(yymm) yymm,wm_concat(memo) remitinfo, hid from u_account where ftype=2 and vflag=0 group by sseq,hid) u4,
(select sseq,md_name,ic_no,md_type,md_id from u_relation where vflag=0 and ptype=1001001) u5
where   u3.sseq=u5.sseq(+)
and exists (select hid from u_tenancy t1,u_relation t2 where t1.vflag=0 and t2.vflag=0 and t2.ptype=1001001 and t1.sseq=t2.sseq and t1.hid=u2.hid)
and u1.bldgid=u2.bldgid and u2.hid=u3.hid and u3.hid=u4.hid(+)


/
