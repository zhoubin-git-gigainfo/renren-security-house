CREATE VIEW DIM_VDATE AS select distinct
       extract(year from v_date) year ,extract(year from v_date)||'年' year_name,
       v_date_m, to_char(v_date,'mm')||'月' month_name
       from sta_provolist_v
       order by v_date_m
/
