CREATE VIEW VS_PRICE AS Select t01."APPSEQ",t01."SSEQ",t01."BAREA",t01."UPRICE",t01."TPRICE",co_get_segment(2248250,uprice) suprice From (
Select a.appseq,a.sseq,sum(b.barea) barea,round(max(cprice)/sum(b.barea),0) uprice,max(cprice) tprice
  From sales_contract a,taq_sdlist b
 Where a.sseq=b.sseq
 Group by a.appseq,a.sseq having max(cprice)>0 and sum(b.barea)>0) t01


/
