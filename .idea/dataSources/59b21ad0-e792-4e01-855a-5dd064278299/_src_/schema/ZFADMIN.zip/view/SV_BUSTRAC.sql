CREATE VIEW SV_BUSTRAC AS Select t0.bname,t1.bseq,t1.appseq,t1.sseq, subject,co_get_strlists('sseq',t1.sseq,'agentname','ta_agent',null) mduname,
       co_get_strlists('tappseq',t1.appseq,'tuname','apptasks','tuname!=''End'' and tstate=0')  tuname
  from appdefine t0,taq_enrol t1 Where t0.bseq=t1.bseq
union all
--档案查询
Select t2.bname,t2.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］'||sseq,'xx','yy' From ta_qarchives t1,appdefine t2 where t1.bseq=t2.bseq
union all
--测量与成果利用
Select bname,ta_scale.bseq ,ta_scale.appseq WFSEQ,sseq SSEQ,location,'xx','yy' from ta_scale,appdefine where ta_scale.bseq=appdefine.bseq
union all
--预售许可/变更
Select bname,tas_pslist.bseq,tas_pslist.appseq,sseq,co_get_strlists('sid',tas_pslist.sid,'lname||bdesc','tu_bldg',''),'xx','yy'
 From tas_pslist,appdefine where tas_pslist.bseq=appdefine.bseq
--项目申报
union all Select b.bname,a.bseq,a.SSEQ,a.sseq,pdesc,'xx','yy' From tas_proj a,appdefine b Where a.bseq=b.bseq
--合同备案
union all select bname,Sales_contract.bseq,appseq,sseq,title,'xx','yy'
from Sales_contract,appdefine where Sales_contract.bseq=appdefine.bseq
--企业入网
union all Select t2.bname,t1.bseq,t1.appseq,t1.id,t1.corp_name,'xx','yy' from corp_base t1,appdefine t2 where t1.bseq=t2.bseq
--担保
union all Select t2.bname,t1.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］','xx','yy' from ta_suretyagent t1,appdefine t2 where t1.bseq=t2.bseq
--合同模板申请
union all Select t2.bname,t1.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］','xx','yy' from ta_sales_template t1,appdefine t2 where t1.bseq=t2.bseq

union all select  t2.bname,t2.bseq,t1.appseq,t1.sseq,t1.appsubject,'xx','yy' from corp_common t1,appdefine t2
where t1.cbid=t2.bid
--基础测量
union all select  t2.bname,t2.bseq,t1.appseq,t1.sseq,t1.LNAME,'xx','yy' from ta_basescale t1,appdefine t2
where t1.bseq=t2.bseq


/
