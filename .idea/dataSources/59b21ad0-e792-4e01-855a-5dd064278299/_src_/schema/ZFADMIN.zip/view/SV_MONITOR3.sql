CREATE VIEW SV_MONITOR3 AS select 1 as ord,101 as id,'全部' as bname,-1 as parentid,'0' as bid from appdefine where rownum=1
union  select distinct 1 as ord,b.bseq as id,bname,101 as parentid,bid from appdefine b, sysorgbu a,sysuserorg c where a.bseq=b.bseq and a.oseq=c.oseq and c.useq=212061
union  select -1 as ord,201 as id,'超期任务' as bname,-1 as parentid,'0' as bid  from appdefine where rownum=1
union  select distinct -1 as ord,b.bseq as id,bname,201 as parentid,bid from appdefine b, sysorgbu a,sysuserorg c where a.bseq=b.bseq and a.oseq=c.oseq and c.useq=212061
union  select 0 as ord,301 as id,'未过期任务' as bname,-1 as parentid,'0' as bid  from appdefine where rownum=1
union  select distinct 0 as ord,b.bseq as id,bname,301 as parentid,bid from appdefine b, sysorgbu a,sysuserorg c where a.bseq=b.bseq and a.oseq=c.oseq and c.useq=212061


/
