CREATE VIEW I_TUSDLIST AS select sseq,tid as did,dno,dname,dcount,spage,decode(dstate,null,'0','113002','0','1') dstate from tu_dlist


/
