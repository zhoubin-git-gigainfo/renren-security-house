CREATE VIEW MV_GROUP_HOUSE AS Select hpoint,sum(barea) barea,sum(garea) garea,sum(parea) parea,sum(sarea) sarea,sum(uarea) uarea,sum(1) counts
 from tu_house Where hpoint>1 group by hpoint


/
