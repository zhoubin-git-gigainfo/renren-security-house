-- Cannot generate trigger CMGUIDS_INSERT_TR: the table is unknown
/
