CREATE VIEW SV_MONITOR2 AS select 1 as ord,101 as id,'全部' as bname,-1 as parentid from appdefine where rownum=1
union  select distinct 2 as ord,b.bseq as id,bname,101 as parentid from sysorgbu a,appdefine b where a.bseq=b.bseq and a.oseq=203
union  select 3 as ord,201 as id,'超期任务' as bname,-1 as parentid from appdefine where rownum=1
union  Select distinct 4 as ord,bseq as id,TBNAME as bname,201 as parentid from AppTasks,AppWorkFlow,appdefine where  sf_comp_date(plandate,tedate)=-1  and TAPPSEQ=APPSEQ  and  bid=tbid  and HasApp=1 and AppWorkFlow.isurge=1 and wfstate>=0
union  select 5 as ord,301 as id,'未过期任务' as bname,-1 as parentid from appdefine where rownum=1
union  Select distinct 6 as ord,bseq as id,TBNAME as bname,301 as parentid from AppTasks,AppWorkFlow,appdefine where  sf_comp_date(plandate,tedate)=1  and TAPPSEQ=APPSEQ  and  bid=tbid  and HasApp=1 and AppWorkFlow.isurge=1 and wfstate>=0


/
