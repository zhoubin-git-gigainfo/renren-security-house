CREATE VIEW VT_CARD AS Select bid,count(*) vcs from tu_card where tu_card.cstate>-100 group by bid


/
