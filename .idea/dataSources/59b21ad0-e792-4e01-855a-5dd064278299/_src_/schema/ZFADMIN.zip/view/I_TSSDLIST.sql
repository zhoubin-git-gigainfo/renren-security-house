CREATE VIEW I_TSSDLIST AS select a.bseq,bname,did,rno,dname from ts_dlist a,appdefine b where a.bseq=b.bseq


/
