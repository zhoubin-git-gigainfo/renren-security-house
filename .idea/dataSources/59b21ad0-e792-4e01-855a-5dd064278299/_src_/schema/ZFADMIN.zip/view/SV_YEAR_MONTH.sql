CREATE VIEW SV_YEAR_MONTH AS select t1.year,t2.month from sta_year t1 ,sta_month t2

order by  t1.year,t2.month
/
