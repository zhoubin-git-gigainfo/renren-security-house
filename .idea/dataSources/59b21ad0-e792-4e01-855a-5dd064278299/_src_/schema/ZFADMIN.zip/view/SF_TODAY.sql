CREATE VIEW SF_TODAY AS select SYSTIMESTAMP Today  from dual

/
