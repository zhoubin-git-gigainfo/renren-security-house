CREATE VIEW SV_WORKORGAN AS select   OSEQ_ID,OCODE,  OSEQ_ONAME ,
(case when( instr( ocode,'---')>0)  then 1 else 0 end )
 OSEQ_ISEAF,OSEQ_L1,OSEQ_L2,
( case when( instr( ocode,'---')>0 and OSEQ_L3 is null and length(ocode)=15 ) then oseq_id
when(   length(ocode)=9 ) then oseq_id

 else OSEQ_L3 end )OSEQ_L3 ,


(case when( instr( ocode,'---')>0 and OSEQ_L4 is null and length(ocode)=18) then oseq_id  else OSEQ_L4 end )
OSEQ_L4,
(case when( length( ocode)=3)   then 1  when( length( ocode)=6)  then 2
when( length( ocode )=9 or ( length( ocode)=15 and instr(ocode,'---')>0  ))  then 3
when( length( ocode)=12 or ( length( ocode)>15 and instr(ocode,'---')>0  ) )  then 4

  else 5 end ) lev
 from (
select  OSEQ OSEQ_ID,OCODE,ONAME OSEQ_ONAME ,NULL OSEQ_ISEAF,
 ( SELECT  T2.OSEQ FROM SYSORGAN T2 WHERE T2.OCODE=SUBSTR(organ1.OCODE,0,3  ) ) OSEQ_L1
 ,( SELECT  T3.OSEQ FROM SYSORGAN T3 WHERE T3.OCODE=SUBSTR(organ1.OCODE,0,6  ) AND OSEQ<>203
  AND LENGTH(organ1.OCODE )>3
  ) OSEQ_L2
 ,( SELECT  T4.OSEQ FROM SYSORGAN T4 WHERE T4.OCODE=SUBSTR(organ1.OCODE,0,9  ) AND OSEQ<>203
 AND LENGTH(organ1.OCODE )>15
-- and instr(organ1.OCODE,'---' )<0


  ) OSEQ_L3

   ,( SELECT  T5.OSEQ FROM SYSORGAN T5 WHERE T5.OCODE=SUBSTR(organ1.OCODE,0,12  ) AND OSEQ<>203
 AND LENGTH(organ1.OCODE )>18
  ) OSEQ_L4
 from  sv_orguser     organ1
where    organ1.OCODE like   '100%'
                --   and organ1.OCODE like  substr('100',0,3 )||'%'
                   and organ1.vr=1
                   AND OTYPE NOT IN(4) )
/
