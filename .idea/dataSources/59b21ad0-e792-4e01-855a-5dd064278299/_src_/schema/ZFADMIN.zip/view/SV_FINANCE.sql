CREATE VIEW SV_FINANCE AS select m.accountid,m.payer,decode(m.zstate,0,'老业务',1,'新业务','新业务') zstate,m.memo,m.realrating ysje,m.pcredate ysrq,decode(n.realrating,null,0,n.realrating) clje,
n.pcredate clrq,decode(o.realrating,null,0,o.realrating) ffje,o.pcredate ffrq,
decode(p.realrating,null,0,p.realrating) dyje,p.pcredate dyrq,decode(q.realrating,null,0,q.realrating) jjfje,
q.pcredate jjfrq,
decode(k.realrating,null,0,k.realrating) jsje,k.pcredate jsrq,
decode(m.realrating,null,0,m.realrating)+decode(n.realrating,null,0,n.realrating)+decode(o.realrating,null,0,o.realrating)+decode(p.realrating,null,0,p.realrating)+decode(q.realrating,null,0,q.realrating)+decode(k.realrating,null,0,k.realrating) ye from
 (select a.accountid,a.payer,zstate,memo,min(a.pcredate) pcredate,sum(a.apprating) realrating from tac_finance a where a.ptype=1 group by a.accountid,a.payer,zstate,memo) m,
 (select b.sseq,b.oseq,b.pcredate,sum(b.ptype*b.realrating) realrating from tac_finance b where b.bseq=100000004180 group by b.sseq,b.oseq,b.pcredate) n,
 (select c.sseq,c.oseq,c.pcredate,sum(c.ptype*c.realrating) realrating from tac_finance c where c.bseq=100000004181 group by c.sseq,c.oseq,c.pcredate) o,
 (select d.sseq,d.oseq,d.pcredate,sum(d.ptype*d.realrating) realrating from tac_finance d where d.bseq=100000004182 group by d.sseq,d.oseq,d.pcredate) p,
 (select e.sseq,e.oseq,e.pcredate,sum(e.ptype*e.realrating) realrating from tac_finance e where e.bseq=2591013 group by e.sseq,e.oseq,e.pcredate) q,
 (select f.sseq,f.oseq,f.pcredate,sum(f.ptype*f.realrating) realrating from tac_finance f where f.bseq=100000004184 group by f.sseq,f.oseq,f.pcredate) k
 where m.accountid=n.oseq(+) and m.accountid=o.oseq(+) and m.accountid=p.oseq(+) and m.accountid=q.oseq(+) and m.accountid=k.oseq(+)
/
