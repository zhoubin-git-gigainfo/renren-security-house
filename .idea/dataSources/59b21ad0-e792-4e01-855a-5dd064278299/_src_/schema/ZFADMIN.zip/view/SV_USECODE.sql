CREATE VIEW SV_USECODE AS select
decode(co_get_spelev(dimid_path,2)  ,110, 1101,1102) useid_l1, decode(co_get_spelev(dimid_path,2)  ,110, '住宅','非住宅') usename_l1,
co_get_spelev(dimid_path||'/',2) useid_l2 ,co_get_spelev(dimname_path||'/',2) usename_l2 ,
co_get_spelev(dimid_path||'/',3) useid_l3 , co_get_spelev(dimname_path||'/',3) usename_l3
from mv_code where dimname_path like '%/房屋用途/%'
   and co_get_spelev(dimid_path||'/',3) is not null
/
