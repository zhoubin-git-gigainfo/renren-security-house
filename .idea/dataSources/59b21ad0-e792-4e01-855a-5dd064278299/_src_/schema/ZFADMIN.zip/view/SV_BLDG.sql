CREATE VIEW SV_BLDG AS select sid,v_date,f_date,metno,plotid,distid,ddesc,lid,lname,bno,bdesc,spid,bstru,btype,buse,barea,bpric,
garea,parea,sarea,uarea,bfete,lcout,ucout,memo,bkind,bqut,pbldg,parentid,dq,nq,xq,bq,lucn,ldcn,dm_cb,dm_yt,
dm_jg,bstate,sstate,gis_x,gis_y,bstruname,husename,btypename,a_id,a_name,xz_id from tu_bldg
union
select sid,v_date,f_date,metno,plotid,distid,ddesc,lid,lname,bno,bdesc,spid,bstru,btype,buse,barea,bpric,
garea,parea,sarea,uarea,bfete,lcout,ucout,memo,bkind,bqut,pbldg,parentid,dq,nq,xq,bq,lucn,ldcn,dm_cb,dm_yt,
dm_jg,bstate,sstate,gis_x,gis_y,bstruname,husename,btypename,a_id,a_name,xz_id from tuh_bldg a where bstate=14
and v_date=(select max(v_date) from tuh_bldg b where a.sid=b.sid)
/
