CREATE VIEW VS_HOUSE AS Select b.sid,h.hid,to_char(b.v_date,'yyyy') yy,to_char(b.v_date,'yyyy.q') yq,to_char(b.v_date,'yyyy.mm') ym,
       b.distid,b.btype,b.bstate,b.BFETE,co_get_subcode(h.huse) huse,co_get_subcode(h.bstru) bstru,
       h.barea+nvl(mv.barea,0) barea,co_get_segment(2248249,h.barea+nvl(mv.barea,0)) sbarea,h.htype,1 tCount,1+nvl(mv.counts,0) counts
  From MV_Group_House mv,tu_bldg b,Tu_house h
 Where h.hid=mv.hpoint(+) and h.sid=b.sid
   and h.hpoint=1


/
