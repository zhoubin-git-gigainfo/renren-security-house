CREATE VIEW SV_REALSTRU AS Select a.sseq as oseq,a.fwzl as name,0 as pid,1 as otype from ta_zxx a
union
Select a.sseq as oseq,a.fwzl as name,0 as pid,1 as otype from ta_zxx a
union
Select distinct dyid,decode(dyid,-1,'未定义_',dy||'_')||dyid as Cname,sseq,3
  from ta_hxx
union
Select distinct cseq,b.cc||'层_'||b.cc as Cname,a.sseq,2
  from ta_hxx a,ta_cxx b Where a.sseq=b.sseq and a.cc=b.cc

/
