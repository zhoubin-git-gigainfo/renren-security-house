CREATE VIEW I_WFAPP AS select distinct sseq,tappseq as appseq,b.actmod,tseq,tactseq,tactname,tsdate,tedate,trolename,tuname,tstate,bseq
from apptasks a,appwfactivity b,sv_bulists c where c.appseq=a.tappseq and  a.tappseq=b.wfseq and b.wfseq=c.appseq and a.tactseq=b.actseq
/
