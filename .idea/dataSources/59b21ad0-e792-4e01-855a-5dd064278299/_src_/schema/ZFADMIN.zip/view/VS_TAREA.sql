CREATE VIEW VS_TAREA AS select hpoint,sum(barea) Tarea from tu_house Where hpoint>1 group by hpoint


/
