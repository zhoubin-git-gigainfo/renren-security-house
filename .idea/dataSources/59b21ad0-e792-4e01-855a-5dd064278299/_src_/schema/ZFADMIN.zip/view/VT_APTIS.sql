CREATE VIEW VT_APTIS AS select t3.md_name,t2.name QUAL_LAYS,t1.qv_date ,  t1.qi_date,1 COUNT  from tm_aptis t1,ts_code t2
,tm_mainbody t3
 where
 t1.md_id=t3.md_id
 and
 to_char(qual_lays)=to_char(t2.id(+))
 and t3.f_date is null


/
