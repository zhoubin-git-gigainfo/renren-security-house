CREATE VIEW STA_BU_MN_V AS select  to_date(bu_date,'yyyymm')v_date,bseq,  bname,  accept_count,finish_count, unit_count,
                                        barea,tcharge,outtime_count, back_count
                                          from sta_bu_mn
/
