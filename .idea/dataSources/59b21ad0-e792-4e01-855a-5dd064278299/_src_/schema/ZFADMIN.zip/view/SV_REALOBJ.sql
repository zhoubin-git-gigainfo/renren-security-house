CREATE VIEW SV_REALOBJ AS Select sid as OSEQ,METNO,lname AS lname,'' as UNAME,bdesc as ONAME,decode(pbldg,'0',1,2) as otype,bstru,buse,
barea,parea,sarea,garea,bpric,pbldg as PARENTID,bstate from tu_bldg
union
Select a.lid,METNO,b.lname,'' as UNAME,a.ldesc||'层',3,a.lstru,a.luse,
a.barea,a.parea,a.sarea,a.garea,a.bpric,a.sid,bstate
  From tu_layer a,tu_bldg b
 where a.sid=b.sid and a.f_date=b.f_date
union
Select a.hid,a.METNO,c.lname,d.name,decode(a.hno,a.hdesc,a.hno,a.hno||'/'||a.hdesc),4,s.name,u.name,
       a.barea,a.parea,a.sarea,a.garea,a.bpric,B.LID,bstate
 from tu_house a,tu_layer b,tu_bldg c,ts_code u,ts_code s,ts_code d
where a.sid=b.sid and b.sid=c.sid and a.lid=b.lid
  and a.huse=u.id and a.bstru=s.id   and a.utid=d.id


/
