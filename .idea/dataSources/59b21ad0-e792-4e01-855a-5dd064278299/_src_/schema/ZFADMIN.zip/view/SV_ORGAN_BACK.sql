CREATE VIEW SV_ORGAN_BACK AS SELECT OCODE,OCODE as OCODESort , OSEQ,OID,ONAME,OTYPE,OPARENT,OMAIL,Ocatlog,rtx_deptid as RTXID,vr,1 as ustste
FROM SysOrgan
Union
SELECT SysOrgan.OCODE || '---', SysOrgan.OCODE || '---'||substr('000'||to_char(SysUserOrg.Sort),-3),SysUser.USEQ,SysUser.Userid,SysUser.UNAME,9,SysOrgan.OSEQ,UMAIL,SysOrgan.Ocatlog as Ocatlog,SysUser.Rtx_Userid
,vr ,ustste FROM SysOrgan,SysUserOrg,SysUser
Where SysOrgan.OSEQ = SysUserOrg.OSEQ and SysUserOrg.USEQ = SysUser.USEQ
union
Select '100999', '100999',-100,'','用户分类',3,oseq,'',0,0,1 vr,1 from sysorgan where ocode='100'
union
Select '100999999'||cdkey,'100999999'||cdkey ,cdid,'',cdvalue,4,-100,'',0,0,1 vr,1 from appcode where cdparent=800
union
select '100999999'||cdkey||'---', '100999999'||cdkey||'---'||SysUserOrg.Sort
,
sysuser.useq,userid,uname,9,cdid,'',0,0,1 vr,ustste from sysusersort,sysuser,appcode ,SysUserOrg
where sysusersort.useq=sysuser.useq and sysusersort.sortid=appcode.cdid
and  SysUserOrg.Useq=sysuser.useq
 union
select distinct a.ocode||'900' as ocode,a.ocode||'900' as OCODESort ,-1*a.oseq as oseq,a.oid as oid,
a.oname||'下属部门主管领导' as oname,
3 as otype,a.oseq as oparent,'' as omail,0 as ocatlog,0,1 vr,1
  from sysorgan a,sysorgan b
where a.otype=1 or a.otype=5 and
a.oseq=b.oparent and b.oseq in (select oparent from sysorgan where otype!=3 or otype!=4)
union
Select a.ocode||'900---',  a.ocode||'900---' as ocodesort  ,c.useq,userid,uname,9,-1*a.oseq,c.umail,3,0,1 vr,ustste
from sysorgan a,sysorgan b,sysuser c , SysUserOrg d
Where a.otype=1 and b.otype=5 and instr(b.ocode,a.ocode,1,1)=1
  and Instr(','||b.mainleader||',',','||to_char(c.useq)||',',1,1)>0
  and c.useq=d.useq
union
Select a.ocode||'900---', a.ocode||'900---' as ocodesort, c.useq,userid,uname,9,-1*a.oseq,c.umail,2,0,1 vr,ustste
 from sysorgan a,sysorgan b,sysuser c
,SysUserOrg d
Where a.otype=5 and b.oparent=a.oseq and b.oseq in (select oparent from sysorgan where otype!=3 or otype!=4)
  and Instr(','||b.mainleader||',',','||to_char(c.useq)||',',1,1)>0 and b.otype!=5 and b.otype!=3
  and c.useq=d.useq
 -- )
/
