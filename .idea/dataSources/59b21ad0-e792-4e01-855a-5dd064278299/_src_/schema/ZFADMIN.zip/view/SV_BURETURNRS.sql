CREATE VIEW SV_BURETURNRS AS select tappseq,sl-1 htcs from (
select tappseq,max(sl) sl from (
select tappseq,tactseq,count(*) sl from apptasks  group by tappseq,tactseq having count(*)>1 )
group by tappseq

)
/
