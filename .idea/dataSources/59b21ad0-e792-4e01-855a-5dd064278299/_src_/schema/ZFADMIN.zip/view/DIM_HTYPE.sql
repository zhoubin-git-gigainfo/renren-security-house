CREATE VIEW DIM_HTYPE AS select  id,name,parentid,'所有户型结构' as parentname from ts_code where parentid=77000
/
