CREATE VIEW SV_TARBULISTS AS Select t2.bname,t1.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］'||subject subject,null cardcount,
state_id,null osseq,t1.protype
,t1.startdate,t1.enddate,t1.pawnmoney,  t1.informno, t1.xz_id,t2.outnet,t3.accedate,t3.appdatea
,t3.acceman
 from ta_bscommon t3, tar_recode_bu t1
, appdefine t2 where t1.bseq=t2.bseq
and t1.sseq=t3.sseq
--销售合同
union all select bname,t1.bseq,appseq,sseq,'［'||t1.bdesc||'］'||title,0,state_id,Osseq,
null,null ,null ,null ,informno,t1.xz_id,t2.outnet,t1.accedate,t1.appdatea,t1.acceman
from Sales_contract t1,appdefine t2 where t1.bseq=t2.bseq
--二手房
union all Select t2.bname,t1.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］',1,state_id,osseq ,null,null,
null  ,null,t1.informno,
t1.xz_id,t2.outnet,t3.accedate,t3.appdatea,t3.acceman from
ta_bscommon t3,tat_contract_bu t1,appdefine t2 where t1.bseq=t2.bseq
and t1.sseq=t3.sseq
/
