CREATE VIEW SV_USECD AS select "USEID","USENAME",LPAD( ORD,2,'0')  ORD from (
select distinct
decode(co_get_spelev(dimid_path,2)  ,110, 1101,1102) useid, decode(co_get_spelev(dimid_path,2)  ,110, '住宅','非住宅') usename,

decode(co_get_spelev(dimid_path,2)  ,110, 1,2)  ord


 from mv_code where dimname_path like '%/房屋用途/%'
   and co_get_spelev(dimid_path||'/',3) is not null
 union
   /* select distinct
to_number(co_get_spelev(dimid_path,2)) useid ,co_get_spelev(dimname_path,2) usename
 from mv_code where dimname_path like '%/房屋用途/%'
   and co_get_spelev(dimid_path||'/',3) is not null*/
   select id,name,rank() over( order by ckey )+2 ord from ts_code where parentid=998

   union
  select distinct to_number( co_get_spelev(dimid_path||'/',3)) useid , co_get_spelev(dimname_path||'/',3) usename
  ,rank() over( order by ckey )+15 ord
   from mv_code where dimname_path like '%/房屋用途/%'
   and co_get_spelev(dimid_path||'/',3) is not null
   )
/
