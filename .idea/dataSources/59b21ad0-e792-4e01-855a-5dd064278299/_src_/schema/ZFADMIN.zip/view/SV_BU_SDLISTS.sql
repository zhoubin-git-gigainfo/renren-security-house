CREATE VIEW SV_BU_SDLISTS AS select '测量' SD_From,appseq,sseq,ridgepoleno as sd_id From ta_scale where bseq<>1806000 and bseq<>2587030 and bseq<>100000004180--测量
union Select '登记&合同',appseq,sseq,sd_id from taq_sdlist--登记和合同
Union Select '预售许可',appseq,sseq,sid From tas_pslist--预售许可
Union select '担保代办',appseq,sseq,sd_id from tac_sdlist where bseq in (2591001,1806000,100000004180,100000004177) --测量分户和担保代办
/
