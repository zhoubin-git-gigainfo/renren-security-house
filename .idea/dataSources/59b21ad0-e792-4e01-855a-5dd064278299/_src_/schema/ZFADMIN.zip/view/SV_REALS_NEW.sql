CREATE VIEW SV_REALS_NEW AS Select a.hid as OSEQ,
c.METNO,c.lname,bdesc||decode(a.hno,a.hdesc,a.hno,a.hno||'('||a.hdesc||')') as ONAME,c.bdesc,decode(a.hno,a.hdesc,a.hno,a.hno||'('||a.hdesc||')') hdesc,4 as otype,
       co_convert_code(a.bstru,'') as bstru,a.BSTRUNAME,to_char(a.bstru)  BSTRUID,co_convert_code(a.huse,'') as buse,a.HUSENAME,
       to_char(a.huse)  BUSEID,b.lid as G_layer,b.ldesc,a.utid as g_unit
       ,a.barea,a.parea,a.sarea,a.garea,a.bpric,a.Sid PARENTID,c.bstate,c.sstate,c.lcout,c.lucn,c.LDCN
       ,c.distid,c.ddesc,c.lid,c.bkind,co_convert_code(c.bkind,'') bkindname,c.btype,c.bfete
       ,a.htype,co_convert_code(a.htype,'') htypename,a.bq,a.nq,a.xq,a.dq,
       d.plotid,d.pno,d.PCARDNO,d.pname,d.ppid,d.PPNAME,d.pyid,d.PYNAME,d.puid,
       d.puname,d.parea pparea,d.V_DATE,d.f_date,d.uyear,a.pactnum,a.sattribute
 from tu_house a,tu_layer b,tu_bldg c,tu_plot d
where a.sid=c.sid and a.lid=b.lid and a.plotid=d.plotid(+)
union all
Select a.sid ,a.METNO,a.lname,a.bdesc,a.bdesc,null,1, a.bstru,
a.BSTRUNAME,a.bstru  , a.buse,a.HUSENAME, a.buse , null,null,null,
       a.barea,a.parea,a.sarea,a.garea,a.bpric,a.pbldg,a.bstate,a.sstate,a.lcout,null,null,
       a.distid,a.ddesc,a.lid,a.bkind,co_convert_code(a.bkind,''),a.btype,a.bfete,
       null,null,a.bq,a.nq,a.xq,a.dq,
       d.plotid,d.pno,d.PCARDNO,d.pname,d.ppid,d.PPNAME,d.pyid,d.PYNAME,
       d.puid,d.puname,d.parea,d.V_DATE,d.f_date,d.uyear,0, 145003
from tu_bldg a,tu_plot d Where a.plotid=d.plotid(+)
union all
Select a.lid,c.METNO,c.lname,a.lno,c.bdesc,ldesc||'层',3,
       a.lstru,a.BSTRUNAME,a.lstru ,a.luse,a.HUSENAME,a.luse,a.lid,a.ldesc,null,
       a.barea,a.parea,a.sarea,a.garea,a.bpric,a.Sid,c.bstate,c.sstate,c.lcout,null,null
       ,c.distid,c.ddesc,c.lid,c.bkind,co_convert_code(c.bkind,''),c.btype,c.bfete
       ,null,null,c.bq,c.nq,c.xq,c.dq,
       d.plotid,d.pno,d.PCARDNO,d.pname,d.ppid,d.PPNAME,d.pyid,
       d.PYNAME,d.puid,d.puname,d.parea,d.V_DATE,d.f_date,d.uyear,0, 145003
 From tu_layer a,tu_bldg c,tu_plot d
where a.sid=c.sid and c.plotid=d.plotid(+)
/
