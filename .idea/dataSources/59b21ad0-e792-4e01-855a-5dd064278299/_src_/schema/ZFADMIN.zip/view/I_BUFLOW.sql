CREATE VIEW I_BUFLOW AS select bseq,bname,wfseq,wfname from appdefine a,syswfdefine b  where instr(a.wfseqs,wfseq)>0


/
