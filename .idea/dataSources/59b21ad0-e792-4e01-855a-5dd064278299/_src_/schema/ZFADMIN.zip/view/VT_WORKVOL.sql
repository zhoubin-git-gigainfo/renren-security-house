CREATE VIEW VT_WORKVOL AS Select ut.oname,ut.uname,bu.bname,tt.tactname,sum(1) wkcount,
sum(Case When tt.tedate>tt.plandate Then 1 else 0 End) overtimecount,
to_char(Trunc(tt.tedate),'YYYY-MM') tedate
  From sv_orguser ut,mv_bulist bu,apptasks tt
 Where ut.rseq=tt.troleseq and ut.useq=tt.tuser and bu.appseq=tt.tappseq and tt.tstate=0
 Group by tt.tedate,ut.ocode2,ut.ocode3,ut.oname,ut.uname,bu.bname,tt.tactname
 Order by ut.ocode2,ut.ocode3,ut.uname


/
