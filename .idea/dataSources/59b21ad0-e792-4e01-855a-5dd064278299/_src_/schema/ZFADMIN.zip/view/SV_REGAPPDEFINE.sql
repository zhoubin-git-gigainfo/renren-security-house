CREATE VIEW SV_REGAPPDEFINE AS select bseq_id,bseq_name,bseq_isleaf,bseq_l4 bseq_l1,bseq_l5 bseq_l2,bseq_l6 bseq_l3,bcode
  from MVIWE_APPDEFINE where bseq_l4=100002011012
  union

select  bseq_id,bseq_name,bseq_isleaf,'100002011012'  bseq_l1,'100002010848' bseq_l2,bseq_l6 bseq_l3,bcode
 from    MVIWE_APPDEFINE where bseq_l3=100009479091
/
