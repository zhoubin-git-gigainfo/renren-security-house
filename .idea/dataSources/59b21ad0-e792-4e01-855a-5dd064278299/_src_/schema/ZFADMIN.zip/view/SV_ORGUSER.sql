CREATE VIEW SV_ORGUSER AS SELECT OCODE,OCODE as OCODESort , OSEQ,OID,ONAME,OTYPE,OPARENT,OMAIL,Ocatlog,rtx_deptid as RTXID,vr,1 as ustste
FROM SysOrgan
Union
SELECT SysOrgan.OCODE || '---' ||substr('000'||count(*) OVER(PARTITION BY  SysOrgan.ocode  ORDER BY SysUserOrg.useq ) ,-3)
, SysOrgan.OCODE || '---'||substr('000'||to_char(SysUserOrg.Sort),-3),SysUser.USEQ,SysUser.Userid,SysUser.UNAME,9,SysOrgan.OSEQ,UMAIL,SysOrgan.Ocatlog as Ocatlog,SysUser.Rtx_Userid
,vr ,ustste FROM SysOrgan,SysUserOrg,SysUser
Where SysOrgan.OSEQ = SysUserOrg.OSEQ and SysUserOrg.USEQ = SysUser.USEQ
/
