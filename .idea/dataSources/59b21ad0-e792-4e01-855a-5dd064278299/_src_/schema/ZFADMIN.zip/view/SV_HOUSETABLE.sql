CREATE VIEW SV_HOUSETABLE AS Select PID AS OSEQ,''as METNO, t.pdesc as lname,-1 AS PARENTID,
''as bstru,'' as buse,  null as  barea, null as parea,  null as sarea,  null as garea, null as bpric,
'' as ST_NAME,bcompid,'' as state
from tu_proj t
union
Select OSEQ,METNO, lname||ONAME lname,t3.PID AS PARENTID,
bstru,buse,t2.barea,parea,t2.sarea,garea,bpric,
'<div style=background:'||st_bgclr||'>'||ST_NAME||'</div>' as ST_NAME,t3.bcompid,co_get_strlists('a.sid',OSEQ,'b.st_name','to_state a,ts_state b','a.stype=b.st_code and modality=0') as state
from sv_reals t2  ,ts_state,tu_sdinfo,TU_PBLDG t1  ,TU_PROJ t3
Where bstate=st_code and   sd_id=oseq and
 t1.sid=t2.OSEQ and t1.pid=t3.pid
 and otype=1 order by LNAME


/
