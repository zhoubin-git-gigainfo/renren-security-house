CREATE VIEW SV_APPDATA AS Select 1 AS APPTYPE,'APPMYDATUM' as tbname,Dseq as appseq,'公文包' as Appname,null as appfileno,null as completedate,to_char(CreDate,'yyyy.mm.dd')||' '||Subject||' '||Catlog||' '||Memo as Remark From APPMYDATUM --公文包
union Select 1,'APPMYLINK',Pseq ,'名片夹' ,null,null,Catlog||' '||PName||' '||to_char(PBDate,'yyyy.mm.dd')||' '||PMobil||' '||PMail||' '||Company||' '||Dept||' '||Addr||' '||Post||' '||CTel||' '||CFax from APPMYLINK --我的名片
union Select 1,'APPMYACCR',Aseq,'公务授权',null,null ,AuthorName||' '||to_char(CreDate,'yyyy.mm.dd')||' '||Subject||' '||RecName From APPMYACCR --公务授权
union Select 1,'APPMYSITE',Appseq,'站点收藏',null,null,SiteType||' '||SiteName||' '||SiteURL From APPMYSITE --站点收藏
union Select 1,'APPMYCALEND',Appseq,'日程安排',null,null,sf_convert_code(AppType)||' '||AppSubject||' '||to_char(StartDate,'yyyy.mm.dd')||' '||AppMemo From APPMYCALEND --我的日程
union Select 1,'APPPUBLISH',appseq,'信息发布',null,null,sf_convert_code(apptype)||' '||AppName||' '||to_char(AppCreDate,'yyyy-mm-dd')||' '||AppSubject||' '||appcredept from APPPUBLISH --信息发布
union Select 1,'APPNOTICE',nseq,'通知',null,null,AppSubject||' '||to_char(AppCreDate,'yyyy.mm.dd')||' '||AppName from APPNOTICE  --通知


/
