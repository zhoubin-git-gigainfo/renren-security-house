CREATE VIEW SV_PERSONTASKS AS select sysuser.useq,sysuser.uname,startdate,enddate from appmycalend,sysuser,sysuserdept where sysuser.useq=author(+)
and sysuser.useq=sysuserdept.useq and sysuserdept.oseq=42030 and apptype(+)=1764001
/
