CREATE VIEW VT_BULISTS AS Select t3.bseq, t1.bid,t1.sid,t1.v_date,t1.stype,t2.hid,t2.barea,t2.huse,decode(t3.protype,230,'SF','GF') cb,
       co_get_total('sseq',t1.bid,'round(nvl(pawnmoney,0))','taq_enrol',null) dke,
       co_get_total('sseq',t1.bid,'round(nvl(hprice,0))','taq_sdlist',null) cje
 From taq_enrol t3,tu_house t2,to_state t1
Where t1.bid=t3.sseq(+) and t1.sid=t2.hid and (t1.modality=0 or t1.modality=9)
  and t1.bid between 20081000000 and 99995000000
  and t1.stype>'30'


/
