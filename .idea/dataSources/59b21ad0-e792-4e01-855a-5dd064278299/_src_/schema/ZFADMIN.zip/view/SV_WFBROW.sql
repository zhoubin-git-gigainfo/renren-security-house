CREATE VIEW SV_WFBROW AS select a.wfname,
       b.actname,
       c.cdvalue as AcTTYPE,
       d.cdvalue as actproc,
       e.cdvalue as actassi,
       f.cdvalue as actscop,
       b.assignrolename,
       b.actfunc
from syswfactivity b,
     syswfdefine a,
     syscode c,
     syscode d,
     syscode e,
     syscode f
where a.wfseq=b.wfseq and a.wfstate=0
  and b.acttype=to_number(c.cdkey) and c.cdparent=960
  and b.actmonth=to_number(d.cdkey) and d.cdparent=967
  and b.assgnmonth=to_number(e.cdkey) and e.cdparent=980
  and b.assgnscope=to_number(f.cdkey) and f.cdparent=990

/
