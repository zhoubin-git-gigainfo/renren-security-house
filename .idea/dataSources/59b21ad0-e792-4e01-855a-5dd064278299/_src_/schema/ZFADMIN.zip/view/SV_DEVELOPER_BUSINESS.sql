CREATE VIEW SV_DEVELOPER_BUSINESS AS select TSEQ,t2.appbid tbid,t2.wfname tbname,wfseq TAPPSEQ,decode(wfstate,0,'完成','在办') TSTATE,
      appsubject subject,t2.actname TACTNAME,appdate appdate, appdept appdept,t1.tuname,t4.sseq from apptasks t1,appworkflow t2,appdefine t3,sv_bulists t4 where
 t4.appseq=t2.appseq and t4.appseq=t1.tappseq and tappseq=t2.appseq and t2.appbid=t3.bid and t1.tbid=t3.bid and t3.apptype>1
   and wfstate>=0 and hasapp=1 and tseq=(select max(tseq) from apptasks where tappseq=t2.appseq)


/
