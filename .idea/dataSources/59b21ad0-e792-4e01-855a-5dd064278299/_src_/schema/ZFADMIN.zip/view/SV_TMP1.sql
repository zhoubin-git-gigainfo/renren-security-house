CREATE VIEW SV_TMP1 AS Select distinct ys.sid,pactnums,to_number(substr(pactnums,1,10)) startnum,to_number(substr(pactnums,12,10)) endnum
  From tu_house sh,tu_card tc,tas_pslist ys
 Where sh.sid=tc.oid and sh.sid=ys.sid and nvl(sh.pactnum,0)=0
   and cid=101 and not ys.pactnums is null


/
