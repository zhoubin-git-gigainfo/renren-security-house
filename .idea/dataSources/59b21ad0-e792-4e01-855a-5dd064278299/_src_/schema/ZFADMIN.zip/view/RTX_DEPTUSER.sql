CREATE VIEW RTX_DEPTUSER AS Select distinct deptid,c.rtxid as userid
  From RTX_DEPT a,sv_organ b,sv_organ c
 Where a.deptid=b.rtxid
   and c.OCODE like b.ocode||'___---'
   and c.otype=9
   and c.Ocatlog!=10
   and c.RTXID>0 and deptid<>55


/
