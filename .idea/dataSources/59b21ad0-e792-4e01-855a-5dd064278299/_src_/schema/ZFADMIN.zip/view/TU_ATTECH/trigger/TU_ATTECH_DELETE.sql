-- Cannot generate trigger TU_ATTECH_DELETE: the table is unknown
/
