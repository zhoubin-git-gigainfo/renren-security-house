-- Cannot generate trigger TU_ATTECH_INSERT: the table is unknown
/
