-- Cannot generate trigger TU_ATTECH_UPDATE: the table is unknown
/
