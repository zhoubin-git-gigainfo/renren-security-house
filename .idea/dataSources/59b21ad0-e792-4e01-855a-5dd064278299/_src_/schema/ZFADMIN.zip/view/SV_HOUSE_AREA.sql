CREATE VIEW SV_HOUSE_AREA AS select sid,sg_name,count(hid) hcount from
(select sid,hid,barea,a1.sg_name from tu_house a0,(select sg_name,sg_minval,sg_maxval from TS_SEGMENT t where sg_type=2248249) a1
where a0.barea between (a1.sg_minval) and (a1.sg_maxval)) group by sid,sg_name


/
