CREATE VIEW SV_SDLISTS AS Select t1.bdesc,t1.appseq,t1.sseq,t2.sd_id,
       round(co_get_total('sseq',t1.sseq,'nvl(pprice,0)','taq_sdlist',null)) tprice,
       round(co_get_total('sseq',t1.sseq,'nvl(pprice,0)','taq_sdlist',null)/decode(co_get_total('sseq',t1.sseq,'nvl(barea,0)','taq_sdlist',null),0,null,co_get_total('sseq',t1.sseq,'nvl(barea,0)','taq_sdlist',null)),0) uprice,
       nvl(pawnmoney,0)+nvl(TIPTOPCREDITOR,0) pprice,
       round((nvl(t1.pawnmoney,0)+nvl(TIPTOPCREDITOR,0))/decode(co_get_total('sseq',t1.sseq,'nvl(barea,0)','taq_sdlist',null),0,null,co_get_total('sseq',t1.sseq,'nvl(barea,0)','taq_sdlist',null)),0) upprice,barea
  From taq_enrol t1,taq_sdlist t2 Where t1.sseq=t2.sseq
union all
Select '合同备案' ,t1.appseq,t1.sseq,t2.sd_id,round(t1.cprice,2),round(t1.dprice,0),null,null,barea
  from sales_contract t1,taq_sdlist t2 Where t1.sseq=t2.sseq
union all select '栋测量' SD_From,appseq,sseq,ridgepoleno,null,null,null,null,null From ta_scale--测量
Union all Select '预售许可',appseq,sseq,sid,null,null,null,null,null From tas_pslist--预售许可;
Union all Select '补交或退款' ,t2.appseq,t2.sseq,t2.sd_id,0,0,null,null,barea
  from TFB_UPDATETAX_BU t1,taq_sdlist t2 Where t1.sseq=t2.sseq--补交或退款


/
