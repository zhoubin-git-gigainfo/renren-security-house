CREATE VIEW SYS_USER1 AS SELECT  rtx_userid AS id, USERID AS username,
      '8F25D35CC63BCC2150458C539AE53D8E00000000000000000000000000000000' AS pwd,
       0 AS pwdtype, NULL AS smsid, UNAME AS name, 0 AS UserType, SEX AS Gender,
      126 AS Face, NULL AS Mobile, NULL AS Email, null AS Phone,
      0 AS ProfileOpenLevel, 0 AS BuddyAuth, 0 AS LastLogonTime,
      '00000000000000000000000000000000' AS UserRight, NULL AS AccountState,
      0 AS UserVersion, 0 AS AuthType
FROM SysUser order by rtx_userid


/
