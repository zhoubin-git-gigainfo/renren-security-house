CREATE VIEW VS_SALES AS Select min(v_date) v_date,to_char(min(v_date),'yyyy') yy,to_char(min(v_date),'yyyy.mm') ym,bid,sid
  from to_state
 where stype='33' or stype='32'
 group by  bid,sid


/
