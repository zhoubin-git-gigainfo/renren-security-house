CREATE VIEW SV_BULISTS AS Select t2.bname,t1.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］'||subject subject,nvl(cardcount,0) cardcount,state_id,osseq,t1.protype,t1.enddate,t1.xz_id from taq_enrol t1
, appdefine t2 where t1.bseq=t2.bseq
union all
--档案查询
Select t2.bname,t2.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］'||sseq,0,state_id,0,null,null, t1.xz_id From ta_qarchives t1,appdefine t2 where t1.bseq=t2.bseq and t2.bid not like 'NDA%'
union all
--测量与成果利用
Select bname,ta_scale.bseq ,ta_scale.appseq WFSEQ,sseq SSEQ,'［'||appdefine.bname||'］'||location,0,state_id,0,null,null,ta_scale.xz_id from ta_scale,appdefine where ta_scale.bseq=appdefine.bseq
union all
--预售许可/变更
Select bname,tas_pslist.bseq,tas_pslist.appseq,sseq,'［'||appdefine.bname||'］'||co_get_strlists('sid',tas_pslist.sid,'lname||bdesc','tu_bldg',''),1,state_id,osseq,null,null,tas_pslist.xz_id
 From tas_pslist,appdefine where tas_pslist.bseq=appdefine.bseq
--项目申报
--union all Select b.bname,a.bseq,a.SSEQ,a.sseq,'［'||bname||'］'||pdesc,1,state_id,0,null,null From tas_proj a,appdefine b Where a.bseq=b.bseq
--合同备案
union all select bname,Sales_contract.bseq,appseq,sseq,'［'||Sales_contract.bdesc||'］'||title,0,state_id,Osseq,null,null,Sales_contract.xz_id
from Sales_contract,appdefine where  Sales_contract.bseq=appdefine.bseq and appdefine.bseq!=130008260
--企业入网
union all Select t2.bname,t1.bseq,t1.appseq,t1.id,'［'||t2.bname||'］',1,state_id,0,null,null,t1.xz_id from corp_base t1,appdefine t2 where t1.bseq=t2.bseq
--担保
union all Select t2.bname,t1.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］'||location,1,state_id,0,null,null,t1.xz_id from ta_suretyagent t1,appdefine t2 where t1.bseq=t2.bseq
--基础测量
union all select  t2.bname,t2.bseq,t1.appseq,t1.sseq,t1.LNAME,1,state_id,0,null,null,t1.xz_id from ta_basescale t1,appdefine t2 where t1.bseq=t2.bseq
--合同模板申请
union all Select t2.bname,t1.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］',1,state_id,0,null,null, t1.xz_id from ta_sales_template t1,appdefine t2 where t1.bseq=t2.bseq
union all select  t2.bname,t2.bseq,t1.appseq,t1.sseq,t1.appsubject,1,state_id,0,null,null,t1.xz_id from corp_common t1,appdefine t2
where t1.cbid=t2.bid
--拆迁许可
union all Select b.bname,a.bseq,a.appseq,a.sseq,'［'||b.bname||'］'||pdesc,1,state_id,0,null,null,a.xz_id From tab_proj a,appdefine b Where a.bseq=b.bseq
--维修资金
 union all
select  t2.bname,t2.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］'||t1.LNAME,1,'0' state_id,0,null,null,t1.xz_id from taw_paymentnotice t1,appdefine t2
where t1.bseq=t2.bseq
--维修资金使用
 union all
select  t2.bname,t2.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］'||t1.appsubject,1,'0' state_id,0,null,null,t1.xz_id from taw_useapply t1,appdefine t2
where t1.bseq=t2.bseq
--维修资金票据
 union all
select  t2.bname,t2.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］'||t1.subject,1,'0' state_id,0,null,null,t1.xz_id from taw_note_bu t1,appdefine t2
where t1.bseq=t2.bseq
--产权数据清理
 --union all
--select  t2.bname,t2.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］'||t1.subject,1,'0' state_id,0,null,null from ta_impbady t1,appdefine t2
--where t1.bseq=t2.bseq
union all
select  t2.bname,t2.bseq,t1.appseq,t1.sseq,'［'||t2.bname||'］'||t1.appsubject,1,'0' state_id,0,null,null,t1.xz_id from ta_bscommon t1,appdefine t2
where t2.bchar>0  and t1.bseq=t2.bseq
--老开工申报
union all Select b.bname,a.bseq,a.appseq,a.sseq,'［'||b.bname||'］'||bdesc,1,state_id,0,null,null,a.xz_id From tas_bplan a,appdefine b Where a.bseq=b.bseq
/
