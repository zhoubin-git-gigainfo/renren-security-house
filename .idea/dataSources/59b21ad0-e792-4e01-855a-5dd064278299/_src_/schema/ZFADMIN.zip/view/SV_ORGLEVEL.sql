CREATE VIEW SV_ORGLEVEL AS SELECT Org1.OSEQ PSeq,Org1.ONAME PName,Org1.OTYPE PType,Org1.Isdept Isdept,org1.deptlev deptlev,
               Org2.OSEQ SSeq,Org2.ONAME SName,Org2.Ocatlog Ocatlog, Org2.OTYPE SType,Org2.OCODE OCODE
FROM SysOrgan  Org1,SysOrgan  Org2
Where  Org1.OCODE != Org2.OCODE and
Org2.OCODE like Org1.OCODE || '%'


/
