CREATE VIEW I_DEPT AS select oseq,oname,oparent,otype from sysorgan


/
