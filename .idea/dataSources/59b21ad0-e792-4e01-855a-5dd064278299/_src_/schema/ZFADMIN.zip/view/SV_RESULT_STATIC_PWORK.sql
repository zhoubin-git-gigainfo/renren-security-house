CREATE VIEW SV_RESULT_STATIC_PWORK AS select yymm,useq,uname,bname,sl_bcounts,cs_bcounts,sh_bcounts,ba_bcounts,shrk_bcounts,lpxg_bcounts,sjdy_bcounts,gis_bcounts,sjbj_bcounts,xcck_bcounts,
GREATEST(sl_sids,cs_sids,sh_sids,ba_sids,shrk_sids,lpxg_sids,sjdy_sids,gis_sids,sjbj_sids,xcck_sids) msxsids,GREATEST(sl_bareas,cs_bareas,sh_bareas,ba_bareas,shrk_bareas,lpxg_bareas,sjdy_bareas,gis_bareas,sjbj_bareas,xcck_bareas) maxbareas from
--LEAST
(select yymm,useq,uname,bname,sum(sl_bcounts) sl_bcounts,sum(sl_sids) sl_sids,sum(sl_bareas) sl_bareas,sum(cs_bcounts) cs_bcounts,sum(cs_sids) cs_sids,sum(cs_bareas) cs_bareas,
sum(sh_bcounts) sh_bcounts,sum(sh_sids) sh_sids,sum(sh_bareas) sh_bareas,sum(ba_bcounts) ba_bcounts,sum(ba_sids) ba_sids,sum(ba_bareas) ba_bareas,
sum(shrk_bcounts) shrk_bcounts,sum(shrk_sids) shrk_sids,sum(shrk_bareas) shrk_bareas,sum(lpxg_bcounts) lpxg_bcounts,sum(lpxg_sids) lpxg_sids,sum(lpxg_bareas) lpxg_bareas,
sum(sjdy_bcounts) sjdy_bcounts,sum(sjdy_sids) sjdy_sids,sum(sjdy_bareas) sjdy_bareas,sum(gis_bcounts) gis_bcounts,sum(gis_sids) gis_sids,sum(gis_bareas) gis_bareas,
sum(sjbj_bcounts) sjbj_bcounts,sum(sjbj_sids) sjbj_sids,sum(sjbj_bareas) sjbj_bareas,sum(xcck_bcounts) xcck_bcounts,sum(xcck_sids) xcck_sids,sum(xcck_bareas) xcck_bareas from
(select yymm,useq,uname,bname,decode(actname,'受理',bcounts,0) sl_bcounts,decode(actname,'受理',sids,0) sl_sids,decode(actname,'受理',bareas,0) sl_bareas
,decode(actname,'初审',bcounts,0) cs_bcounts,decode(actname,'初审',sids,0) cs_sids,decode(actname,'初审',bareas,0) cs_bareas
,decode(actname,'审核',bcounts,0) sh_bcounts,decode(actname,'审核',sids,0) sh_sids,decode(actname,'审核',bareas,0) sh_bareas
,decode(actname,'备案',bcounts,0) ba_bcounts,decode(actname,'备案',sids,0) ba_sids,decode(actname,'备案',bareas,0) ba_bareas
,decode(actname,'审核入库',bcounts,0) shrk_bcounts,decode(actname,'审核入库',sids,0) shrk_sids,decode(actname,'审核入库',bareas,0) shrk_bareas
,decode(actname,'楼盘修改',bcounts,0) lpxg_bcounts,decode(actname,'楼盘修改',sids,0) lpxg_sids,decode(actname,'楼盘修改',bareas,0) lpxg_bareas
,decode(actname,'数据对应',bcounts,0) sjdy_bcounts,decode(actname,'数据对应',sids,0) sjdy_sids,decode(actname,'数据对应',bareas,0) sjdy_bareas
,decode(actname,'房产GIS入库',bcounts,0) gis_bcounts,decode(actname,'房产GIS入库',sids,0) gis_sids,decode(actname,'房产GIS入库',bareas,0) gis_bareas
,decode(actname,'数据编辑',bcounts,0) sjbj_bcounts,decode(actname,'数据编辑',sids,0) sjbj_sids,decode(actname,'数据编辑',bareas,0) sjbj_bareas
,decode(actname,'现场查看',bcounts,0) xcck_bcounts,decode(actname,'现场查看',sids,0) xcck_sids,decode(actname,'现场查看',bareas,0) xcck_bareas
 from
(select to_char(comitdate,'yyyymm') yymm,useq,uname,bname,actname,sum(bcount) bcounts,sum(sids) sids,sum(barea) bareas from result_static_pwork
group by to_char(comitdate,'yyyymm'),useq,bname,uname,actname order by to_char(comitdate,'yyyymm'),useq,uname,bname,actname)) group by  yymm,useq,uname,bname)
/
