CREATE VIEW I_WFROUTE AS select wfrseq,wfseq,saction,eaction,pointx,pointy,wfrname from syswfroute


/
