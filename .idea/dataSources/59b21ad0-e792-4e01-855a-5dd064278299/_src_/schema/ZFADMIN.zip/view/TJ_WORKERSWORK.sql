CREATE VIEW TJ_WORKERSWORK AS select max(t.tappseq) tappseq,tactname,tbname,tuname,count(*) counts,max(f.appdate) appdate  from apptasks t,appworkflow f where t.tappseq=f.appseq and tstate=0 and wfstate=0 and tuser>0 and tedate is null and to_char(f.appdate, 'yyyy-mm-dd ') between '2008-07-01 ' and '2008-07-30 '  group by tactname,tbname,tuname order by tbname,tactname,tuname


/
