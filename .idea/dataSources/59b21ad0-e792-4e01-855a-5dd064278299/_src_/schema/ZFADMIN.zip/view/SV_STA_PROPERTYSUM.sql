CREATE VIEW SV_STA_PROPERTYSUM AS select sseq,bseq,v_date,stype,tamount,bankname,hcount,tbarea,xz_id,1 as bcount from sta_propertysum_incr
/
