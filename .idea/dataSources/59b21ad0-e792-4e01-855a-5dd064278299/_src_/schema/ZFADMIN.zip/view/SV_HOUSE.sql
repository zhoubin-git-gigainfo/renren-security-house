CREATE VIEW SV_HOUSE AS select sid,hid,v_date,f_date,metno,hno,hdesc,utid,lid,htype,bstru,huse,barea,garea,parea,sarea,uarea,dq,nq,xq,bq,hparent,
hseq,bpric,sattribute,pactnum,plotid,bstruname,husename,rseq,hkind,hpoint,fx,cx,xz_id,ohno from tu_house
union
select sid,hid,v_date,f_date,metno,hno,hdesc,utid,lid,htype,bstru,huse,barea,garea,parea,sarea,uarea,dq,nq,xq,bq,hparent,
hseq,bpric,sattribute,pactnum,plotid,bstruname,husename,rseq,hkind,hpoint,fx,cx,xz_id,ohno from tuh_house a where sid in (select sid from tuh_bldg where bstate=14) and  v_date=(select max(v_date) from tuh_bldg b where a.sid=b.sid)
/
