CREATE function co_get_wzdata_paccount(v_sid number)
  return varchar2 is
    v_location varchar2(4000);
    v_onebarea float;
    vm_buno number;
    vm_recs number default 0;
    vm_clob clob;
    vm_zl   varchar2(4000);
    vm_lp1  number  ;
    vm_lp2  number  ;
    vm_val  varchar2(1000);
    vm_n    number default 1;
    vm_len  number;
begin

    dbms_lob.createtemporary(vm_clob, TRUE);
    select ndata into vm_clob From taw_data where  sid=v_sid;
--靠

         vm_n:=1;
         vm_val:='';
         vm_zl:=' ';
         loop
            vm_lp1:=Instr(vm_clob,'<个人账号>',1,vm_n)+6;
            If vm_lp1=6 or vm_len=0 Then Exit; End if;
            vm_lp2:=Instr(vm_clob,'</个人账号>',1,vm_n);
            vm_val:=substr(vm_clob,vm_lp1,vm_lp2-vm_lp1);
            vm_n:=vm_n+1;
           If Instr(vm_zl,vm_val)=0 Then
               vm_zl:=vm_zl||vm_val;
           End if;
         End loop;
--靠?
         vm_n:=1;
         loop
            vm_lp1:=Instr(vm_clob,'<个人账号>',1,vm_n)+6;
            If vm_lp1=6 or vm_len=0 Then Exit; End if;
            vm_lp2:=Instr(vm_clob,'</个人账号>',1,vm_n);
            vm_val:=substr(vm_clob,vm_lp1,vm_lp2-vm_lp1);
            If length(vm_zl)+length(vm_val)+1>3999 then
               exit;
            end if;
            vm_n:=vm_n+1;
            If Instr(vm_zl,vm_val)=0 Then
               vm_zl:=vm_zl||vm_val||',';
            End if;
         End loop;
         If (substr(vm_zl,length(vm_zl),1)=',') then
            vm_zl:=substr(vm_zl,1,length(vm_zl)-1);
         End If;
    return(vm_zl);

end co_get_wzdata_paccount;
/
