CREATE function co_Total_charts 
                  (--v_Type in number, 
                   --v_catlogs in varchar2,
                   v_SQL in varchar2) Return clob is PRAGMA AUTONOMOUS_TRANSACTION;
  Result clob;
  v_tmp  clob;
  v_text varchar2(6000);
  type rc is ref cursor;
  cur    rc;
  v_cat  varchar2(600);
  v_Val  varchar2(600);  
begin

  dbms_lob.createtemporary(Result,TRUE);
  dbms_lob.createtemporary(v_tmp,TRUE);  
  --dbms_lob.open(Result, dbms_lob. lob_readwrite);
  Result:='<graph caption="#Caption" xAxisName="#xLists" yAxisName="#yLists" decimalPrecision="0" formatNumberScale="0">'||chr(13);
 
  --dbms_lob.writeappend(v_tmp,length(v_text),v_text);
  --dbms_lob.append(Result,v_tmp);
  
  --Select DISTID,sum(barea) from vs_house group by DISTID
  
  Open cur for v_SQL;
  Loop
     Fetch cur into v_cat,v_Val;
     Exit when cur%notfound;
     v_tmp:='<set name="'||to_char(v_cat)||'" value="'||to_char(v_Val)||'" color="'||chr(13);
     dbms_lob.append(Result,v_tmp);
     --dbms_lob.append(Result,v_tmp);
  End loop;
  Close cur;

  --ts_bgclr
  /*
  <graph caption="2008年各月业务量" 
         xAxisName="月" 
         yAxisName="宗" 
         decimalPrecision="0" 
         formatNumberScale="0">
         
  <set name="Jan" value="462" color="AFD8F8" /> 
  <set name="Feb" value="857" color="F6BD0F" /> 
  <set name="Mar" value="671" color="8BBA00" /> 
  <set name="Apr" value="494" color="FF8E46" /> 
  <set name="May" value="761" color="008E8E" /> 
  <set name="Jun" value="960" color="D64646" /> 
  <set name="Jul" value="629" color="8E468E" /> 
  <set name="Aug" value="622" color="588526" /> 
  <set name="Sep" value="376" color="B3AA00" /> 
  <set name="Oct" value="494" color="008ED6" /> 
  <set name="Nov" value="761" color="9D080D" /> 
  <set name="Dec" value="960" color="A186BE" /> 
  </graph>
  */
  --Multi-Series Charts
  
  --Stacked Charts

  --Combination Charts
  
  --Financial Charts
  --dbms_lob.close(Result);
  return(Result);
end co_Total_charts;


/
