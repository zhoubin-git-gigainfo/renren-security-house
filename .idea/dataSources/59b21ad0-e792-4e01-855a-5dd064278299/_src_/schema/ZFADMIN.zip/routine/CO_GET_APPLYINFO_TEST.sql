CREATE function CO_GET_APPLYINFO_test(Bu_No in number)  return
 varchar2 is
  --  co_table PIPELINED is
    My_Type     co_basic;
    v_optMod    char(20);
    v_StCode    char(20);
     
    
    
    
    type rc is ref cursor;
    cur_MdList    rc;
    l_cardnosql       varchar2(600);
    l_updatesql       varchar2(600);
    l_causql  varchar2(600);
    l_querysql varchar2(600);
   
    v_OldBuNo     number;
    
    v_qx_name varchar2(20);
    v_dye_cname varchar2(20);
Begin
--1、初始化自定义类型

    My_Type:=co_basic(null,null,null,null,null,null,0,null,null,null,null,null,null,null);
   


 Select distinct optmod,b.state_id,  a.osseq
    into v_optMod,v_StCode,v_OldBuNo
      From sv_tarbulists a,appdefine b 
     Where a.sseq=Bu_No and a.bseq=b.bseq 
     ;


    If v_StCode='**' Then  --属于变更、换补证业务，基本业务类型及数据与原业务是一致的
       If v_OldBuNo is null Then
          Select max(stype) into v_STCode from to_state t1,tar_olist t2
           Where t1.bid=t2.osseq and t1.sid=t2.hid and t2.sseq=Bu_No;
       Else
          Select max(stype) into v_STCode from to_state where bid=v_OldBuNo;
       End if;
    End if;
    
    
     SELECT t1.cardnosql, t1.updatesql, t1.causql,qx_name,
     dye_cname INTO l_cardnosql,l_updatesql,
     l_causql,v_qx_name,v_dye_cname
    FROM( SELECT to_char(t1.cardnosql) cardnosql, to_char(t1.updatesql) updatesql,
    to_char( t1.causql) causql ,qx_name,
     dye_cname  FROM tar_sldconfig T1 ,ta_bscommon t2
    
     
     WHERE T1.STATE=trim(v_StCode) 
     and t2.sseq=bu_no
     and instr(','||t1.bseqs||',',','||t2.bseq||',')>0
     
     union 
     
     SELECT to_char(t1.cardnosql) cardnosql, to_char(t1.updatesql) updatesql,
    to_char( t1.causql) causql ,qx_name,
     dye_cname  FROM tar_sldconfig T1 ,sales_contract t2
    
     
     WHERE T1.STATE=trim(v_StCode) 
     and t2.sseq=bu_no
     and instr(','||t1.bseqs||',',','||t2.bseq||',')>0
     
      ) t1
   WHERE  ROWNUM=1;
   
    
    IF v_optMod='01' THEN      
    l_querysql:=l_cardnosql;    
    else
       l_querysql:=l_updatesql;
    end if;
  
 if l_querysql is not null then
    l_querysql:=REPLACE(l_querysql,'%sseq%',Bu_No);
     Open cur_MdList for l_querysql ;
    loop
           Fetch cur_MdList into My_Type.Str_1,My_Type.Str_2;
           exit when cur_MdList%notfound; 
          -- PIPE ROW (My_Type);
           --My_Type.num_5:=My_Type.num_5+1;
       end loop;
       close cur_MdList;
   end if;    
       
       
      l_causql:=REPLACE(l_causql,'%sseq%',Bu_No);
     Open cur_MdList for l_causql ;
    loop
           Fetch cur_MdList into My_Type.Str_3,My_Type.Str_4;
           exit when cur_MdList%notfound;
          -- PIPE ROW (My_Type);
           --My_Type.num_5:=My_Type.num_5+1;
       end loop;
       close cur_MdList;
       
      My_Type.Str_5:=v_qx_name;
       My_Type.key:=v_dye_cname;
--    My_Type.Str_6:=v_dye_cname;
       
 --     PIPE ROW (My_Type);
       
    
   
     
    return '';

end CO_GET_APPLYINFO_test;
/
