CREATE function sf_convert_code(cid in number) return varchar2 is
  Result varchar2(40);
begin
  Select appcode.cddisc into Result from appcode where appcode.cdid=cid;
  return(Result);
end sf_convert_code;


/
