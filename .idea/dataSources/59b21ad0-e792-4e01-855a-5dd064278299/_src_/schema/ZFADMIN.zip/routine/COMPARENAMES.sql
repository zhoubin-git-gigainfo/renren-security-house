CREATE function COMPARENAMES(name_1 varchar2,  name_2 varchar2)
return varchar2
is
begin
  DECLARE 
  retValue  number := '2';--1成功2失败
  cursor csr_name_1 is select  str_1 from table(co_get_split(name_1)) ;
  --cursor csr_name_2 is select  str_1 from table(co_get_split(name_2)) ;
  
  v_name_1 varchar2(100);
  --v_name_2 varchar2(100);
 -- v_length number := 0;
  --v_lengthnum number :=0;
  
  begin
 
  --长度不一致，返回失败
   if(length(name_1) <> length(name_2)) then
           retValue := '2';
           return retValue;    
    end if;   
  
   --select  count(str_1) into(v_length) from table(co_get_split(name_1));
  
  open  csr_name_1;
  loop fetch csr_name_1 into v_name_1;
  exit when csr_name_1%notfound;
      
       if(instr(name_2, v_name_1) > 0) then
                retValue := '1';
                else 
                     retValue := '2';    
                     return    retValue;
       end if;
       /* open  csr_name_2;
        loop fetch csr_name_2 into v_name_2;
         exit when csr_name_2%notfound;
        
        if(v_name_1 = v_name_2) then
              v_lengthnum := v_lengthnum+1;
       
        end if;
       
        end loop;
         close   csr_name_2; */
        
  end loop;
  close   csr_name_1;
 
--dbms_output.put_line(v_length || '  ' || v_lengthnum);
 /*if(v_length =v_lengthnum ) then
 retValue := '1';
 else 
   retValue := '2';
 end if;
        */

return retValue;
end;
end COMPARENAMES;
/
