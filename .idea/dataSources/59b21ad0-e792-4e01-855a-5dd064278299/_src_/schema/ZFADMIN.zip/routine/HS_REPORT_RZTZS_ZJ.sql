CREATE function hs_report_rztzs_zj(v_sseq number, v_sqbh number)
return varchar2
is
retStr varchar2(100) := '0';--返回值
v_index number := 0;
v_zj varchar2(100) := '0';
v_sqlb number :=0;

begin
     --一年租金。租金标准为：1.6元/平方米/月，按实际面积计算。
     if(null = v_sseq or null = v_sqbh) then
         return retStr;
     end if;

     select count(*) into v_index from hs_selehouse_bu
     where sseq=v_sseq and sqbh=v_sqbh
     and type=0   and state=1;

     if(0 = v_index) then
        return retStr;
     end if;

     v_index := 0;

     select count(*) into v_index from hs_family
     where f_date is null and sqbh=v_sqbh;

     if(0 = v_index) then
        return retStr;
     end if;

    select sqlb into v_sqlb from hs_family
     where f_date is null and sqbh=v_sqbh;

     if(100002124400 = v_sqlb) then
        select cfgvalue into v_zj from sysconfig where cfgkey='HS_RENTSTAND_GZ';
        
      elsif (100002124281 = v_sqlb) then  
        select cfgvalue into v_zj from sysconfig where cfgkey='HS_RENTSTAND_LZ';
     end if;

     retStr :=  v_zj;
     return retStr;
end;
/
