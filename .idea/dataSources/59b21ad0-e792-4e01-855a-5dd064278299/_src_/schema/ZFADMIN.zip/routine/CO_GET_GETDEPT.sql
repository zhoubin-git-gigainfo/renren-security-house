CREATE function co_get_getDept(vuseq in number) Return integer is
  v_resu integer;
  v_oparent number;
  v_vr number;
  v_oseq number;
begin
   /*select oparent,vr into v_oparent,v_vr from sv_organ where oseq=useq and rownum<2;
   while (v_vr is  null) loop      
      select oseq,oparent,vr into v_oseq,v_oparent,v_vr from sv_organ where oseq=v_oparent;
   end loop;
    v_resu:=v_oseq;*/
    Select distinct PSeq into v_oseq From SV_OrgLevel 
                  Where SType=4 
                  and SSeq in (Select OSEQ From SysUserOrg Where USEQ=vuseq)
                  and ptype=5;
    v_resu:=v_oseq;
    return v_resu;
end co_get_getDept;


/
