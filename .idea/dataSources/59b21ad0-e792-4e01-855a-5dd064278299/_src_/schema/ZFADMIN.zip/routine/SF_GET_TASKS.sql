CREATE function SF_GET_TASKS(SDATE in Date, DATE1 in Date,DATE2 in Date,IntMod in varchar2)
return integer is
  Result integer;
  dtDate1 date;
  dtDate2 date;  
begin
  Result:=0;
  If IntMod='AM' Then 
     Begin 
        dtDate1:=to_date(To_char(SDATE,'yyyy/mm/dd')||' 06:00:00','yyyy/mm/dd hh24:mi:ss');
        dtDate2:=to_date(To_char(SDATE,'yyyy/mm/dd')||' 12:00:00','yyyy/mm/dd hh24:mi:ss');
     End;
  End if;
  If IntMod='PM' Then 
     Begin 
        dtDate1:=to_date(To_char(SDATE,'yyyy/mm/dd')||' 12:00:01','yyyy/mm/dd hh24:mi:ss');
        dtDate2:=to_date(To_char(SDATE,'yyyy/mm/dd')||' 18:00:00','yyyy/mm/dd hh24:mi:ss');
     End;
  End if;
  If (dtDate1>=DATE1 and dtDate1<=DATE2) or (dtDate2>=DATE1 and dtDate2<=DATE2) Then
     Result:=1;
  End if;
  return(Result);
end SF_Get_TASKS;


/
