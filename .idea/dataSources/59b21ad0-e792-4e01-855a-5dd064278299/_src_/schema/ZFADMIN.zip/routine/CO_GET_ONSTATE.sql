CREATE function CO_GET_ONSTATE(BuSeq      in Number,
                                          v_WkNo     in number,
                                          v_SDCounts number) Return number is
  v_Counts      number;
  v_ExcludLimit varchar2(2048);
  v_IncludLimit varchar2(2048);

  v_hasstates varchar2(2048);
  v_states    varchar2(2048);
  v_setcount  number;

begin

  select count(*)
    into v_setcount
    from appdefine
   where (to_char(SDDEF) LIKE '%ExcludLimit%' OR
         to_char(SDDEF) LIKE '%IncludLimit%')
     and bseq = BuSeq;

  if v_setcount = 0 then
   
   Select sum(stcount)
      into v_Counts
      From my_onstlist
     Where no = v_WkNo;
  
    if v_Counts > 0 then
      return 0;
     else
        return 1;
    end if;  
    
    
  
  end if;

  select EXTRACTVALUE(xmltype(to_char(nvl(SDDEF,
                                          '<ROOT>   
 <ExcludLimit></ExcludLimit>
 </ROOT>  '))),
                      '/ROOT/ExcludLimit') ExcludLimit,
         EXTRACTVALUE(xmltype(to_char(nvl(SDDEF,
                                          '<ROOT>   
 <IncludLimit></IncludLimit>
 </ROOT>  '))),
                      '/ROOT/IncludLimit') IncludLimit
    into v_ExcludLimit, v_IncludLimit
    from appdefine
   where bseq = BuSeq;

  --判断是否存在不允许的状态

  if v_ExcludLimit is not null and v_ExcludLimit <> '' then
  
    Select sum(stcount)
      into v_Counts
      From my_onstlist
     Where no = v_WkNo
       and Instr(v_ExcludLimit, stcode) = 0;
  
    if v_Counts > 0 then
      return 0;
    end if;
  
  end if;

  if v_ExcludLimit is not null and v_ExcludLimit <> '' then
  
    Select sum(stcount)
      into v_Counts
      From my_onstlist
     Where no = v_WkNo
       and Instr(v_ExcludLimit, stcode) > 0;
  
    if v_Counts > 0 then
      return 1;
    end if;
  
  end if; 

  -- If v_Counts=0 Then  Return 0; End if;

Return 1;

End CO_GET_ONSTATE;
/
