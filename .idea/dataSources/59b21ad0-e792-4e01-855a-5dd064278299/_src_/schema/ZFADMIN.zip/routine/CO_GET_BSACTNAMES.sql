CREATE function CO_GET_BSACTNAMES(v_bseq in number)
return varchar2 is

  v_actname       varchar2(1000);

Begin
--1、初始化自定义类型
--3、获取用途组合名称和主用途编码


 select to_char(wm_concat(actname)) actname into v_actname from (select actname from syswfactivity t4,appdefine t5 where
   instr(t5.wfseqs,to_char(t4.wfseq) )>0 and t5.bseq=v_bseq order by actord );


  return(v_actname);
end CO_GET_BSACTNAMES;


/
