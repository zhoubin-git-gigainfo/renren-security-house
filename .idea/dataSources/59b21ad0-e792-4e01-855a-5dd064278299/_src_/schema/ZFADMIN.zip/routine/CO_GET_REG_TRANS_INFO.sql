CREATE function co_get_Reg_Trans_Info(Bu_No in number) return clob is
/*  =========== 返回业务的客体登记簿数据（XML格式） ==============
    输入：Bu_No=业务编号
          SD_ID=客体ID
    输出：Result=客体信息（内容：房屋、共有部分）
    接口：被过程co_set_reg_sd_info调用。
    =============================================================*/
  Result clob;
  v_BuNo number;
  v_SDID   number;
  v_val    varchar2(32767);
  v_tag    varchar2(20);
  l_sql    varchar2(32767);
  v_tmp    clob;
  v_bussiness varchar2(32767);
  v_bldg   varchar2(32767);
  v_card   varchar2(32767);
  v_mainbody varchar2(32767);
begin
/*    v_BuNo:=nvl(Bu_No,0);
    v_SDID:=nvl(SD_ID,0);*/
  dbms_lob.createtemporary(Result, TRUE);
    v_bussiness:='Select a.docid	业务号,c.typename 业务名称,''所有权'' 权利方式,
                co_trans_code(a.realsource,4000) 产权来源,co_trans_code(a.realtype,4000) 产别,APPLYVALUE 房屋价值,
                ASSESSVALUE 确认价值,to_char(b.applydate,''yyyy-mm-dd'')	开始时间,to_char(a.realtime,''yyyy-mm-dd'')	结束时间,a.remark	备注
                From realinfo a,document b,typelist c
                Where  a.docid=b.docid and b.typeid=c.typeid and a.docid='||Bu_No;
    v_tmp:=co_get_xml(v_bussiness,'业务信息','业务');
    v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
    dbms_lob.append(Result,v_tmp);
/*    v_bldg:='Select hid 房屋编号,a.metno 用户码,ddesc 行政区,lname 坐落,bdesc 房名,hdesc 房号,a.BSTRUNAME 结构,a.HUSENAME 用途,
                co_convert_code(htype,'') 房型,a.barea 建筑面积,a.parea 套内面积,a.garea 公摊面积,a.bpric 分摊系数,
                a.sarea 阳台面积,b.bkind 房屋类型,co_convert_code(bqut,'') 建筑质量,a.dq 东墙,a.nq 南墙,a.xq 西墙,a.bq 北墙,b.memo 注记
                From tu_house a,tu_bldg b Where a.sid=b.sid and hid='||SD_ID;*/
      v_bldg:='Select hid 房屋编号,a.metno 用户码,ddesc 行政区,lname 坐落,bdesc 房名,hdesc 房号,a.BSTRUNAME 结构,a.HUSENAME 用途,
                co_convert_code(htype,'') 房型,a.barea 建筑面积,a.parea 套内面积,a.garea 公摊面积,a.bpric 分摊系数,
                a.sarea 阳台面积,b.bkind 房屋类型,co_convert_code(bqut,'') 建筑质量,a.dq 东墙,a.nq 南墙,a.xq 西墙,a.bq 北墙,b.memo 注记
                From tu_house a,tu_bldg b,to_relation c Where a.sid=b.sid  and a.hid=c.sid and bid='||Bu_No;
    v_tmp:=co_get_xml(v_bldg,'房屋信息','房屋');
    v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
    dbms_lob.append(Result,v_tmp);
/*    v_mainbody:='Select Decode(MD_TYPE,1,''法人及其他组织'',2,''自然人'',''自然人'') 类别,md_name 名称,co_convert_code(ic_type,'''')||'': ''||IC_No 证明
                From tm_mainbody Where md_id in ('||MD_ID||')';*/
/*    v_mainbody:='select co_get_xml(''Select Decode(MD_TYPE,1,''法人及其他组织'',2,''自然人'',''自然人'') 类别,md_name 名称,co_convert_code(ic_type,'''')||'': ''||IC_No 证明
                From tm_mainbody Where md_id in (||MD_ID||)'',''aa'',''bb'') from dual'; */
       v_mainbody:='Select Decode(MD_TYPE,1,''法人及其他组织'',''自然人'') 类别,md_name 名称,co_convert_code(ic_type,null)||'': ''||IC_No 证明
                   From tm_mainbody a,t_holder b Where a.newmid=b.newmid and docid='||Bu_No;

    v_tmp:=co_get_xml(v_mainbody,'主体信息','主体');
    v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
    dbms_lob.append(Result,v_tmp);
    v_card:='Select cname 证名,cdno||Decode(cstate,2,''(换)'',3,''(补)'','''') 证号,to_char(pdate,''yyyy.mm.dd'') 日期,
                Org_Name 发证机关 From tu_card Where cstate>0 and bid='||Bu_No;
    v_tmp:=co_get_xml(v_card,'权证信息','权证');
    v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
    dbms_lob.append(Result,v_tmp);

    Result:='<?xml version="1.0" encoding="UTF-8"?>'||chr(13)||'<SD_Info>'||Result||chr(13)||'</SD_Info>';

    Return(Result);
end co_get_Reg_Trans_Info;


/
