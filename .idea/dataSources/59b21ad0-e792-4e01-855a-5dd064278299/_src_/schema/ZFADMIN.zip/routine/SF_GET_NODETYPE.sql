CREATE function SF_GET_NODETYPE(CID in number)
return number is
  Result number;
begin
  Select Count(*) into Result From ts_code where parentid=cid;
  return(Result);
end sf_get_nodetype;


/
