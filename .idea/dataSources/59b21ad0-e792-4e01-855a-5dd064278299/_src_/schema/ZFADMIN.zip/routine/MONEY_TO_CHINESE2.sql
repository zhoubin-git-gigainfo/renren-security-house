CREATE function money_to_chinese2(n_LowerMoney in number default null)
RETURN VARCHAR2
AS
v_LowerStr VARCHAR2(200); -- 小写金额
v_UpperPart VARCHAR2(200);
v_UpperStr VARCHAR2(200); -- 大写金额
BEGIN
v_LowerStr := LTRIM(RTRIM(TO_CHAR(ROUND(n_LowerMoney,2),'9999999999999.99')));
IF SUBSTR(v_LowerStr,1,1) = '#' THEN
RETURN '转换金额超过计算范围(计算范围为:计算范围为: 0 - 9,999,999,999,999.99)';
END IF;
FOR I IN 1 .. LENGTH(v_LowerStr) LOOP
SELECT DECODE(SUBSTR(v_LowerStr,LENGTH(v_LowerStr) - I + 1,1),
'.','圆',
'0','零', '1','壹', '2','贰', '3','叁', '4','肆',
'5','伍', '6','陆', '7','柒', '8','捌', '9','玖')||
DECODE(I,1,'分',2,'角',3,NULL,4,NULL,5,'拾',6,'佰',7,'仟',8,'万',
9,'拾',10,'佰',11,'仟',12,'亿',13,'拾',14,'佰',15,'仟',16,'万',NULL)
INTO v_UpperPart FROM DUAL;
v_UpperStr := v_UpperPart||v_UpperStr;
END LOOP;

v_UpperStr := REPLACE(v_UpperStr,'零拾','零');
v_UpperStr := REPLACE(v_UpperStr,'零佰','零');
v_UpperStr := REPLACE(v_UpperStr,'零仟','零');
v_UpperStr := REPLACE(v_UpperStr,'零零零','零');
v_UpperStr := REPLACE(v_UpperStr,'零零','零');
v_UpperStr := REPLACE(v_UpperStr,'零角零分','整');
v_UpperStr := REPLACE(v_UpperStr,'零分','整');
v_UpperStr := REPLACE(v_UpperStr,'零角','零');
v_UpperStr := REPLACE(v_UpperStr,'零亿零万零圆','亿圆');
v_UpperStr := REPLACE(v_UpperStr,'亿零万零圆','亿圆');
v_UpperStr := REPLACE(v_UpperStr,'零亿零万','亿');
v_UpperStr := REPLACE(v_UpperStr,'零万零圆','万圆');
v_UpperStr := REPLACE(v_UpperStr,'万零圆','万圆');
v_UpperStr := REPLACE(v_UpperStr,'零亿','亿');
v_UpperStr := REPLACE(v_UpperStr,'零万','万');
v_UpperStr := REPLACE(v_UpperStr,'零元','元');
v_UpperStr := REPLACE(v_UpperStr,'零零','零');
v_UpperStr := REPLACE(v_UpperStr,'亿万零','亿零');
v_UpperStr := REPLACE(v_UpperStr,'拾零圆整','拾圆整');
v_UpperStr := REPLACE(v_UpperStr,'佰零圆整','佰圆整');
v_UpperStr := REPLACE(v_UpperStr,'仟零圆整','仟圆整');

-- 对壹元以下的金额的处理
v_UpperStr := LTRIM(LTRIM(LTRIM(LTRIM(v_UpperStr,'圆'),'零'),'角'),'分');
IF SUBSTR(v_UpperStr,1,1) = '整' THEN
v_UpperStr := '零元整';
END IF;
RETURN v_UpperStr;
EXCEPTION WHEN OTHERS THEN
--RETURN '发生错误: '||SQLCODE||'--'||SQLERRM;
return '';
END money_to_chinese2;


/
