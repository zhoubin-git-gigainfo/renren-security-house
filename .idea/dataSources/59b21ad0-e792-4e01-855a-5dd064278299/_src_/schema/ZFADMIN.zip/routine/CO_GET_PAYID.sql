CREATE function co_get_PayID return varchar
as
v_num number;
payid varchar2(50);
begin
   v_num:=co_get_seq('JKTZ');
   payid:=v_num||getVerify_ISO7064(v_num);
return payid;
end co_get_PayID;


/
