CREATE function co_get_embody(v_Mems in varchar2,v_Mem in varchar2) return number is
  Result number;
begin
  If v_Mems='*' Then 
     Result:=1;
  Else
     Result:=Instr(','||v_Mems||',',','||v_Mem||',');
  End if;
  Return(Result);
end co_get_embody;


/
