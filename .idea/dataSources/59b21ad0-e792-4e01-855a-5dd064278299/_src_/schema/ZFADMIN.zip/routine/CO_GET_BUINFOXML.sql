CREATE function co_get_buinfoxml(i_sid in number,i_stype varchar2,i_path varchar2) return varchar2 is
  Result varchar2(40);

begin




      SELECT EXTRACTVALUE( XMLTYPE(t3.bu_info),i_path)
      into Result
      FROM TO_STATE T2,TU_APPLISTS T3
 WHERE    i_sid=T2.SID
 AND T2.BID=T3.BU_SSEQ
 AND T2.MODALITY=0
 and t2.stype=i_stype;

  Return(Result);
  Exception when others then return ' ';
end co_get_buinfoxml;
/
