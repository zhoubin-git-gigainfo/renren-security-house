CREATE function co_get_chinesenum2(   /*   2006-03-26
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  最多允许小数点后保留两位有效数（即保留到分）
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                最大值为999999999999.99   （玖千玖百玖拾玖亿玖千玖百玖拾玖万玖千玖百玖拾玖点玖玖元）
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  **/

                                                                                    p_input   number)   return   varchar2   as
      rv           varchar2(4000);
      tmpstr   varchar(4000);
      m             varchar(4000);
      k             varchar(4000);
      i             numeric(38,   2);
      j             int;
      lastj     int;
      lastv     varchar(10);
      lastf     varchar(10);
      laste     varchar(10);
      lastve   varchar(10);
  begin
      i             :=   p_input;
      tmpstr   :=   '零壹贰叁肆伍陆柒捌玖分角元拾佰仟万拾佰仟亿拾佰仟';
      k             :=   '';
    --  m             :=   to_char(i   *   100);
      m :=   to_char(i );
      j             :=   length(m);
      lastve   :=   '';
      lastv     :=   '';
      while   j   >=   1   loop
          lastf   :=   substr(tmpstr,
                                          to_number(substr(m,   length(m)   -   j   +   1,   1))   +   1,
                                          1);
          laste   :=   substr(tmpstr,   10   +   j,   1);
          if   lastf   <>   '零'   then
              if   lastv   =   '零'   then
                  if   (lastj   >=   7   and   j   <=   7)   or   (lastj   >=   11   and   j   <=   11)   or
                        (lastj   >=   3   and   j   <=   2)   then
                      if   j   <=   2   and   lastj   <=   3   then
                          k   :=   k   ||   lastve   ||   lastf   ||   laste;
                      else
                          k   :=   k   ||   lastve   ||   lastv   ||   lastf   ||   laste;
                      end   if;
                  else
                      k   :=   k   ||   lastv   ||   lastf   ||   laste;
                  end   if;
              else
                  k   :=   k   ||   lastf   ||   laste;
              end   if;
              lastj     :=   j;
              lastve   :=   '';

          elsif   lastf   =   '零'   then
              if   lastj   >   11   then
                  lastve   :=   '亿';
              end   if;
              if   lastj   >   7   and   lastj   <   10   then
                  lastve   :=   '万';
              end   if;
              if   (lastj   >   3)   and   (lastj   <   6)   then
                  lastve   :=   '元';
              end   if;
              if   lastv   <>   '零'   then
                  lastj   :=   j;
              end   if;
          end   if;
          lastv   :=   lastf;
          j           :=   j   -   1;
      end   loop;
      if   lastj   >=   3   then
          k   :=   k   ||   '元';
      end   if;
      if   lastj   >=   2   then
          k   :=   k   ||   '整';
      end   if;
      rv   :=   k;
      return   rv;
  end   co_get_chinesenum2;


/
