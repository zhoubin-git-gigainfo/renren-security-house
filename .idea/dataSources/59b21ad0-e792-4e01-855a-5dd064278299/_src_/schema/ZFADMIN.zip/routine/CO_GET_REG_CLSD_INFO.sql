CREATE function co_get_Reg_CLSD_Info(SD_ID in number) return clob is
/*  =========== 返回的客体自然状况登记簿数据（XML格式） ==========
    输入：Bu_No=业务编号
          SD_ID=客体ID
    输出：Result=客体信息（内容：房屋、共有部分）
    接口：被过程co_set_reg_sd_info调用。
    =============================================================*/
  Result clob;
  v_SDID   number;
  v_val    varchar2(32767);
  v_tag    varchar2(20);
  l_sql    varchar2(32767);
  v_tmp    clob;
begin
    v_SDID:=nvl(SD_ID,0);
    dbms_lob.createtemporary(Result, TRUE);
    Declare CURSOR cur_Sql IS --取出需要登记的自然状况信息SQL DML（在）
            Select cfgvalue From sysconfig Where cfgkey like 'CLDJB-%' order by cfgkey;

    BEGIN
        OPEN cur_Sql;
        LOOP
            FETCH cur_Sql INTO v_val;
            EXIT WHEN cur_Sql%NOTFOUND;
            v_tag:=Substr(v_val,1,Instr(v_val,'=')-1);
            l_sql:=replace(Substr(v_val,Instr(v_val,'=')+1),'#SDID#',to_char(v_SDID));
            v_tmp:=co_get_xml(l_sql,v_Tag||'信息',v_tag);
            v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
            dbms_lob.append(Result,v_tmp);
        End loop;
        Close cur_Sql;
    End;
    Result:='<?xml version="1.0" encoding="UTF-8"?>'||chr(13)||'<SD_Info>'||Result||chr(13)||'</SD_Info>';

    Return(Result);
end co_get_Reg_CLSD_Info;


/
