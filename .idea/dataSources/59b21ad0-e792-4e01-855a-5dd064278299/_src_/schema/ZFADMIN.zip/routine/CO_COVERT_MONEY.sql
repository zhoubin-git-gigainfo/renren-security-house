CREATE function CO_COVERT_MONEY(My_Money in number,InteCount in number,DociCount number,FillString varchar2)
return varchar2 is  
    c_money       VARCHAR2(40);
    m_string      VARCHAR2(60) := '亿千佰拾万仟佰拾圆角分';
    n_string      VARCHAR2(40) := '零壹贰叁肆伍陆柒捌玖';
    Ret_Value     VARCHAR2(60) :='';
    c_Val         VARCHAR2(20);
    c_Pix         VARCHAR2(20);
    c_IntVal      VARCHAR2(20);
    c_DocVal      VARCHAR2(20);
    v_Pos         Integer;
  BEGIN
    If My_Money<0 Then c_Pix:='负'; End if;
    c_money:=to_char(abs(My_Money));
    return c_money;
    v_Pos:=instr(c_money,'.');
        
    c_DocVal:=Substr(substr(c_money,v_Pos+1,2)||'00',1,2); 
    c_IntVal:=Substr(Substr(c_money,1, v_Pos-1),-1*InteCount); 
    
    If DociCount=0 Then c_DocVal:='__'; End if;
    If DociCount=1 Then c_DocVal:=Substr(c_DocVal,1,1)||'_'; End if;

    c_IntVal:=Substr('__________'||c_IntVal,-9);    
    c_money:=c_IntVal||c_DocVal;
    
    For I in 1 .. 11 LOOP 
        c_Val:=substr(c_money,I,1);
        If c_Val!='_' Then
           Ret_Value:=Ret_Value||Substr(n_string,to_number(c_Val)+1,1);
           If FillString is null Then 
              Ret_Value:=Ret_Value||Substr(m_string,i,1);
           Else
              Ret_Value:=Ret_Value||FillString;
           End if;
        End if;
    END loop;
    Ret_Value:=c_Pix||Ret_Value;
    return Ret_Value;

exception
  --异常处理
   WHEN OTHERS THEN
      RETURN(SQLERRM);

END co_covert_money;


/
