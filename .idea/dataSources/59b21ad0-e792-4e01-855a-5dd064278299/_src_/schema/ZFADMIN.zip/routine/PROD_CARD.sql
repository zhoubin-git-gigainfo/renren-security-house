CREATE function prod_card(card varchar2) return varchar2 is
type TIArray is table of integer;
type TCArray is table of char(1);
Results varchar2(18);
W       TIArray; --数字数组
A       TCArray; --字符数组
S       integer;
begin
if card is null then
    return '';
end if;
if Length(card) <> 15 then
    return card;
end if;
W       := TIArray(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1);
A       := TCArray('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
Results := SubStr(card, 1, 6) || '19' || SubStr(card, 7, 9);

S := 0;
begin
    for i in 1 .. 17 loop
      S := S + to_number(SubStr(Results, i, 1)) * W(i);
    end loop;
exception
    when others then
      return '';
end;
S       := S mod 11;
Results := Results || A(s + 1);
return(Results);
end prod_card;


/
