CREATE function CO_GET_SAMEFLOOR(strclh in number,strfloor in VARCHAR2)
return VARCHAR2 is
   Fhlen VARCHAR2(1500);
   strcc VARCHAR2(500);
   strbzc VARCHAR2(500);
   i integer;
begin
  strbzc:='';
  i:=0;
    DECLARE
     CURSOR cc_house IS
        select cc from ta_cxx where sseq=strclh and bzcbz=1 and bzc=strfloor order by cc;
     BEGIN
        OPEN cc_house;
        loop
        FETCH cc_house INTO strcc;
        EXIT WHEN cc_house%NOTFOUND;
        if i=0 then
           strbzc:=strcc;
        else
           strbzc:=strbzc||','||strcc;
        end if;
        i:=i+1;
        end loop;      
      CLOSE cc_house;
     END;
  return strbzc;
end;


/
