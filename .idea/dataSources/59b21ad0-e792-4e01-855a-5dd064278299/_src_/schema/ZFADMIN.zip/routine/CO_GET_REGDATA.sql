CREATE function co_get_RegData(v_BuNo in number, v_SdId in number) return clob is
  Result clob;
  v_regBuBo number;
  v_state   integer default 0;
  v_SQl     varchar2(4000);
begin
  Select nvl(disbuno,0),modality into v_regBuBo,v_state
    From to_state Where bid=v_BuNo and sid=v_SdId;
  If v_state=0 Then v_regBuBo:=0; end if;
  v_SQl:='Select to_char(sseq) 业务号,bdesc 业务名,to_char(regbookdate,''yyyy.mm.dd'') 登簿日期,regbookerame 登簿人,caudesc 事由,memo 注记 From taq_enrol where sseq='||to_char(v_regBuBo);
  Select co_get_xml(v_SQl ,'Reg_Info','注销') into Result from dual;
  Return(Result);
end co_get_RegData;


/
