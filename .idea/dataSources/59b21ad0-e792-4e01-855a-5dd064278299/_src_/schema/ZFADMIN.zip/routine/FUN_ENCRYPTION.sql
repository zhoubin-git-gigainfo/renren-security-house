CREATE FUNCTION FUN_ENCRYPTION(
   V_STR VARCHAR2 ,
   V_KEY VARCHAR2
    )
 RETURN VARCHAR2
 AS
   V_KEY_RAW RAW(24) ;
   V_STR_RAW RAW(2000) ;
   V_RETURN_STR VARCHAR2(2000) ;
   V_TYPE PLS_INTEGER ;
 BEGIN
 /*************************************************
   加密函数　FUN_ENCRYPTION　
      入参：
        V_STR 输入明文字符串
        V_KEY 输入密钥字符串，长度为24字节
      返回值：
        V_RETURN_STR　返回密文字符串，约定返回为 16进制密文字符串
     　异常处理：
        此函数不对任何异常做捕捉处理，请相应的程序模块对异常做捕捉处理。

       加密方式：
        密钥位数:AES192   DBMS_CRYPTO.ENCRYPT_AES192
         连接方式:CBC      DBMS_CRYPTO.CHAIN_CBC
         填充方式:PKCS5    DBMS_CRYPTO.PAD_PKCS5

 **************************************************/
   V_KEY_RAW := UTL_I18N.STRING_TO_RAW(V_KEY,'UTF8') ;
   V_STR_RAW := UTL_I18N.STRING_TO_RAW(V_STR,'UTF8') ;
   V_TYPE := DBMS_CRYPTO.ENCRYPT_AES192+DBMS_CRYPTO.CHAIN_CBC+DBMS_CRYPTO.PAD_PKCS5 ;
   V_STR_RAW := DBMS_CRYPTO.ENCRYPT(SRC => V_STR_RAW , typ => V_TYPE, key => V_KEY_RAW) ;
   V_RETURN_STR := RAWTOHEX(V_STR_RAW);
   RETURN V_RETURN_STR ;

 /* EXCEPTION
     WHEN OTHERS THEN
     RETURN SQLERRM||SQLCODE ;   */
 END;
/
