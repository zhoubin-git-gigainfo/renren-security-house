CREATE function CO_get_mtenstate(v_sseq in varchar2)
--取得该租赁关系最新状态
return number is
  Result number(2);
begin
 select vflag into Result from (select sseq,vflag,vdate from u_tenancy where sseq=v_sseq order by vdate desc) where rownum=1;
  return(Result);
end CO_get_mtenstate;


/
