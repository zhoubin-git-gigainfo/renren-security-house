CREATE function co_get_split2(str_List in varchar2) return
    co_table PIPELINED is
    My_Type     co_basic;
    s_pos       number default 1;
    e_pos       number;
    tmp_clob    varchar2(32767) ;
Begin
--1、初始化自定义类型  

    My_Type:=co_basic(0,null,null,null,null,null,0,null,null,null,null,null,null,null);

    
    If Length(str_List)=0 then 
       return ; 
    end if;
    
    tmp_clob:=str_List||',';
    e_pos:=instr(tmp_clob,',');
    
    While e_pos>s_pos Loop    
          My_Type.id:=My_Type.id+1;
          My_Type.STR_1:=substr(tmp_clob,e_pos-s_pos,s_pos);
          If co_IS_NUM(My_Type.STR_1)=1 Then
             My_Type.NUM_1:=to_number(My_Type.STR_1);
          End if;
          PIPE ROW (My_Type);
          s_pos:=e_pos+1;
          e_pos:=instr(tmp_clob,',',s_pos) ;
    End Loop;

    return  ;

end co_get_split2;


/
