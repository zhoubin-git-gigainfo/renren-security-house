CREATE function co_get_xzqid(vparent in number,vid in number) return number is
  Result number;
Begin

  select id into Result from ts_code where parentid=vparent and memo=vid;
  return(Result);
End co_get_xzqid;
/
