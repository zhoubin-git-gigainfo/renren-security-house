CREATE function co_show_state(vm_WkNo in number,vm_BuId in varchar2) return varchar2 is
  Result varchar2(1024);
/*
  vm_appseq:流程号
  vm_BuId：业务类型ID（组合业务用“，”分开；为空值显示所有登记业务的提示状态,在点到业务选择树时可以获取）
  Result：返回信息
*/
begin
  If length(vm_BuId)=0 or vm_BuId is null Then
     --取所有登记业务(vm_BuId为空）需要提示的状态
  --  Select to_char(wm_concat(warnstate)) into Result From appdefine       zk修改 
      -- Where apptype=4 and bseq=decode(vm_BuId,0,bseq,null,bseq,vm_BuId);
        Select to_char(wm_concat(warnstate)) into Result From appdefine
       Where apptype=4 and bseq=decode(nvl(vm_BuId,0),'0',bseq,null,bseq,vm_BuId);
  Else
     --取指定业务（vm_BuId 参数决定）需要提示的状态
     Select to_char(wm_concat(warnstate)) into Result From appdefine,table(co_split(vm_BuId)) Where bseq=num_1;
  End if;

  --取出选出客体已有的、需要提示的状态名称列表
  Select to_char(wm_concat(st_name)) Into Result
    From (Select distinct t4.st_code,t4.st_name
            From ts_state t4,tu_state t3,tu_house t2,my_worksdlist t1
           Where t4.st_code=t3.stype and t3.sid=t2.hid
             and t1.sd_id in (t2.sid,t2.hid,t2.lid)
             and Instr(Result,t3.stype)>0 and no=vm_WkNo
          );
  return(Result);
end co_show_state;


/
