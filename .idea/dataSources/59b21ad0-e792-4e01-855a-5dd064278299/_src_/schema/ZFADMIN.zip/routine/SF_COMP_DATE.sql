CREATE function SF_COMP_DATE(pramPlanDate in date,pramEndDate in date)
return integer is
  Result integer;
begin
  Select Decode(Substr(to_date(to_char(pramPlanDate,'yyyy-mm-dd'),'yyyy-mm-dd')-to_date(to_char(Decode(pramEndDate,null,sysdate,pramEndDate),'yyyy-mm-dd'),'yyyy-mm-dd'),1,1),'-',-1,0,'0',1) into Result from DUAL;
  return Result;
end ;


/
