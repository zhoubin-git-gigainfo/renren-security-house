CREATE function co_get_date(vm_SdId in number,vm_CurDate in date) return date is
  Result date;
begin
  Select max(s_date) into Result From mv_house where s_date<=vm_CurDate and hid=vm_SdId;
  return(Result);
end co_get_date;


/
