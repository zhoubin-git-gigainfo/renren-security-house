CREATE function co_Get_BUData(Bu_No number) return clob is
  Result clob;
  v_BuNo     number;
  v_OldBuNo  number; 
  v_InfoDM   varchar2(20);
  v_val      varchar2(32767);
  v_tag      varchar2(20);
  l_sql      varchar2(32767);
  v_tmp      clob;
  v_UpdMod   varchar2(2);
  v_StCode   varchar2(2);
  v_MDList   varchar2(100);
begin
    v_BuNo:=nvl(Bu_No,0);
    --v_SDID:=nvl(SD_ID,0);
    dbms_lob.createtemporary(Result, TRUE);
    Select Bu_Pix,optmod,b.state_id,nvl(osseq,0) into v_InfoDM,v_UpdMod,v_StCode,v_OldBuNo
      From sv_bulists a,appdefine b where a.sseq=v_BuNo and a.bseq=b.bseq;
      
    If v_STCode='**' then
       If v_OldBuNo is null Then
          Select max(stype) into v_STCode from to_state t1,taq_olist t2
           Where t1.bid=t2.osseq and t1.sid=t2.hid and t2.sseq=v_BUNO;
       Else
          Select max(stype) into v_STCode from to_state where bid=v_OldBuNo;
       End if;
    End if;
 
--1、   获取业务、客体、权证、意见信息（由配置表定义）

    Declare CURSOR cur_Sql IS --取出需要登记的自然状况信息DML Select语句
            Select cfgvalue From sysconfig Where cfgkey like v_InfoDM||'%' order by cfgkey;
    BEGIN
        OPEN cur_Sql;
        LOOP
            FETCH cur_Sql INTO v_val;
            EXIT WHEN cur_Sql%NOTFOUND;
            v_tag:=Substr(v_val,1,Instr(v_val,'=')-1);
            l_sql:=Substr(v_val,Instr(v_val,'=')+1);
            l_sql:=replace(l_sql,'#BU_NO#',to_char(v_BuNo));
            v_tmp:=co_get_xml(l_sql,v_Tag||'信息',v_tag);
            v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
            dbms_lob.append(Result,v_tmp);
        End loop;
        Close cur_Sql;
    End;
    
    
--2、主体信息  

    --获取权利申请人
    Result:=Result||'<申请人>'||chr(13);    
    Select cfgvalue into v_val From Sysconfig Where cfgkey='MD_Apply';
    Select MD_list into v_MDList From ts_state Where st_code=v_StCode;
    l_sql:=Replace(replace(v_val,'#BU_NO#',to_char(v_BuNo)),'#MD_List#',v_MDList);
    
    v_tmp:=co_get_xml(l_sql,'主体信息','主体');
    v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
    dbms_lob.append(Result,v_tmp);
    
    Result:=Result||chr(13)||'</申请人>';

    --获取代理人
    Select cfgvalue into v_val From Sysconfig Where cfgkey='MD_Agent';
    l_sql:=replace(v_val,'#BU_NO#',to_char(v_BuNo));
    v_tmp:=co_get_xml(l_sql,'代理人信息','代理人');
    v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
    dbms_lob.append(Result,v_tmp);

    Result:='<?xml version="1.0" encoding="UTF-8"?>'||chr(13)||'<BU_Info>'||Result||chr(13)||'</BU_Info>';

  Return(Result);
end co_Get_BUData;


/
