CREATE function CO_GET_FEE1(BU_SEQ in number)
RETURN --number 
co_table PIPELINED
IS
    My_Type        co_basic;


Begin
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    Declare CURSOR cur_TItem IS
            Select id,key,num_1,sum(num_2),num_3,num_4,ts_titem.pid,str_2,str_3 
              From ts_titem,table(co_get_feelist(BU_SEQ)) Where id=cid
             Group by id,key,num_1,num_3,num_4,ts_titem.pid,str_2,str_3;
    Begin
        Open cur_TItem;
        Loop
            Fetch cur_TItem Into My_Type.id,My_Type.key,My_Type.num_1,My_Type.num_2,My_Type.num_3,My_Type.num_4,My_Type.num_5,My_Type.STR_2,My_Type.STR_3;
            Exit When cur_TItem%NotFound;
            PIPE ROW (My_Type);
        End loop;
        Close cur_TItem;
    End;                                 
    Return  ;
End CO_GET_FEE1;


/
