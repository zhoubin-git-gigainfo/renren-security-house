CREATE function co_get_CGGLBABH return varchar
as
v_num number;
payid varchar2(50);
counts char(1);
V_RQ varchar2(12);
begin
   V_RQ:=to_char(sysdate,'yyyymmdd');
   V_RQ:=V_RQ||to_char(co_get_seq('CGGL'));
return V_RQ;
end co_get_CGGLBABH;
/
