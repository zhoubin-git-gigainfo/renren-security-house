CREATE function CO_GET_SDSTATE(BuSeq in Number,v_WkNo in number,v_SDCounts number) Return number is
  v_Counts  number;
  v_needs   varchar2(2048);
  v_unneeds varchar2(2048);
begin

   Select needs,unneeds into v_needs,v_unneeds From appdefine Where bseq=BuSeq;
   Select to_char(wm_concat(str_1)) into v_needs From (Select str_1 From table(co_split(v_needs)) Order by str_1);
   v_needs:='%'||Replace(v_needs,',','%')||'%';

   --判断是否存在不允许的状态
   Select max(Instr(','||v_unneeds||',',','||stcode||',')) into v_Counts From my_stlist Where no=v_WkNo;
   If v_Counts>0 Then Return -1*v_Counts; End if;
   
   --判断是否具备必须的状态
   Select nvl(to_char(wm_concat(stcode)),' ') into v_unneeds From (Select stcode From my_stlist Where stcount>=v_SDCounts and no=v_WkNo Order by stcode);
   
   Select count(*) into v_Counts From dual Where v_unneeds like v_needs ;
   
   If v_Counts=0 Then  Return 0; End if;
   
   Return 1;
   
End co_get_SDState;



/
