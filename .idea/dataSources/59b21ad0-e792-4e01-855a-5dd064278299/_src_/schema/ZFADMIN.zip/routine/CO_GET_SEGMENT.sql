CREATE function co_get_segment(v_type in number,v_value in number default 0) return varchar2 is
  Result varchar2(20);
  --v_val  number;
begin
  --v_val:=nvl(v_value,0);
  Select sg_name into Result From ts_segment 
   Where sg_minval<=v_value and sg_maxval>v_value and sg_type=v_type;
  Return Result;
  Exception when others then return '不详';
end co_get_segment;


/
