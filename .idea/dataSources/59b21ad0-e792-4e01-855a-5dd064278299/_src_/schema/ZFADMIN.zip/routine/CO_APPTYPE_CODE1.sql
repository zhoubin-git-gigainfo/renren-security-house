CREATE function co_apptype_code1(apptype in number,bid in varchar2) return varchar2 is

  Result1 varchar2(40);
begin
 --Result:=-1;
     --bid:=bid||
   --  Select tname into Result
    --   From (select name tname,bk_hue,cname,ckey from ts_code) 
    --  Where bk_hue='APPLYTYPE' and cname=to_char(apptype) and instr(ckey,bid)>0;
       
        Select nvl(name,-1) into Result1
       From ts_code 
       Where bk_hue='APPLYTYPE' and cname=to_char(apptype);-- and instr(nvl(ckey,-1),bid)>0;
       dbms_output.put_line('通过');  
    if Result1 =-1 then--假如没有定义则使用默认的ckey='DEFAULT'
      Select name into Result1
      From (select name,bk_hue,cname,ckey from ts_code)
       Where bk_hue='APPLYTYPE' and cname=to_char(apptype) and ckey='DEFAULT';
     End if;
  Return Result1;
 -- Exception when others then return '不详';
    Exception when others then
       -- dbms_output.put_line(sqlcode||'：'||sqlerrm);  
       return '';
end co_apptype_code1;


/
