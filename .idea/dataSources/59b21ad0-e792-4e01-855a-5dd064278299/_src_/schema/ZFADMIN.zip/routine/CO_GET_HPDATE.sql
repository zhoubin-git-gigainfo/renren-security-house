CREATE function co_get_hpdate(vm_SdId in number,vm_CurDate in date) return date is
  Result date;
begin
  Select max(v_date) into Result From tu_hprice where v_date<=vm_CurDate and hid=vm_SdId;
  return(Result);
end co_get_hpdate;
/
