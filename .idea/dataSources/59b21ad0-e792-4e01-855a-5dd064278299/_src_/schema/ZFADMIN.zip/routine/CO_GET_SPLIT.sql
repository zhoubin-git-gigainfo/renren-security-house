CREATE function co_get_split(str_List clob) return
    co_table PIPELINED is
    My_Type     co_basic;
    --l_recs      integer;
    l_pos       integer;
    --l_list      varchar2(32767):=str_List;
    l_list      clob:=str_List;
Begin
--1、初始化自定义类型
       
    My_Type:=co_basic(1,null,null,null,null,null,0,null,null,null,null,null,null,null);
    If instr(l_list,',')=0 Then My_Type.Id:=0;End if;
    loop
         l_pos:=instr(l_list,',');
         If  l_pos>0 Then
             My_Type.str_1:=substr(l_list,1,l_pos-1);
             PIPE ROW (My_Type);
             My_Type.id:=My_Type.id+1;
             l_list:=substr(l_list,l_pos+1);
         Else
             My_Type.str_1:=l_list;
             PIPE ROW (My_Type);
             exit;
         End if;
    End loop
    return ;

end co_get_split;


/
