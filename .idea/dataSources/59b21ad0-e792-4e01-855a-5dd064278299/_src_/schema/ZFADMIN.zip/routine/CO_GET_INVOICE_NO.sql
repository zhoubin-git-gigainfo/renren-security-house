CREATE function co_get_INVOICE_no(T_ID in  number) return number is
  Result number;
  v_seed varchar2(60);
begin

  Select count(*) into Result From ts_ticket Where ts_ticket.id=nvl(T_ID,0);
  If Result=0 then
     EXECUTE IMMEDIATE 'Select co_seq_invoice.nextval From Dual' into Result;
  Else
     Select tnoname into v_seed From ts_ticket Where ts_ticket.id=nvl(T_ID,0);
     EXECUTE IMMEDIATE 'Select co_seq_pj_'||v_seed||'.nextval From Dual' into Result;
  End if;   
  return(Result);
end co_get_INVOICE_no;


/
