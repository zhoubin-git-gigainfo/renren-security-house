CREATE function co_get_st_code(vparent in number,vid in number,vdefault in number) return number is
  Result number;
  recs integer;
Begin
  select count(*) into recs from TS_ST_CODE where parentid=vparent and  id=vid;
  If (recs=0) then
    Result:=vdefault;
  else
     select dm into Result from TS_ST_CODE where parentid=vparent and  id=vid;
  End If;
  return(Result);
End co_get_st_code;
/
