CREATE function CO_GET_BUlist_WG(App_bseq integer,vm_wkno in number,vm_isbatch in number)
  RETURN co_table PIPELINED is
  --RETURN number is
  PRAGMA AUTONOMOUS_TRANSACTION;
  My_Type         co_basic;
  v_Recs          integer;
  Menu_Type       integer;
  v_bseq          number(12);
  v_bid           varchar2(20);
  v_bname         varchar2(60);
  v_needs         varchar2(200);
  v_unneeds       varchar2(200);
  v_group         varchar2(200);
  v_bath          integer;
  v_Single        integer default 100000;
  v_More          integer default 0;
  v_MenuID        integer default 10;
  v_sdCount       integer;
  v_gwfseq        number(12);
  --Type strArray  is table of varchar2(10);
  --Type numArray  Is table of number;
  --v_StCode        strArray:=strArray();
  --v_StTotl        numArray:=numArray();
  v_WkNo          integer default 1;
  v_tempCount    integer;
  v_estateCount     integer;
  v_selectHouseCount integer;--选择房屋的数量
  v_hasStateCount   integer;
  v_hasWGhouse        integer;--项目下物业用房数量(房屋用途)

Begin
  v_tempCount:=0;
  v_estateCount:=0;
  v_estateCount:=0;
  v_hasStateCount:=0;
  v_hasWGhouse:=0;
--1、初始化自定义类型
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);

    Select apptype,co_seq_work.nextval into Menu_Type,v_WkNo
      From Appdefine Where bseq=app_bseq;

    Insert into My_SDList(No,Sd_Id) Select distinct v_WkNo,hid From tu_house t1,my_worksdlist t2
     Where (t1.sid=t2.SD_ID or t1.lid=t2.SD_ID or t1.hid=t2.SD_ID)
       --and nvl(t1.sattribute,0)!=145001
       and no=vm_wkno;

    --如果客体有业务在办
    Select Count(*) into v_recs From to_state a,appdefine b,my_worksdlist c
     Where a.bseq=b.bseq and apptype in (531,4) 
     and modality=1 and a.sid=c.sd_id and c.no=vm_wkno ;

    If v_Recs>0 Then
       Rollback;
       return ;
    End if;

    --计算客体数量->v_sdCount变量
    Select count(*) into v_sdCount From My_SDList Where no=v_WkNo;

    If v_sdCount=0 and (Menu_Type=2 or Menu_Type=5 or Menu_Type=12) then
        Rollback;
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:='单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        PIPE ROW (My_Type);
      
  
        Return ;
    End if;

  /*  If v_sdCount=0 Then
       Rollback;
       Return ;
    end if;*/

    --计算所有状态和客体数my_stlist）
    Insert into my_stlist(NO,stcode,stcount) Select v_WkNo,stype,count(*) totl
                            From (Select distinct sid,stype from tu_state t1,My_SDList t2
                                   Where sid=sd_id and stype>'3' and no=v_WkNo)
                           Group by Stype;
    --生命周期状态
    Insert into my_stlist(NO,stcode,stcount) Select v_WkNo,bstate,count(*) From tu_bldg t1,tu_house t2,my_sdlist t3
                           Where t1.sid=t2.sid and hid=sd_id and no=v_WkNo
                           Group by bstate;
    --测量状态
    Insert into my_stlist(NO,stcode,stcount) Select v_WkNo,t0.sstate,count(*) From tu_bldg t0,tu_house t1,my_sdlist t2
                           Where t0.sid=t1.sid and t1.hid=t2.sd_id and no=v_WkNo
                           Group by sstate;
    Commit;

   -- select count(a1.stype) into v_hasStateCount from 
   -- (select distinct stype from my_worksdlist a1,to_state a2 where a1.no=vm_wkno  
   -- and a1.sd_id=a2.sid and a2.modality=0 and a2.f_date is null) a1,appdefine a2
   -- where a2.apptype=531 and a2.unneeds is not null and instr(a2.unneeds,a1.stype)>0;

    --计算项目下房屋用途为物业用房的数量 >0则可以启动物管用房设立
  --  select count(distinct u2.hid) into v_hasWGhouse from 
  --  tu_pbldg u0,tu_house u2,my_worksdlist u3 
  --  where u0.pid=u3.sd_id and u0.sid=u2.sid and u2.huse=1146415 and u3.no=vm_wkno;

    --计算前台所选择房屋的数量
 --   select    count(*) into v_selectHouseCount from my_worksdlist where no=vm_wkno;

--计算所选择房屋里有临时物管用房状态的房屋数量
  --  select    count(*) into v_tempCount   from to_state a1,my_worksdlist a2 where a1.sid=a2.sd_id and a2.no=vm_wkno and a1.modality=0 and a1.stype='901';
--计算所选择房屋里有共管状态的房屋数量  
 -- select    count(*) into v_estateCount   from to_state a1,my_worksdlist a2 where a1.sid=a2.sd_id and a2.no=vm_wkno and a1.modality=0 and a1.stype='91';
    DECLARE CURSOR MyCur IS


            Select tt0.BSEQ,BID,tt0.BNAME,tt0.needs,tt0.unneeds,Replace(','||bugroup||',',' ','') bugroup,isbath,Gwfseq
              From Appdefine tt0
             Where  tt0.apptype=531 and tt0.optmod='01' and tt0.state_id='91' ;
            -- union
            -- Select tt0.BSEQ,BID,tt0.BNAME,tt0.needs,tt0.unneeds,Replace(','||bugroup||',',' ','') bugroup,isbath,Gwfseq
           --  from Appdefine tt0
           --  where tt0.apptype=531 and tt0.optmod='01' and tt0.state_id='901' and 2=vm_isbatch and v_tempCount=0 and v_hasStateCount=0
          --   union
          --    Select tt0.BSEQ,BID,tt0.BNAME,tt0.needs,tt0.unneeds,Replace(','||bugroup||',',' ','') bugroup,isbath,Gwfseq
          --   from Appdefine tt0
          --    where tt0.apptype=531 and tt0.optmod='10' and tt0.state_id='91' and 2=vm_isbatch and v_estateCount=v_selectHouseCount
          --    union
           --   Select tt0.BSEQ,BID,tt0.BNAME,tt0.needs,tt0.unneeds,Replace(','||bugroup||',',' ','') bugroup,isbath,Gwfseq
          --   from Appdefine tt0
          --    where tt0.apptype=531 and tt0.optmod='10' and tt0.state_id='901' and 2=vm_isbatch and v_tempCount=v_selectHouseCount;
             --and co_get_SDState(tt0.BSEQ,v_WkNo,v_sdCount)=1
                -- tt0.apptype=decode(vm_isbatch,'1',531,'2',532,'3',533,'9',-100)    
            -- Order by decode(Optmod,'01',1,'10',9,2),bid;

    Begin
       OPEN MyCur;
       LOOP
           FETCH MyCur INTO v_bseq,v_bid,v_bname,v_needs,v_unneeds,v_group,v_bath,v_gwfseq;
           EXIT WHEN MyCur%NOTFOUND;

           My_Type.id:=v_MenuID;
           My_Type.key:=v_bid;
           My_Type.str_1:=v_bname;
           My_Type.num_1:=1;
           My_Type.str_2:=to_char(v_bseq);
           My_Type.str_3:=v_bid;
           My_Type.num_2:=v_Single+v_MenuID;
           My_Type.num_5:=null;
           PIPE ROW (My_Type);
           v_MenuID:=v_MenuID+1;

     
       END loop;
       CLOSE MyCur;
    End;
    My_type.str_2:=null;
    My_type.str_3:=null;
    If v_Single=100000 Then
      My_type.id:=1;
      My_type.KEY:='1';
      My_type.str_1:='单笔业务';
      My_type.num_1:=-1;
      My_type.num_2:=100000;
      PIPE ROW (My_Type);
    End if;

    Return ;
end ;


/
