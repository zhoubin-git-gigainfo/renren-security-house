CREATE function co_get_substr(str in varchar2,fnum in number,enum in number) Return varchar2 is
  v_tmp  varchar2(200);
  v_keep varchar2(200);
  v_keepall varchar2(400);
  v_cc number;
  v_cc_all number;
  v_resu varchar2(200);
begin
  If str is null Then Return '找不到数据！！！';end if;
  if fnum=0 then
    v_tmp:=substr(str,0,enum);
    v_keep:=translate(v_tmp,'0123456789','x');
    v_cc:=length(v_tmp)-length(v_keep);
     v_resu:=substr(str,0,enum+v_cc/2);
    else
      v_tmp:=substr(str,0,enum+fnum-1);
      --0-enum总共含有多少个数字
      v_cc_all:=length(v_tmp)-length(translate(v_tmp,'0123456789','x'));
      v_keep:=substr(str,0,fnum-1);
       --fnum之前含有多少个数字
       v_cc:=length(v_keep)-length(translate(v_keep,'0123456789','x'));
       v_resu:=substr(str,fnum+v_cc/2,enum+(v_cc_all-v_cc)/2);
      end if;
    return v_resu;
end co_get_substr;


/
