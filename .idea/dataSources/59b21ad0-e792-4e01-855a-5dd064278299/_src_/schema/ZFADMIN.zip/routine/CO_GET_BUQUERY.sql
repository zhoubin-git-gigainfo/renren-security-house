CREATE function co_get_buquery(v_buNo in varchar2, v_buType in varchar2, v_Caption in varchar2,v_Apply in varchar2,v_Wkname in varchar2) return varchar2 is
  Result varchar2(32767);
begin

   If not trim(v_Wkname) is null Then
      Result:=Result||' and exists (Select 1 From apptasks Where tuname='''||v_Wkname||''' and tappseq=appseq)';
   End if;
   If not trim(v_Apply) is null Then
      Result:=Result||' and exists (Select 1 From ta_agent Where agentname like ''%'||v_Apply||'%'' and Maintypeid in(1,2) and ta_agent.sseq=sv_bulists.sseq)';
   End if;
    If not trim(v_buType) is null Then
      Result:=Result||' and bname like ''%'||v_buType||'%''';
   End if;

   If not trim(v_Caption) is null Then
      Result:=Result||' and subject like ''%'||v_Caption||'%''';
   End if;

   If not trim(v_buNo) is null Then
      Result:=Result||' and (sseq='||v_buNo||' or appseq='||v_buNo||')';
   End if;

   If Result is null Then
      Result:='Select sseq,subject,appseq From sv_bulists Where 1=0';
   Else
      Result:='Select sseq,subject,appseq From sv_bulists where 1=1 '||Result||' order by sseq desc';
   End if;
   return(Result);
end co_get_buquery;


/
