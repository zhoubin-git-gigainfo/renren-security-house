CREATE function CO_GET_BUmenu1_bak(App_bseq integer,SD_IDs in varchar2)
  RETURN co_table PIPELINED is
  My_Type         co_basic;
  v_Recs          integer;
  Menu_Type       integer;
  v_bseq          number(12);
  v_bid           varchar2(20);
  v_bname         varchar2(60);
  v_needs         varchar2(200);
  v_unneeds       varchar2(200);
  v_group         varchar2(200);
  v_bath          integer;
  v_Single        integer default 0;
  v_More          integer default 0;
  v_unite         integer default 0;
  v_MenuID        integer default 10;

Begin
--1、初始化自定义类型
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    Select apptype into Menu_Type From Appdefine Where bseq=app_bseq;
    
    If not SD_IDs is null Then
       Execute immediate
       'Select Count(*) From to_state a,appdefine b Where a.bseq=b.bseq and apptype='||Menu_Type||' and modality=1 and sid in ('||SD_IDs||')' into v_recs ;
       If v_Recs>0 Then return; end if;
    End if;
    
    DECLARE CURSOR MyCur IS
        Select BSEQ,BID,BNAME,needs,unneeds,Replace(','||bugroup||',',' ',''),isbath
          From Appdefine
         Where apptype=Menu_Type and bseq!=App_bseq
           and CO_GET_SDSTATE2(SD_IDs,needs,unneeds)=1
         order by Decode(State_Id,'00','50',State_Id),decode(Optmod,'01',1,'10',9,2),bid;
    Begin
       OPEN MyCur;
       LOOP
           FETCH MyCur INTO v_bseq,v_bid,v_bname,v_needs,v_unneeds,v_group,v_bath;
           EXIT WHEN MyCur%NOTFOUND;
 
           v_Single:=10000;
           My_Type.id:=v_MenuID;
           My_Type.key:=v_bid;
           My_Type.str_1:=v_bname;
           My_Type.num_1:=1;
           My_Type.str_2:=to_char(v_bseq);
           My_Type.str_3:=v_bid;
           My_Type.num_2:=v_Single+v_MenuID;
           PIPE ROW (My_Type);
           v_MenuID:=v_MenuID+1;
   
           if v_bath=1 Then
               v_More:=20000;
               My_Type.id:=v_MenuID;
               My_Type.key:=v_bid;
               My_Type.str_1:=v_bname;
               My_Type.num_1:=2;
               My_Type.str_2:=to_char(v_bseq);
               My_Type.str_3:=v_bid;
               My_Type.num_2:=v_More+v_MenuID;
               PIPE ROW (My_Type);
               v_MenuID:=v_MenuID+1;
           End if;
            
           If  v_group!=',,' Then
               v_unite:=30000;
               My_Type.id:=v_MenuID;
               My_Type.key:=v_bid;
               My_Type.str_1:=v_bname;
               My_Type.num_1:=3;
               My_Type.str_2:=to_char(v_bseq);
               My_Type.str_3:=v_bid;
               My_Type.num_2:=v_unite+v_MenuID;
               PIPE ROW (My_Type);
               v_MenuID:=v_MenuID+1;
                            
               DECLARE CURSOR MyChildMenu IS
                       Select BID,My_Type.id,BNAME,My_Type.str_2||','||TO_CHAR(BSEQ),My_Type.str_3||','||BID 
                        From Appdefine
                        Where instr(v_group,','||to_char(bseq)||',')>0
                        order by Decode(State_Id,'00','50',State_Id),decode(Optmod,'01',1,'10',9,2),bid;
               Begin
                   Open MyChildMenu;
                   LOOP
                       FETCH MyChildMenu INTO My_Type.KEY,My_Type.num_1,My_Type.str_1,My_Type.str_2,My_Type.str_3;
                       EXIT WHEN MyChildMenu%NOTFOUND;
                       My_Type.id:=v_MenuID;
                       My_Type.num_2:=v_unite+v_MenuID;
                       PIPE ROW (My_Type);
                       v_MenuID:=v_MenuID+1;
                   End loop;
                   CLOSE MyChildMenu;
               End;             
           End if;

       END loop;
       CLOSE MyCur;
    End;
    
    If v_Single=10000 Then
      My_type.id:=1;
      My_type.KEY:='1';
      My_type.str_1:='单笔业务';
      My_type.num_1:=-1;
      My_type.num_2:=10000;
      PIPE ROW (My_Type);
    End if;
    If v_More=20000 Then
      My_type.id:=2;
      My_type.KEY:='2';
      My_type.str_1:='批量业务';
      My_type.num_1:=-1;
      My_type.num_2:=20000;
      PIPE ROW (My_Type);
    End if;
    If v_unite=30000 Then
      My_type.id:=3;
      My_type.KEY:='3';
      My_type.str_1:='组合业务';
      My_type.num_1:=-1;
      My_type.num_2:=30000;
      PIPE ROW (My_Type);
    End if;

    Return;
end CO_GET_BUmenu1_bak;


/
