CREATE function co_get_apasunid(Object_Type in varchar2) return varchar2 is
  Result varchar2(32);
Begin

  select 1||lpad( to_char(co_seq_apas_unid.nextval) , 30, '0')into Result   from  dual ;     
 -- Execute immediate 'Select CO_SEQ_'||Object_Type||'.nextval From dual' into Result;
  return(Result);
End co_get_apasunid;



/
