CREATE function co_get_bzdx_newstate(sqbh in number )
RETURN VARCHAR2
AS
v_spelev VARCHAR2(200); -- 小写金额
BEGIN

/*
资格  GQUATION
摇号  WAITING     补贴 HSYBHB
复审  EXAMINATION 补贴 HSYBHB
已选  HSYX        补贴 HSYBHB
已入住   HSRZ
已签   HSYQ*/
 select concatstr(st_name) st_name into v_spelev from (
select  t2.st_name   st_name from to_mbstate t1, ts_mbstate t2 where v_date in(
select  max(v_date) v_date from to_mbstate t1   where md_id=sqbh
 and   ( stype in('GQUATION','WAITING','HSYX','HSYQ' ) )
 and t1.f_date is null  ) and md_id=sqbh
  and t1.f_date is null and t1.stype=t2.st_code
  and stype in('GQUATION','WAITING','HSYX','HSYQ' )

union
select t2.st_name from to_mbstate t1, ts_mbstate t2 where
t1.stype='HSYBHB'
and md_id=sqbh and t1.f_date is null
 and t1.stype=t2.st_code ) ;


RETURN v_spelev;
EXCEPTION WHEN OTHERS THEN
--RETURN '发生错误: '||SQLCODE||'--'||SQLERRM;
return '';
END co_get_bzdx_newstate;
/
