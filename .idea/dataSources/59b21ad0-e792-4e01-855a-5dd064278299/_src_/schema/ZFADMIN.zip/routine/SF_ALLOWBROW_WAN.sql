CREATE function SF_ALLOWBROW_WAN(READERS in varchar2,AUTHOR in number,USID in varchar2,ADMINVALUE in varchar)
return number as
 IsOrgan number;
 strOrg varchar2(2048);
 UserID number:=to_number(UsID);
Begin
 --读者域全开放
 --If nvl(Readers,'~')='~' then return 1;end if;

 --当连接作者、管理员、读者信息
 strOrg:=','||to_char(nvl(Author,''))||','||to_char(nvl(ADMINVALUE,''))||','||nvl(READERS,'')||',';

 Select count(*) into IsOrgan from sv_organ a, sv_organ b
  where b.oseq=UserID and b.Otype=9 and not (a.OTYPE=9 and a.oseq!=UserID)
    and InStr(b.OCODE,a.ocode)=1
    and InStr(strOrg,','||to_char(a.oseq)||',')>0;
 If IsOrgan>0 then Return 1 ;end if; --文档作者、管理员、读者返回1

 Return 0;
End;


/
