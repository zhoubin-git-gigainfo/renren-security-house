CREATE function CO_GET_OPLIST(SIDs in varchar2,vm_type in number)
RETURN co_table PIPELINED
  /*输入参数说明：
  SIDs：房屋对象IDs
  vm_Type: 业务视角
           1=房屋生命周期
           2=测量
           3=期房市场管理
           4=登记
           5=二手市场
*/
IS
  My_Type   co_basic;
  v_date    date;
  v_code    varchar2(12);
  v_name    varchar2(20);
  v_color   varchar2(10);

Begin
--一、初始化自定义类型
  My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);

--1、、取生命周期状态

--  Select bstate,ST_BGCLR into My_Type.Key,My_Type.str_1 From sv_realobj,ts_state Where OSEQ=SD_ID and bstate=st_code;

--2、、取限制状态
  DECLARE CURSOR MyCur IS
          Select v_date,ts_state.st_code,to_state.St_name,ST_BGCLR From to_state,ts_state
           Where to_state.sid=SIDs and to_state.f_date is null
             and to_state.stype=ts_state.st_code
--             and ts_state.st_type>2
           Order by ts_state.st_code,v_date;
  Begin
     OPEN MyCur;
     Loop
         FETCH MyCur INTO v_date,v_code,v_name,v_color;
         EXIT WHEN MyCur%NOTFOUND;
         My_Type.date1:=v_date;
         My_Type.key:=v_color;
         IF length(My_Type.Str_2)>0 Then
            My_Type.Str_2:=','||My_Type.Str_2;
            My_Type.Str_3:='，'||My_Type.Str_3;
         End if;
         My_Type.Str_2:=v_code||My_Type.Str_2;
         My_Type.Str_3:=v_name||My_Type.Str_3;
     END loop;
     CLOSE MyCur;
  End;
/*
--3、、取业务状态
  DECLARE CURSOR MyCur IS
          Select v_date,ts_state.st_code,ST_BGCLR From to_state,ts_state
           Where to_state.sid=SD_ID and to_state.f_date is null
             and ts_state.st_type=vw_Type
           Order by v_date,ts_state.st_code desc ;
  Begin
     OPEN MyCur;
     FETCH MyCur INTO My_Type.date1,My_Type.Str_4,My_Type.Str_5;
     CLOSE MyCur;
  End;

*/

/*
  Mr_DymCur:=DBMS_SQL.OPEN_CURSOR;
  My_LSQL:='Select ts_state.st_code From tu_state,ts_state Where Instr(:IDs,'',''||to_char(tu_state.sid)||'','')>0
     and tu_state.stype=ts_state.st_code and Instr(:VWs,to_char(ts_state.st_type))>0' ;

  DBMS_SQL.PARSE(Mr_DymCur,My_LSQL,DBMS_SQL.V7);
  DBMS_SQL.BIND_VARIABLE(Mr_DymCur,':IDs',v_Reals);
  DBMS_SQL.BIND_VARIABLE(Mr_DymCur,':VWs',ST_View);
  Mr_Ret1:=DBMS_SQL.EXECUTE(Mr_DymCur);
*/

--三、返回结果（）
  PIPE ROW (My_Type);
  Return ;
end co_get_oplist;


/
