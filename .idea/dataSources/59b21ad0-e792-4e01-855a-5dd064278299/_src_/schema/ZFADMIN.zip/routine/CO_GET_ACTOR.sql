CREATE function CO_GET_ACTOR(BID in Number,AType number)
RETURN co_table PIPELINED
IS
  My_Type   co_basic;
  v_Fill    varchar2(3000);
  v_Sgem    varchar2(3000);
begin
--1、初始化自定义类型
  My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
  --Select Area3 into v_Fill From ta_func Where sseq=BID and area2=AreaNo;  
  v_Fill:='01@1~5,2@1&4~5&8~10&11&13&16~20,6@1~5';

        My_Type := co_basic(0,'Agent',null,null,null,null,null,null,null,null,null,null,null,null);
        PIPE ROW (My_Type);

     return;
end co_get_Actor;


/
