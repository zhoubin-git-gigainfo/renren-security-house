CREATE function SF_GET_LAYN(zid in number,v_use in number,v_stru in number)
return varchar2 is
  Result varchar2(512);
  v_ename varchar2(60);
begin
  Result:='';
  DECLARE  
     CURSOR c_emp IS 
            Select b.ldesc from tu_house a,tu_layer b
             where a.sid=zid and b.sid=zid and a.lid=b.lid
               and a.huse=v_use and a.bstru=v_stru
             group by b.ldesc; 
     BEGIN  
        OPEN c_emp;  
        LOOP  
           FETCH c_emp INTO v_ename; 
           EXIT WHEN c_emp%NOTFOUND;
           If length(Result)>0 then
              Result:=Result||'，';
           End if;
           Result:=Result||v_ename; 
        END loop;
        CLOSE c_emp;
     End;
  return(Result);
end sf_get_layn;


/
