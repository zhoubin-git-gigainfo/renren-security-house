CREATE function co_get_spelev(dimname_path in varchar,p_lev  in number)
RETURN VARCHAR2
AS
v_spelev VARCHAR2(200); -- 小写金额
v_lev   number;
BEGIN
 v_spelev:= substr(dimname_path,
 instr(dimname_path,'/',1,p_lev)+1,
 instr(dimname_path,'/',1,p_lev+1)-
 instr(dimname_path,'/',1,p_lev)-1 );
 v_lev:=p_lev;
 
 /*
 Loop
  
 exit when v_spelev is not null  ;
 
 v_lev:=v_lev-1;
 v_spelev:= substr(dimname_path,
 instr(dimname_path,'/',1,v_lev)+1,
 instr(dimname_path,'/',1,v_lev+1)-
 instr(dimname_path,'/',1,v_lev)-1 );

 end Loop ;*/


RETURN v_spelev;
EXCEPTION WHEN OTHERS THEN
--RETURN '发生错误: '||SQLCODE||'--'||SQLERRM;
return '';
END co_get_spelev;
/
