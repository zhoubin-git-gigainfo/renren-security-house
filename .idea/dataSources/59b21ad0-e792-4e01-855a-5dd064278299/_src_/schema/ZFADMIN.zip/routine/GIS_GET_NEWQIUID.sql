CREATE function GIS_GET_NEWQIUID(strTF  in varchar2,strSeq in varchar2)
return varchar2 is
  Result varchar2(512);
  PRAGMA AUTONOMOUS_TRANSACTION; 
  n_qiu varchar2(10);
  i number;
  maxqiuid number;
  totalqiu number;
  newQiuID varchar2(10);
begin
  Result:='';
  i:=0;
  select max(qiun) into maxqiuid  from GIS_QIUINFO where TFN=strTF;
  select count(*) into totalqiu from GIS_QIUINFO where TFN=strTF;
  if (to_number(maxqiuid)=totalqiu) then
  begin
     --insert into GIS_QIUINFO(tfn,qiun) values('723030','006');
     newQiuID:=substr('00'||to_char(to_number(maxqiuid)+1),-3);
     insert into GIS_QIUINFO(tfn,qiun,source) values(strTF,newQiuID,strSeq);
     commit;

  end;
  else
  begin
  DECLARE
     CURSOR c_emp IS
          select qiun from GIS_QIUINFO where TFN=strTF order by QIUN;
     BEGIN
        OPEN c_emp;
        LOOP
           FETCH c_emp INTO n_qiu;
           EXIT WHEN c_emp%NOTFOUND;
           i:=i+1;
           if (to_number(n_qiu)<>i) then
           begin
              newQiuID:=substr('00'||to_char(i),-3);
              insert into GIS_QIUINFO(tfn,qiun,source) values(strTF,newQiuID,strSeq);
              commit;
           end;
           End if;
        END loop;
        CLOSE c_emp;
     End;
  end;
  end if;
  Result:=newQiuID;
  return(Result);
end GIS_GET_NEWQIUID;


/
