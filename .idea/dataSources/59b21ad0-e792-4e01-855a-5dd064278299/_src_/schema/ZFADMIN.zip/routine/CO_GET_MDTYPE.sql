CREATE function co_get_MDType(v_Hid in number) return number is
  Result number(1);
begin
  Select max(mt.md_type) into Result From tm_mainbody mt,to_relation rt, tu_state st
   Where mt.md_id=rt.mid and rt.bid=st.bid and st.stype='44' and st.sid=v_Hid;
  return(nvl(Result,1));
end co_get_MDType;


/
