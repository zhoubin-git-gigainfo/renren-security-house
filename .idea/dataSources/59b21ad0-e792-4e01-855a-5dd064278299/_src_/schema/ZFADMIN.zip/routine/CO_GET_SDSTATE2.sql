CREATE function CO_GET_SDSTATE2(v_Reals in varchar2,IsNeeds in varchar2,UnNeeds in varchar2)
RETURN number

IS
  v_SDList  varchar2(32767);
  v_STList  varchar2(500);
  v_Recs1   integer default 1;
  v_Recs2   integer default 0;
  v_MaxDM   varchar2(100);
  v_spos     integer default 1;
  v_epos     integer default 0;
  v_spos1    integer default 1;
  v_epos1    integer default 0;
  v_IsNeeds  varchar2(200);

begin
   v_SDList:=v_Reals||',';
   If IsNeeds is null and UnNeeds is null then return 1; end if;
   
   While v_Recs1>0 and v_Recs2=0 loop
       v_epos:=instr(v_SDList,',',v_spos);
       v_MaxDM:=substr(v_SDList,v_spos,v_epos-v_spos);
       if v_MaxDM is null then exit;end if;
       v_spos:=v_epos+1;
       
       Select bstate||','||sstate into v_STList from tu_bldg 
       where sid=(Select sid From tu_house where hid=to_char(v_MaxDM) union
                  Select sid From tu_layer where lid=to_char(v_MaxDM) union
                  Select sid From tu_bldg where sid=to_char(v_MaxDM));
       Select nvl(sum(instr(UnNeeds,stype)),0) into v_Recs2 From tu_state Where sid=to_char(v_MaxDM);
       v_Recs2:=v_Recs2+instr(UnNeeds,v_STList);
             
       v_spos1:=1;  v_epos1:=0;
       While v_Recs1>0 and v_Recs2=0 loop
           v_epos1:=instr(IsNeeds||',',',',v_spos1);
           v_IsNeeds:=substr(IsNeeds||',',v_spos1,v_epos1-v_spos1);
           if v_IsNeeds is null then exit;end if;
           v_spos1:=v_epos1+1;
           If v_IsNeeds>'3' then
               Select count(*) into v_recs1 from tu_state where sid=to_number(v_MaxDM) 
                  and stype like v_IsNeeds; 
           Else
               v_recs1:=instr(v_STList,v_IsNeeds);
           End if;
       End loop;
           
   End loop;
   If v_Recs1>0 and v_Recs2=0 then 
      Return 1; 
   End if;
   Return 0;
End co_get_SDState2;


/
