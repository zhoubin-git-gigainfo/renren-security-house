CREATE function CO_GET_PUBAREA(BID in Number,AreaNo varchar2)
RETURN co_table PIPELINED
IS
  My_Type   co_basic;
  v_Fill    varchar2(3000);
  v_Sgem    varchar2(3000);

  v_finish  Integer;
  v_MinVal  integer;
  v_MaxVal  integer;  
begin
--1、初始化自定义类型
  My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);

  Select Area3 into v_Fill From ta_func Where sseq=BID and area2=AreaNo;  
  v_Fill:='01@1~5,2@1&4~5&8~10&11&13&16~20,6@1~5';
  
  While Length(v_Fill)>0 loop
     If instr(v_Fill,',')>0 Then
        v_Sgem:=substr(v_Fill,1,instr(v_Fill,',')-1);
        v_Fill:=Substr(v_Fill,instr(v_Fill,',')+1);
--        v_pix:=substr('00'||Substr(v_Sgem,1,Instr(v_Sgem,'@')-1),-2);
     Else
        v_Sgem:=v_Fill;
        v_Fill:='';        
--        v_pix:=substr('00'||Substr(v_Sgem,1,Instr(v_Sgem,'@')-1),-2);
     End if;     
     v_Sgem:=Substr(v_Sgem,Instr(v_Sgem,'@')+1);
  
/*     
     --处理&符
     v_Start:=1;
     v_Temp:='';
     Loop 
        v_first:=InStr(v_Temp,'~',v_Start);
        If v_first=0 Then
           Exit;
        End If;
        v_MinVal:=to_number(Substr(v_Val,1,v_first-1));
        v_MaxVal:=to_number(Substr(v_Val,v_first+1));
        For I in  v_MinVal .. v_MaxVal loop
            v_Temp:=v_Temp||','||Substr('00'||to_char(i),-2);
        End loop;
        v_Start:=v_Start+1;
     End Loop;
    
     --处理&符
     v_Start:=1;
     v_Temp:='';
     Loop 
        v_first:=InStr(v_Val,'&',v_Start);
        v_Finish:=InStr(v_Val,'&',v_Start+1);
        If v_Finish>v_first Then
           v_Temp:=Substr(v_Val,v_Start+1,v_Finish-1);
        Else
           v_Temp:=Substr(v_Val,v_Start+1);
        End If;
*/ 
 --       My_Type := co_basic(0,AreaNo,0,0,null,null,null,null,v_Sgem,null,null,null,null,null);
   --     PIPE ROW (My_Type);
--     End Loop;



  End Loop;  

     return;
end co_get_PubArea;


/
