CREATE function CO_GET_XML(quy_XML varchar2,RowsTag varchar2,RowTag varchar2)
RETURN clob IS
  l_ctx DBMS_XMLGEN.ctxHandle;  
  l_xml clob;
begin
  l_ctx := dbms_xmlquery.newContext(quy_XML);
  dbms_xmlquery.setrowsettag(l_ctx,RowsTag);  
  dbms_xmlquery.setrowtag(l_ctx,RowTag);
  l_xml := dbms_xmlquery.getXML( l_ctx );

  dbms_xmlquery.closeContext(l_ctx);
  RETURN l_xml;
  exception
  when others then
  dbms_xmlquery.closeContext(l_ctx);
  raise;
end co_get_xml;


/
