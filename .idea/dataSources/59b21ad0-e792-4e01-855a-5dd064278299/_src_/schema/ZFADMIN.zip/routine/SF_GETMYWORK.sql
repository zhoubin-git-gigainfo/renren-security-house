CREATE function SF_GETMYWORK(RoleID in integer,UserID in integer,CurUser in integer)
return integer as
 recs integer;
Begin
 If UserID=CurUser Then Return 1; End if;
 If UserID=0 Then
 Begin
 Select count(*) into recs From Sysuserorg Where Oseq=RoleID and Useq=CurUser;
 If recs>0 Then Return 0; End if;
 End;
 End if;
 Return -1;
End ;


/
