CREATE function CO_GET_PUBLIC(BID in Number,AreaNo varchar2)
RETURN co_table PIPELINED
IS
  My_Type   co_basic;
  v_Fill    varchar2(3000);
  v_Sgem    varchar2(3000);
  v_Start   Integer;
  v_Finish  Integer;
  v_bzc varchar2(1000);
  v_floor varchar2(10);
  v_temp varchar2(3000);
begin
--1、初始化自定义类型
  My_Type:=co_basic(null,AreaNo,null,null,null,null,null,null,null,null,null,null,null,null);
 Select Area3||',' into v_Fill From ta_func Where sseq=BID and area2=AreaNo;  
  --v_Fill:='01@1~5,2@1&4~5&8~10&11&13&16~20,6@1~5,';
  if (v_Fill<>'0,') then
  begin
  While Length(v_Fill)>0 loop
     If instr(v_Fill,',')>0 Then
        v_Sgem:=substr(v_Fill,1,instr(v_Fill,',')-1);
        v_Fill:=Substr(v_Fill,instr(v_Fill,',')+1);
     Else
        v_Sgem:=v_Fill;
        v_Fill:='';        
     End if;
     

     
     v_temp:=v_Sgem;
     v_floor:=substr('000'||Substr(v_Sgem,1,Instr(v_Sgem,'@')-1),-2);
     v_bzc:=co_get_samefloor(BID,to_char(v_floor))||',';
     if v_bzc=',' then 
        v_bzc:=to_char(to_number(v_floor))||',';
     else
        v_bzc:=to_char(to_number(v_floor))||','||v_bzc;
     end if;
     while (instr(v_bzc,',',1,1)>0)
     loop
        v_Sgem:=v_temp;
        v_floor:=substr(v_bzc,1,instr(v_bzc,',',1,1)-1);
        v_bzc:=substr(v_bzc,instr(v_bzc,',',1,1)+1,length(v_bzc)-instr(v_bzc,',',1,1));
        My_Type.Num_1:=to_number(v_floor);
        /*to_number(Substr(v_Sgem,1,Instr(v_Sgem,'@')-1));     */
        
     v_Sgem:=Substr(v_Sgem,Instr(v_Sgem,'@')+1);
     My_Type.Str_1:=v_Sgem;
     
     --按&符号分割
     While Length(v_Sgem)>0 loop
        If instr(v_Sgem,'&')>0 Then
           My_Type.Str_2:=substr(v_Sgem,1,instr(v_Sgem,'&')-1);
           v_Sgem:=Substr(v_Sgem,instr(v_Sgem,'&')+1);
        Else
           My_Type.Str_2:=v_Sgem;
           v_Sgem:='';        
        End if;
        If Instr(My_Type.Str_2,'~')=0 Then
           My_Type.Num_2:=to_number(My_Type.Str_2);
           PIPE ROW (My_Type);           
        Else
           v_Start:=to_number(Substr(My_Type.Str_2,1,Instr(My_Type.Str_2,'~')-1));
           v_Finish:=to_number(Substr(My_Type.Str_2,Instr(My_Type.Str_2,'~')+1));
           For i in v_Start .. v_Finish Loop
               My_Type.Num_2:=i;
               PIPE ROW (My_Type);
           End loop ;
        End if;
        
     End Loop;
    

  End Loop;
 End loop;
 end;
 end if;
  Return;
end co_get_Public;


/
