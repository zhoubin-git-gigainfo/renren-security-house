CREATE function SF_GETVALIDDATE(objID in Number,vDate in Date)
return date is
  Result date ;
  tmpDate date;
begin
  If tmpDate=null Then
     tmpDate:=sysdate() ;
  Else
     tmpDate:=vDate;
  End if;
  Select Max(FDATE) into Result From T2 Where ID=objID and Fdate<=tmpDate;
  return(Result);
end SF_GETvalidDate;


/
