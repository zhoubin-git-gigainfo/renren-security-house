CREATE function CO_get_mtransTentIn(v_sseq in varchar2,v_yymm in varchar2)
--取得该租赁关系最新状态
return number is
  Result number(10,2);
begin
 select nvl(sfee,0) into Result from u_account where ftype=6 and yymm=to_number(v_yymm) and  sseq=v_sseq;
  return(Result);
end CO_get_mtransTentIn;


/
