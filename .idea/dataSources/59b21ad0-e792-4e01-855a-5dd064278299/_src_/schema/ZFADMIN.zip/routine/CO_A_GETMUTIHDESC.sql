CREATE function CO_a_getMutiHdesc(vm_sseq in varchar2)
return varchar2 is
  Result varchar2(300);
  vm_int int;
begin
  If length(trim(vm_sseq))=0 or vm_sseq is null Then
     return ' ';
  else
  select count(*) cc into vm_int from u_tenancy where vflag=0 and sseq=vm_sseq;
  if vm_int>1 then
  select to_char(wm_concat(u1.hdesc)) hdesc into Result from u_house u1,u_tenancy u2
  where u1.hstate=0 and u2.vflag=0 and u2.hid=u1.hid and u2.sseq=vm_sseq;
  else
   Result:= '';
   end if;
   end if;
  return(Result);
end CO_a_getMutiHdesc;


/
