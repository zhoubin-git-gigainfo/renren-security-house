CREATE function CO_GET_FUNCAREA(area in VARCHAR2,strclh in number)
return VARCHAR2 is
   strtemp varchar2(4000);
   strone  varchar2(4000);
   strlayer  varchar2(200);
   strshouse varchar2(500);
   strehouse varchar2(500);
   formatarea varchar2(4000);
   i integer;
begin
  strtemp:=area;
  i:=1;
  strone:=strtemp;
  formatarea:='';
  /*strone:='01@1~27';*/
  if (instr(strone,'-')=2) then
     strone:=substr(strone,instr(strone,'-'),2);
  end if;
  

  if instr(strone,',',1,1)=0 then
  begin
     strlayer:=to_char(to_number(substr(strone,1,instr(strone,'@',1,1)-1)));
     formatarea:=co_get_funcareaone(strone,strclh,strlayer);
  end;
  else
  begin
     while instr(strtemp,',',1,1)>0 
     loop
     strlayer:=to_char(to_number(substr(strtemp,1,instr(strtemp,'@',1,1)-1)));
       if (i=1) then
          formatarea:=co_get_funcareaone(substr(strtemp,1,instr(strtemp,',',1,1)-1),strclh,strlayer);          
       else
          formatarea:=formatarea||','||co_get_funcareaone(substr(strtemp,1,instr(strtemp,',',1,1)-1),strclh,strlayer); 
       end if;       
       strtemp:=substr(strtemp,instr(strtemp,',',1,1)+1,length(strtemp)-instr(strtemp,',',1,1));
       i:=i+1;    
     end loop;
       strlayer:=to_char(to_number(substr(strtemp,1,instr(strtemp,'@',1,1)-1)));
       formatarea:=formatarea||','||co_get_funcareaone(strtemp,strclh,strlayer);  
  end;
  end if;
  return formatarea;
end;


/
