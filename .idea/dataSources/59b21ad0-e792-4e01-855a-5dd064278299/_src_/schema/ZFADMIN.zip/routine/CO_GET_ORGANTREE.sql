CREATE function co_get_organTree(v_Snum in number) return clob is
  Result clob;
  PRAGMA AUTONOMOUS_TRANSACTION;
  v_oseq   number;
  v_oname  varchar2(200);
  v_pseq   number;
  v_LEAF   number;
  v_layer  number;
  v_type   number;
  v_prelay number default 1;
  v_ord    varchar2(100);
  v_RootOrg number;
  
begin
  dbms_lob.createtemporary(Result, TRUE);
  Select oseq into v_RootOrg From (Select oseq From sysorgan where oparent=-1 order by oorder) Where rownum=1;
  Result:='<?xml version="1.0" encoding="utf-8" ?>'||chr(13)||'<tree id="0">'||chr(13); 

  Delete my_person Where DSEQ=v_Snum;
  Insert into my_person 
         (Select distinct oseq,v_Snum,oname,oparent,(Select userid From sysuser Where useq=oseq) From sv_organ t3 Where otype=9
            Start With oseq in (Select user_orgid From APP_USERSECRET,APP_SECRETDOMAIN Where useq=domainnameid and Secretlevel=v_Snum) Connect By nocycle PRIOR oseq = oparent);
  Commit;
  Delete my_organs Where DSEQ=v_Snum;  

  Insert into my_organs
         (Select Distinct t2.oseq,v_Snum,oname,oparent,otype,ocode
            From (Select oseq From sysorgan Start With oseq in (Select distinct roleid From my_person Where dseq=v_Snum) Connect By nocycle oseq = PRIOR oparent) t1,
                 (Select oseq,oname,oparent,otype,ocode From sysorgan Where otype!=4 Start With oseq=v_RootOrg Connect By nocycle PRIOR oseq=oparent) t2 Where t1.oseq=t2.oseq );
  Insert into my_organs
         (Select distinct t3.useq,v_Snum,t3.uname,t1.oseq,9,t1.ocode||'-' From my_organs t1,sysorgan t2,my_person t3
           Where t1.oseq=t2.oparent and t2.oseq=t3.roleid and t1.dseq=t3.dseq and t1.oseq!=v_RootOrg and t3.dseq=v_Snum);

  DECLARE CURSOR MyCur IS
          Select ocode,oseq,oname,oparent,otype,level,CONNECT_BY_ISLEAF
            From (Select ocode,oseq,oname,oparent,otype From my_organs Where dseq=v_Snum)
           Start With oseq=v_RootOrg Connect By nocycle PRIOR oseq = oparent Order by ocode;
  BEGIN
      OPEN MyCur;
      LOOP
          FETCH MyCur INTO v_ord,v_oseq,v_oname,v_pseq,v_type,v_layer,v_LEAF;
          EXIT WHEN MyCur%NOTFOUND;
          If v_layer>v_prelay Then 
             Result:=Result||chr(13); 
             v_prelay:=v_prelay+1;
          End if;
          
          While v_prelay>v_layer
          Loop
              v_prelay:=v_prelay-1;
              Result:=Result||'</item>'||chr(13); --lpad(' ',2*v_prelay,' ')||
          End Loop;
          
          If v_layer=1 Then 
             Result:=Result||'<item '||'text='||'"'||v_oname||'" id="'||to_char(v_oseq)||'" open="1">';
          Else
             Result:=Result||'<item '||'text='||'"'||v_oname||'" id="'||to_char(v_oseq)||'">';
          End if;
          -- im0="tombs_mag.gif" im1="tombs_mag.gif" im2="tombs_mag.gif">';         
          If v_LEAF=1 Then 
             Result:=Result||'</item>'||chr(13);  
          End if;
      END loop;
      CLOSE MyCur;
      While v_layer>1
      Loop
            v_layer:=v_layer-1;
            Result:=Result||'</item>'||chr(13); --lpad(' ',2*v_layer,' ')||
      End Loop;
  End;
  Rollback;
  Result:=Result||'</tree>'||chr(13);
  return(Result);
  
end co_get_organTree;


/
