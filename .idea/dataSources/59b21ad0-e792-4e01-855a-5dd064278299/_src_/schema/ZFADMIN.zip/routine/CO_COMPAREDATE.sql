CREATE function CO_compareDate(edate in varchar2)
return int is
  Result integer;
  --0 在租 1 停租

begin
  If length(trim(edate))=0 or edate is null Then
     return '0';
  End if;
  If (to_date(edate,'yyyy-mm-dd')-sysdate)>0 then
  Result:=0;

  else
  Result:=1;
  end if;
  return(Result);
end CO_compareDate;


/
