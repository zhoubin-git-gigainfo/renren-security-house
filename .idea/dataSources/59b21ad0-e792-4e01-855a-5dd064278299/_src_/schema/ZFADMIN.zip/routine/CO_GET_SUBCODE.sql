CREATE function co_Get_subCode(v_Code_Id in number)
  return number is
  Result number(12);
  v_malev integer;
begin
   Select max(level) into v_malev from ts_code where parentid!=-1 start with id=v_Code_Id Connect by NOCYCLE prior parentid=id;
   Select id into Result from ts_code where level=v_malev and parentid!=-1 start with id=v_Code_Id Connect by NOCYCLE prior parentid=id;
  return(nvl(Result,0));
end co_Get_subCode;


/
