CREATE function F1_java return varchar2
as language java

 name 'OTest.showmsg() return java.lang.String';


/
