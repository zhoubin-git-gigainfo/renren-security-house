CREATE function CO_GET_APPLIST(Real_IDs in varchar2)
RETURN co_table PIPELINED
  /*输入参数说明：
  Real_ID：房屋对象IDs
  ST_View: 业务视角
  /*返回信息
  id=房屋ID
  Key=生命周期状态
  Str_1：生命周期背景色
  Str_2：业务视角状态
  Str_3: 业务视角背景色
  Str_4：限制状态
  Str_5: 限制背景色
 */
IS
  My_Type   co_basic;
  v_States  varchar2(256);
begin
--一、初始化
  My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
  Select Str_1 into v_States From Table(co_get_State2(Real_IDs));


--三、返回结果（）
  PIPE ROW (My_Type);
  Return ;

End co_get_AppList;


/
