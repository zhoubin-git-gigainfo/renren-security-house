CREATE function SF_GET_STRU(ZID in number,CNO in VARCHAR2,intSeq in number)
return varchar2 is
  Result varchar2(512);
  v_ename varchar2(60);
  n_value number;
begin
  Result:='';
  DECLARE  
     CURSOR c_emp IS 
          Select name,sum(to_number(jzmj)) as totmj From ta_hxx,ts_code
                 Where ridgepoleno=zid 
                   and cc=DECODE(CNO,'',CC,CNO)
                   and frameid=id and sseq=intSeq
                 Group by name
                 Order by sum(to_number(jzmj)) desc ;
     BEGIN  
        OPEN c_emp;  
        LOOP  
           FETCH c_emp INTO v_ename,n_value; 
           EXIT WHEN c_emp%NOTFOUND;
           If length(Result)>0 then
              Result:=Result||'，';
           End if;
           If length(Result||v_ename)<=512 then 
              Result:=Result||v_ename; 
           End if;
        END loop;
        CLOSE c_emp;
     End;
  return(Result);
end sf_get_stru;


/
