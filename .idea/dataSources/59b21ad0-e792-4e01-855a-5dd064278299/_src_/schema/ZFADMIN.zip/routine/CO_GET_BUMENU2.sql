CREATE function CO_GET_BUmenu2(App_bseq integer,SD_IDs in varchar2)
  RETURN co_table PIPELINED is
  --RETURN number is
  PRAGMA AUTONOMOUS_TRANSACTION;
  My_Type         co_basic;
  v_Recs          integer;
  Menu_Type       integer;
  v_bseq          number(12);
  v_bid           varchar2(20);
  v_bname         varchar2(60);
  v_needs         varchar2(200);
  v_unneeds       varchar2(200);
  v_group         varchar2(200);
  v_bath          integer;
  v_Single        integer default 0;
  v_More          integer default 0;
  v_unite         integer default 0;
  v_MenuID        integer default 10;
  v_sdCount       integer;
  v_gwfseq        number(12); 
  --Type strArray  is table of varchar2(10);
  --Type numArray  Is table of number;
  --v_StCode        strArray:=strArray();
  --v_StTotl        numArray:=numArray();
  v_WkNo            integer default 1;
  
Begin
--1、初始化自定义类型
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    
    Select apptype,co_seq_work.nextval into Menu_Type,v_WkNo 
      From Appdefine Where bseq=app_bseq;

    --execute immediate l_sql; 
    --l_sql:='CREATE GLOBAL TEMPORARY table My_SDList (SD_ID number(12)) ON COMMIT DELETE ROWS'; 
    --l_sql:='CREATE GLOBAL TEMPORARY table My_STList (STCODE varchar2(10),STCount number(12)) ON COMMIT DELETE ROWS'; 
    --execute immediate l_sql; 
    
    --建立客体临时数据列表
    Insert into My_SDList Select distinct v_WkNo,to_number(str_1) From table(co_get_split(SD_IDs));

    --如果客体有业务在办
    Select Count(*) into v_recs From to_state a,appdefine b,My_SDList c
     Where a.bseq=b.bseq and apptype=Menu_Type and modality=1 and a.sid=c.sd_id and c.no=v_WkNo ;
    If v_Recs>0 Then  
       Rollback;
       return ; 
    End if;
    
    --计算客体数量->v_sdCount变量
    Select count(*) into v_sdCount From tu_house t1,My_SDList t2
     Where (t1.sid=t2.SD_ID or t1.lid=t2.SD_ID or t1.hid=t2.SD_ID) 
       --and nvl(t1.sattribute,0)!=145001 
       and t2.no=v_WkNo;
       
    If v_sdCount=0 and (Menu_Type=2 or Menu_Type=5) then 
        Rollback;       
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:='单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        PIPE ROW (My_Type);
        If Menu_Type=2 Then
            My_Type.id:=2;
            My_Type.key:='CL01';
            My_Type.str_1:='栋测量';
            My_Type.num_1:=1;
            My_Type.str_2:='22005';
            My_Type.str_3:='CL01';
            My_Type.num_2:=10001;
            PIPE ROW (My_Type); 
        End if;
        If Menu_Type=5 Then
            My_Type.id:=2;
            My_Type.key:='CL02';
            My_Type.str_1:='栋预测量';
            My_Type.num_1:=1;
            My_Type.str_2:='1750000';
            My_Type.str_3:='CL02';
            My_Type.num_2:=10001;
            PIPE ROW (My_Type); 

        End if;
        Return ; 
    End if;
    
    If v_sdCount=0 Then
       Rollback; 
       Return ; 
    end if;
    
    --计算所有状态和客体数my_stlist）
    Insert into my_stlist Select v_WkNo,stype,sum(1) totl 
                            From (Select distinct t2.sid,t2.stype from tu_house t1,tu_state t2,My_SDList T3
                           Where t1.hid=t2.sid and (t1.sid=T3.sd_id or t1.lid=T3.sd_id or t1.hid=T3.sd_id) 
                             and t2.stype>'3' and no=v_WkNo)-- and nvl(t1.sattribute,0)!=145001)
                           Group by Stype;
    --生命周期状态
    Insert into my_stlist Select v_WkNo,t0.bstate,count(*) From tu_bldg t0,tu_house t1,my_sdlist t2
                           Where t0.sid=t1.sid and (t1.sid=t2.sd_id or t1.lid=t2.sd_id or t1.hid=t2.sd_id) and no=v_WkNo
                           Group by bstate;
    --测量状态
    Insert into my_stlist Select v_WkNo,t0.sstate,count(*) From tu_bldg t0,tu_house t1,my_sdlist t2
                           Where t0.sid=t1.sid and (t1.sid=t2.sd_id or t1.lid=t2.sd_id or t1.hid=t2.sd_id) and no=v_WkNo
                           Group by sstate;

    Commit;
    
    DECLARE CURSOR MyCur IS
            Select BSEQ,BID,BNAME,needs,unneeds,Replace(','||bugroup||',',' ',''),isbath,Gwfseq
              From Appdefine Where apptype=Menu_Type and bseq!=app_bseq 
               and bseq in (Select distinct bseq from sv_budefine t1,my_stlist t2
                             Where t2.stcode like nvl(t1.stcode,'%') and apptype=Menu_Type and type=0 and stcount>=v_sdCount and no=v_WkNo)
               and not bseq in (Select distinct bseq From sv_budefine t1,my_stlist t2 
                                 Where t2.stcode like t1.stcode and apptype=Menu_Type and type=1 and no=v_WkNo)
             Order by Decode(State_Id,'00','50',State_Id),decode(Optmod,'01',1,'10',9,2),bid;
    Begin
       OPEN MyCur;
       LOOP
           FETCH MyCur INTO v_bseq,v_bid,v_bname,v_needs,v_unneeds,v_group,v_bath,v_gwfseq;
           EXIT WHEN MyCur%NOTFOUND;
           
           v_Single:=10000;
           My_Type.id:=v_MenuID;
           My_Type.key:=v_bid;
           My_Type.str_1:=v_bname;
           My_Type.num_1:=1;
           My_Type.str_2:=to_char(v_bseq);
           My_Type.str_3:=v_bid;
           My_Type.num_2:=v_Single+v_MenuID;
           My_Type.num_5:=null;
           PIPE ROW (My_Type);
           v_MenuID:=v_MenuID+1;
   
           if v_bath=1 Then
               v_More:=20000;
               My_Type.id:=v_MenuID;
               My_Type.key:=v_bid;
               My_Type.str_1:=v_bname;
               My_Type.num_1:=2;
               My_Type.str_2:=to_char(v_bseq);
               My_Type.str_3:=v_bid;
               My_Type.num_2:=v_More+v_MenuID;
               My_Type.num_5:=null;
               PIPE ROW (My_Type);
               v_MenuID:=v_MenuID+1;
           End if;
            
           If  v_group!=',,' Then
               v_unite:=30000;
               My_Type.id:=v_MenuID;
               My_Type.key:=v_bid;
               My_Type.str_1:=v_bname;
               My_Type.num_1:=3;
               My_Type.num_5:=v_gwfseq;
               My_Type.str_2:=to_char(v_bseq);
               My_Type.str_3:=v_bid;
               My_Type.num_2:=v_unite+v_MenuID;
               PIPE ROW (My_Type);
               v_MenuID:=v_MenuID+1;
                            
               DECLARE CURSOR MyChildMenu IS
                       Select BID,My_Type.id,BNAME,My_Type.str_2||','||TO_CHAR(BSEQ),My_Type.str_3||','||BID 
                        From Appdefine
                        Where instr(v_group,','||to_char(bseq)||',')>0
                        order by Decode(State_Id,'00','50',State_Id),decode(Optmod,'01',1,'10',9,2),bid;
               Begin
                   Open MyChildMenu;
                   LOOP
                       FETCH MyChildMenu INTO My_Type.KEY,My_Type.num_1,My_Type.str_1,My_Type.str_2,My_Type.str_3;
                       EXIT WHEN MyChildMenu%NOTFOUND;
                       My_Type.id:=v_MenuID;
                       My_Type.num_2:=v_unite+v_MenuID;
                       PIPE ROW (My_Type);
                       v_MenuID:=v_MenuID+1;
                   End loop;
                   CLOSE MyChildMenu;
               End;             
           End if;

       END loop;
       CLOSE MyCur;
    End;
    
    If v_Single=10000 Then
      My_type.id:=1;
      My_type.KEY:='1';
      My_type.str_1:='单笔业务';
      My_type.num_1:=-1;
      My_type.num_2:=10000;
      PIPE ROW (My_Type);
    End if;
    If v_More=20000 Then
      My_type.id:=2;
      My_type.KEY:='2';
      My_type.str_1:='批量业务';
      My_type.num_1:=-1;
      My_type.num_2:=20000;
      PIPE ROW (My_Type);
    End if;
    If v_unite=30000 Then
      My_type.id:=3;
      My_type.KEY:='3';
      My_type.str_1:='组合业务';
      My_type.num_1:=-1;
      My_type.num_2:=30000;
      PIPE ROW (My_Type);
    End if;
    Return ;
end ;


/
