CREATE function CO_MOV_OVERLAP(srcString varchar2)
return varchar2
as
    src_Str    varchar2(6000);
    des_Str    varchar2(6000) Default '；';
    tmp_Str    varchar2(6000);
    str_len    number;
begin
    src_Str:=srcString;
    
    Loop
        str_len:=Instr(src_Str,'；');
        If str_len=0 Then exit; End if;
        
        tmp_Str:=substr(src_Str,1,str_len-1);
        src_Str:=substr(src_Str,str_len+1);

        If Instr(des_Str,'；'||tmp_Str||'；')=0 Then
           des_Str:=des_Str||tmp_Str||'；';
        End if;

    End Loop;
    If Instr(des_Str,'；'||src_Str||'；')=0 then
       des_Str:=des_Str||'；'||src_Str;
    end if;
    des_Str:=ltrim(rtrim(des_Str,'；'),'；');
    Return des_Str;
end;


/
