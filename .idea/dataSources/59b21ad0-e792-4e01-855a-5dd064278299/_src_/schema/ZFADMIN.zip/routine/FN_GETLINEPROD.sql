CREATE Function FN_GetLineProd(P_LineProd In TP_TempTable)
  Return Varchar2 Is
  L_Str varchar2(4000);
  i     Number;
Begin
  For i in 1 .. P_LineProd.Count Loop
    If L_Str Is Null Then
      L_Str := P_LineProd(i);
      else
       L_Str := L_Str || '、' || P_LineProd(i);
    End If;
  end loop;
  Return L_Str;
End FN_GetLineProd;


/
