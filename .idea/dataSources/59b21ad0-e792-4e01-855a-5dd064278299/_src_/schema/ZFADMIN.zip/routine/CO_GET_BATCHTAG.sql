CREATE function co_get_batchtag(cur_tseq in number,cur_bid in varchar2) return number is
  Result number;
begin

select decode(nvl(ad.batchtag, 0) + nvl(sc.batchtag, 0),
              2,
              ac.actmod,
              0) batchurl into Result
  from appdefine ad, appwfactivity ac, syswfactivity sc
 where ac.actmod = sc.actseq
   and ad.bid = cur_bid
   and ac.actseq =cur_tseq;
  return(Result);
end co_get_batchtag;


/
