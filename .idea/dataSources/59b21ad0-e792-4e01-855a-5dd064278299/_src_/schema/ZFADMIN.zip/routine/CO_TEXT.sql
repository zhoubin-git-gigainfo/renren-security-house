CREATE function co_text return XMLType is
  Result XMLType;
begin
  Select XMLQuery('for $j in ora:view("zfadmin", "tu_bldg")/ROW  where $j/sid=200000869809 return ( {$j/sid,$j/lanme} 
                  {for $i in ora:view("zfadmin", "tu_house")/ROW where $i/sid=$j/sid return ({$i/hid,$i/hno,$i/barea})} )'
         RETURNING CONTENT) Into Result 
    From Dual;
    --If DBMS_XDB.CREATERESOURCE('/Total_Data/acc_dept.xml', Result) Then 
    --   DBMS_OUTPUT.PUT_LINE('Resource is created');
    --End if;
    Commit;
  return(Result);
end co_text;


/
