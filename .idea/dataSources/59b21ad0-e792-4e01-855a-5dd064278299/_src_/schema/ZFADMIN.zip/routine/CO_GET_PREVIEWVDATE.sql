CREATE function co_get_PreviewVdate(strSid in number,strVdate in timestamp,intType in number) return timestamp is
  Result timestamp;
Begin
  if (intType=1) then
     select max(v_date) into  Result from tuh_bldg where f_date is not null and  sid=strSid and v_date<strVdate;
  else
     select max(v_date) into  Result from tuh_bldg where   sid=strSid and v_date<strVdate;
  end if;     
/*  if (Result<>null) then
  return(Result);
  else
  return(sysdate);
  end if;*/
  return(Result);
End co_get_PreviewVdate;


/
