CREATE function CO_GET_STATE2(v_Reals in varchar2)
RETURN co_table PIPELINED
  /*输入参数说明：
  Real_ID：房屋对象IDs
  ST_View: 业务视角
  /*返回信息
  id=房屋ID
  Key=生命周期状态
  Str_1：生命周期背景色
  Str_2：业务视角状态
  Str_3: 业务视角背景色
  Str_4：限制状态
  Str_5: 限制背景色
 */
IS
  My_Type   co_basic;
  v_state   varchar2(10);
--  v_Cur     Integer;
--  v_Row     Integer;
--  v_Sql     varchar2(3000);
begin
--一、初始化自定义类型
  My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);

--1、、取生命周期状态
  Select max(bstate) into My_Type.Str_1 from tu_bldg,tu_house
   Where tu_bldg.sid=tu_house.sid
     and (instr(','||v_Reals||',',','||to_char(tu_bldg.sid)||',')>0
      or instr(','||v_Reals||',',','||to_char(hid)||',')>0);

--3、、取业务状态

  DECLARE CURSOR MyCur IS
          Select distinct ts_state.st_code From tu_state,ts_state
           Where tu_state.stype=ts_state.st_code
             and Instr(','||v_Reals||',',','||to_char(sid)||',')>0
           Order by ts_state.st_code;
  Begin
     OPEN MyCur;
     LOOP
         FETCH MyCur INTO v_state;
         EXIT WHEN MyCur%NOTFOUND;
         My_Type.Str_1:=My_Type.Str_1||','||v_state;
     END loop;
     CLOSE MyCur;
  End;

--三、返回结果（）
  PIPE ROW (My_Type);
  Return ;

End co_get_State2;


/
