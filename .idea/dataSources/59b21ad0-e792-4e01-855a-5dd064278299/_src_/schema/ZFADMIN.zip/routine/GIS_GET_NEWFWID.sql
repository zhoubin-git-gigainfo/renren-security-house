CREATE function GIS_GET_NEWFWID(strTF  in varchar2,strQiu in varchar2,strSeq in varchar2)
return varchar2 is
  Result varchar2(512);
  PRAGMA AUTONOMOUS_TRANSACTION; 
  n_qiu varchar2(10);
  i number;
  maxqiuid number;
  totalqiu number;
  newQiuID varchar2(10);
begin
  Result:='';
  i:=0;
  select max(fwn) into maxqiuid  from gis_fwinfo where TFN=strTF and qiun=strQiu;
  select count(*) into totalqiu from gis_fwinfo where TFN=strTF and qiun=strQiu;
  if (to_number(maxqiuid)=totalqiu) then
  begin
     --insert into GIS_QIUINFO(tfn,qiun) values('723030','006');
     newQiuID:=substr('000'||to_char(to_number(maxqiuid)+1),-4);
     insert into gis_fwinfo(tfn,qiun,fwn,source) values(strTF,strQiu,newQiuID,strSeq);
     commit;

  end;
  else
  begin
  DECLARE
     CURSOR c_emp IS
          select fwn from  gis_fwinfo where TFN=strTF and qiun=strQiu order by fwn;
     BEGIN
        OPEN c_emp;
        LOOP
           FETCH c_emp INTO n_qiu;
           EXIT WHEN c_emp%NOTFOUND;
           i:=i+1;
           if (to_number(n_qiu)<>i) then
           begin
              newQiuID:=substr('000'||to_char(i),-4);
              insert into gis_fwinfo(tfn,qiun,fwn,source) values(strTF,strQiu,newQiuID,strSeq);
              commit;
           end;
           End if;
        END loop;
        CLOSE c_emp;
     End;
  end;
  end if;
  Result:=newQiuID;
  return(Result);
end GIS_GET_NEWFWID;


/
