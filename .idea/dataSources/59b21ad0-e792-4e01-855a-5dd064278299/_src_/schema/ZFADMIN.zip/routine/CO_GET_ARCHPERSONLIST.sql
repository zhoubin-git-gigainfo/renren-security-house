CREATE function CO_GET_archpersonlist(vm_md_name varchar2,vm_ic_no   varchar2)
  RETURN co_table PIPELINED is
  --RETURN number is

  My_Type         co_basic;
  vm_ic_no_1      varchar2(20);
  vm_ic_no_2      varchar2(20);


  v_bid           varchar2(70);
  v_sid           number(20);
  v_info          varchar2(80);
  vt2_md_name      varchar2(180);
  v_md_id           number(20);
  v_lname            varchar2(180);
  v_hdesc           varchar2(180);
  v_cdno            varchar2(180);
  v_cid              number(10);
  v_xz_id             number(20);

Begin
--1、初始化自定义类型
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    vm_ic_no_1:=substr(vm_ic_no,0,6);
    if length(vm_ic_no)=15 then
      vm_ic_no_2:=substr(vm_ic_no,6,14);
     end if;
     if length(vm_ic_no)=18 then
         vm_ic_no_2:=substr(vm_ic_no,8,16);
     end if;


  DECLARE CURSOR MyCur_arch IS
          select distinct t1.bid,t1.sid,vm_md_name||'('||vm_ic_no||')' info,t2.md_name,t2.md_id,m.lname,t4.hdesc , n.cdno,n.cid,t4.xz_id
          from all_to_relation@zzfcall t1,all_tm_mbodycard@zzfcall   t2, (select * from all_to_state@zzfcall t3  where t3.stype in ('42', '44', '48')) t3,
           all_tu_house@zzfcall  t4,all_tu_bldg@zzfcall m , all_tu_card@zzfcall n
           where  t1.mid = t2.MD_ID and t1.bid = t3.bid  and t3.sid=t4.hid and m.sid = t4.sid  and t1.bid = n.bid  and t4.hid=t1.sid  and ic_type = 58001
             and t2.xz_id=t3.xz_id and t2.xz_id=t4.xz_id and t2.xz_id=m.xz_id and t2.xz_id=n.xz_id   and md_name=vm_md_name and  instr(ic_no,vm_ic_no_1)>0 and instr(ic_no,vm_ic_no_2)>0;
 Begin
       OPEN MyCur_arch;
       LOOP
           FETCH MyCur_arch INTO v_bid,v_sid,v_info,vt2_md_name,v_md_id,v_lname,v_hdesc,v_cdno,v_cid,v_xz_id;
           EXIT WHEN MyCur_arch%NOTFOUND;
            My_Type.id:=v_sid;
           My_Type.key:=v_bid;
           My_Type.NUM_1:=v_md_id;
             My_Type.NUM_2:=v_cid;
             My_Type.NUM_3:= v_xz_id;
           My_Type.str_1:=v_info;
           My_Type.STR_2:=vt2_md_name;
           My_Type.str_3:=v_lname;
           My_Type.str_4:=v_hdesc;
           My_Type.str_5:=v_cdno;
           PIPE ROW (My_Type);

        END loop;

       CLOSE MyCur_arch;

    Return ;
     end;
end ;
/
