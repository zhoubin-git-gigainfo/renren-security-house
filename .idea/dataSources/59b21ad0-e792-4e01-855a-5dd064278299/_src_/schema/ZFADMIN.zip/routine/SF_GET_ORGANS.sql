CREATE function sf_get_Organs(Org_ID in number) return varchar2 is
  Result varchar2(6000);
  Depts  varchar2(1000);
begin
  Select max(sys_connect_by_path(oname,' ')),max(sys_connect_by_path(oseq,',')) into Result,Depts
    From sysorgan
   Start with oseq=Org_ID connect by prior oparent= oseq;

   Depts:=Substr(Depts,instr(Depts,',',-1,3)+1,instr(Depts,',',-1,2)-instr(Depts,',',-1,3)-1)||'~';
   return(Depts||Result);
end sf_get_Organs;


/
