CREATE function co_convert_appdefine(v_bseq number,v_lev in number) return varchar2 is
  Result varchar2(40);
/*代码转换
  输入:
     cid—代码ID
     ckey—装换
  输出
     Result—代码说明
*/
begin
 /*
select t1.sg_name into Result  from ts_segment t1
where sg_type=v_sgtype and sg_minval<sg_value and sg_maxval>sg_value;
*/

     if v_lev is null then

      select bname into Result from appdefine where bseq=v_bseq;

     else

     select substr(t2.dimname_path,
        instr(t2.dimname_path,'/',1,4)+1 )  into Result from mv_appdefine t2 where dimid=v_bseq;


     end if;


     --Select t1.st_name into Result from ts_state t1 where st_code=stcode;

  Return(Result);
  Exception when others then return ' ';
end co_convert_appdefine;
/
