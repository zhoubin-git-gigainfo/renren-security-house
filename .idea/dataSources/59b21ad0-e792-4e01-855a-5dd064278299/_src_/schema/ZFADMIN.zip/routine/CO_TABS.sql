CREATE function CO_TABS
RETURN co_table PIPELINED
IS
    My_Type co_basic;
BEGIN
        My_Type := co_basic (1,'Key',1,2,3,4,5,'Str1','Str2','Str3','Str4','Str5',sysdate,sysdate+1);
        PIPE ROW (My_Type);
    RETURN;
END co_Tabs;


/
