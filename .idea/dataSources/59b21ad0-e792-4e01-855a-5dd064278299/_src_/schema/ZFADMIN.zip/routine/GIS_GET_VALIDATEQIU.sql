CREATE function GIS_GET_ValidateQiu(strTF in varchar2,strQiu in varchar2,strSeq in varchar2)
return integer is
  Result integer;
   PRAGMA AUTONOMOUS_TRANSACTION; 
  newQiuID varchar2(10);
  fwcount integer;
begin
  Result:=0;
    select count(*) into fwcount from GIS_QIUINFO where tfn=strTF and qiun=strQiu;
    if (fwcount=0) then
    begin
      insert into GIS_QIUINFO(tfn,qiun,Source) values(strTF,strQiu,strSeq);
      Result:=1;
      commit;
    end;
    else
      Result:=0; 
    End if;
  return(Result);
end GIS_GET_ValidateQiu;


/
