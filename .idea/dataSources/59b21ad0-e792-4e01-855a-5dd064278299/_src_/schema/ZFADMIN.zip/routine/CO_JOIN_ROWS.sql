CREATE function CO_Join_Rows(Bu_No number,MinRows integer)
  RETURN co_table PIPELINED is
    v_RowNo         Integer;
    My_Type   co_basic;
Begin
    My_Type:=co_basic(0,null,null,null,null,null,null,null,null,null,null,null,null,null);  
    Select Ceil(count(*)/2) into v_RowNo From tu_dlist Where sseq=Bu_No;
    If v_RowNo<MinRows Then 
       v_RowNo:=MinRows; 
    end if;
    for i in 1 .. v_RowNo loop
        My_Type.num_1:=i;
        my_type.num_2:=v_RowNo+i;
        pipe row(My_Type);
    end loop;
    Return ;

end CO_Join_Rows;


/
