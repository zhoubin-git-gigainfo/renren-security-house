CREATE function CO_GET_STATISTICS(cs_ids in varchar2,
s_funcs in varchar2) return varchar2 is
 --cs_ids 为TS_CLASS表已选ID数组如: '1,2,3,4',s_funcs为统计要素数组如:'sum(VS_HOUSE.PRICE),avg(VS_HOUSE.AREA)
 Result varchar2(3000);
  s_groupby varchar2(1000);
  s_tables varchar2(500);
  i_pos1 integer;
  i_pos2 integer;
  i_pos3 integer;
  i_pos4 integer;
  s_tempfuncs varchar2(500);
  s_temptable varchar2(500);
  s_groupbytables varchar2(500);
  s_tempresult varchar2(500);
  s_tempcolumn varchar2(500);
  s_result varchar2(500);
begin
  s_tempfuncs:=s_funcs;
 -- s_tables:="";
  loop
  i_pos1:=instr(s_tempfuncs,'(');
  if i_pos1>0 then

  s_tempfuncs:=substr(s_tempfuncs,i_pos1+1);
  i_pos2:=instr(s_tempfuncs,'.');
  s_temptable:=substr(s_tempfuncs,1,i_pos2-1);


  s_tables:=s_tables||','||s_temptable;

  else
  --s_tables:='';
  exit;


  end if;
  end loop;
  s_tables:=substr(s_tables,2);

  select co_get_sumstr(cs_table||'.'||cs_name_en) into s_groupby from table(co_get_split(cs_ids)) t1,ts_class t2 where t2.cs_id=to_number(t1.str_1) order by t1.id;
  select co_get_sumstr(cs_table) into s_groupbytables from table(co_get_split(cs_ids)) t1,ts_class t2 where t2.cs_id=to_number(t1.str_1);
  --去除相同表名
  s_tempresult:=s_groupbytables||','||s_tables;
  loop
  i_pos3:=instr(s_tempresult,',');

  if i_pos3>0 then
  s_tempresult:=substr(s_tempresult,i_pos3+1);
  i_pos4:=instr(s_tempresult,',');
     if i_pos4>0 then
        s_tempcolumn:=substr(s_tempresult,1,i_pos4-1);
     else
        s_tempcolumn:=s_tempresult;
        --exit;
     end if;

     if instr(s_result,s_tempcolumn)>0 then
     s_result:=s_result;
     else
     s_result:=s_result||','||s_tempcolumn;
     end if;


  else
     if instr(s_result,s_tempresult)>0 then
     s_result:=s_result;
     else
      s_result:=s_result||','||s_tempresult;
     end if;
  exit;
  end if;
  end loop;
  s_result:=substr(s_result,2);
  --
 --Result:='selcet '||s_funcs||' from '||s_groupbytables||','||s_tables|| ' groupby '||s_groupby||s_result;
Result:='selcet '||s_funcs||' from '||s_result|| ' group by '||s_groupby;
  return(Result);
end CO_GET_STATISTICS;


/
