CREATE function co_get_state(v_SdId in number,v_Sdate in date,v_Edate in date,v_Scode varchar2) return number is
  Result number;
begin
  Select count(*) into Result From to_state 
   Where v_date between nvl(v_Sdate,to_char('1900-01-01','yyyy-mm-dd')) and to_date(to_char(nvl(v_Edate,sysdate),'yyyy-mm-dd'),'yyyy-mm-dd')+0.99999 
     and Instr(v_Scode,stype)>0 and sid=v_SdId;
  return(Result);
end co_get_state;


/
