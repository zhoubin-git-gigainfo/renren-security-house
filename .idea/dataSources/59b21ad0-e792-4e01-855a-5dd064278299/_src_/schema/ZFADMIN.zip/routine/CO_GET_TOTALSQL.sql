CREATE function CO_GET_TOTALSQL(s_stseq in number) return varchar2 is
  Result varchar2(5000);
  s_groupby varchar2(1000);
  s_groupbycolumn varchar2(1000);
  s_total   varchar2(1000);
  s_orderby varchar2(1000);
  s_tables  varchar2(1000);
  i_pos1 integer;
  i_pos2 integer;
  s_temptables varchar2(1000);
  s_temptablename varchar2(1000);
  s_resulttables varchar2(1000);
begin
  --取s_groupby
  select co_get_sumstr(cs_table||'.'||cs_name_en||' '||sta_ealias) into s_groupby  from ta_stelements t1,ts_class t2 where t2.cs_id=t1.cs_id(+) and t1.stseq=s_stseq and t1.cs_type=2260140;
   --取s_groupbycolumn
  select co_get_sumstr(sta_ealias) into s_groupbycolumn  from ta_stelements t1,ts_class t2 where t2.cs_id=t1.cs_id(+) and t1.stseq=s_stseq and t1.cs_type=2260140;
    --取s_total
 select co_get_sumstr(sta_type||'('||cs_table||'.'||cs_name_en||') '||sta_ealias) into s_total from ta_stelements t1,ts_class t2 where t2.cs_id=t1.cs_id(+) and t1.stseq=s_stseq and t1.cs_type=2260139;
     --取s_orderby
  select co_get_sumstr(cs_table||'.'||cs_name_en||' '||sta_order) into s_orderby  from ta_stelements t1,ts_class t2 where t2.cs_id=t1.cs_id(+) and t1.stseq=s_stseq and t1.cs_type=2260140;
     --取s_tables
  select co_get_sumstr(cs_table) into s_tables  from ta_stelements t1,ts_class t2 where t2.cs_id=t1.cs_id(+) and t1.stseq=s_stseq;
    
   --去除相同表名
  s_temptables:=s_tables;
  loop
  i_pos1:=instr(s_temptables,',');

  if i_pos1>0 then
  s_temptables:=substr(s_temptables,i_pos1+1);
  i_pos2:=instr(s_temptables,',');
     if i_pos2>0 then
        s_temptablename:=substr(s_temptables,1,i_pos2-1);
     else
        s_temptablename:=s_temptables;
        --exit;
     end if;

     if instr(s_resulttables,s_temptablename)>0 then
     s_resulttables:=s_resulttables;
     else
     s_resulttables:=s_resulttables||','||s_temptablename;
     end if;


  else
     if instr(s_resulttables,s_temptables)>0 then
     s_resulttables:=s_resulttables;
     else
      s_resulttables:=s_resulttables||','||s_temptables;
     end if;
  exit;
  end if;
  end loop;
  s_resulttables:=substr(s_resulttables,2);
  s_tables:=s_resulttables;
  
  --组合SQL
  Result:='select '||s_groupby||','||s_total||' from '||s_tables||' group by '||s_groupbycolumn||' order by '||s_orderby;
  
  return(Result);
end CO_GET_TOTALSQL;


/
