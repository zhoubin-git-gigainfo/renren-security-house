CREATE function SF_GET_OBLIGEE(OID in number)
return varchar2 is
  Result varchar2(512);
  v_ename varchar2(60);
begin
  DECLARE  
     CURSOR c_emp IS 
            SELECT distinct tm_mainbody.md_name FROM TO_RELATION,tm_mainbody
                   where TO_RELATION.sid=OID 
                     and TO_RELATION.Mid=tm_mainbody.md_id;  
     BEGIN  
        OPEN c_emp;  
        LOOP  
           FETCH c_emp INTO v_ename; 
           EXIT WHEN c_emp%NOTFOUND;
           If length(Result)>0 then
              Result:=Result||'，';
           End if;             
           Result:=Result||v_ename;
        END loop;
        CLOSE c_emp;
     End;
  return(Result);
end sf_get_obligee;


/
