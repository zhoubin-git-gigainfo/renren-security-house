CREATE function co_get_jsb_b1(xz_id varchar2, sdate varchar2, edate varchar2)
return co_table pipelined
is
begin
  declare
  my_type co_basic;
  
 begin
   --株洲市
  if (xz_id='430201') then
      Declare Cursor my_cur is
    select t2.rno,t2.cno,t2.t_ssmj,t2.t_qmks,t2.t_rote,t2.t_rote1
    from  sta_fixed t1, sta_unifiedrp1 t2
    where t1.sta_id=t2.sta_id and sta_sdate=sdate
    and sta_edate=edate
    and t1.sta_mid=100
    order by rno,cno;
    
    begin
      my_type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
      my_type.STR_3 := '株洲市';

      open my_cur;
           loop
               fetch my_cur into my_type.STR_1,my_type.STR_2, my_type.NUM_1,
               my_type.NUM_2, my_type.NUM_3, my_type.NUM_4;
               exit when my_cur%notfound;

               pipe row(my_type);
           end loop;
      close my_cur;
    return;
    
    end;
    
    
    
    --茶陵
  elsif (xz_id='430224') then
     Declare Cursor my_cur is

    select t2.rno,t2.cno,t2.t_ssmj,t2.t_qmks,t2.t_rote,t2.t_rote1
    from  sta_fixed t1, sta_unifiedrp1 t2
    where t1.sta_id=t2.sta_id and sta_sdate=sdate
    and sta_edate=edate
    and t1.sta_mid=100
    order by rno,cno;
    
     begin
      my_type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
      my_type.STR_3 := '茶陵';

      open my_cur;
           loop
               fetch my_cur into my_type.STR_1,my_type.STR_2, my_type.NUM_1,
               my_type.NUM_2, my_type.NUM_3, my_type.NUM_4;
               exit when my_cur%notfound;

               pipe row(my_type);
           end loop;
      close my_cur;
    return;
    
    end;
    
    
    --株洲县
     elsif (xz_id='430221') then
     Declare Cursor my_cur is

    select t2.rno,t2.cno,t2.t_ssmj,t2.t_qmks,t2.t_rote,t2.t_rote1
    from  sta_fixed t1, sta_unifiedrp1 t2
    where t1.sta_id=t2.sta_id and sta_sdate=sdate
    and sta_edate=edate
    and t1.sta_mid=100
    order by rno,cno;
    
     begin
      my_type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
       my_type.STR_3 := '株洲县';

      open my_cur;
           loop
               fetch my_cur into my_type.STR_1,my_type.STR_2, my_type.NUM_1,
               my_type.NUM_2, my_type.NUM_3, my_type.NUM_4;
               exit when my_cur%notfound;

               pipe row(my_type);
           end loop;
      close my_cur;
    return;
    
    end;
    
    --炎陵县
     elsif (xz_id='430225') then
     Declare Cursor my_cur is

    select t2.rno,t2.cno,t2.t_ssmj,t2.t_qmks,t2.t_rote,t2.t_rote1
    from  sta_fixed t1, sta_unifiedrp1 t2
    where t1.sta_id=t2.sta_id and sta_sdate=sdate
    and sta_edate=edate
    and t1.sta_mid=100
    order by rno,cno;
    
     begin
      my_type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
      my_type.STR_3 := '炎陵县';

      open my_cur;
           loop
               fetch my_cur into my_type.STR_1,my_type.STR_2, my_type.NUM_1,
               my_type.NUM_2, my_type.NUM_3, my_type.NUM_4;
               exit when my_cur%notfound;

               pipe row(my_type);
           end loop;
      close my_cur;
    return;
    
    end;
    
    --攸县
      elsif (xz_id='430223') then
     Declare Cursor my_cur is

    select t2.rno,t2.cno,t2.t_ssmj,t2.t_qmks,t2.t_rote,t2.t_rote1
    from  sta_fixed t1, sta_unifiedrp1 t2
    where t1.sta_id=t2.sta_id and sta_sdate=sdate
    and sta_edate=edate
    and t1.sta_mid=100
    order by rno,cno;
    
     begin
      my_type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
      my_type.STR_3 := '攸县';

      open my_cur;
           loop
               fetch my_cur into my_type.STR_1,my_type.STR_2, my_type.NUM_1,
               my_type.NUM_2, my_type.NUM_3, my_type.NUM_4;
               exit when my_cur%notfound;

               pipe row(my_type);
           end loop;
      close my_cur;
    return;
    
    end;
    
    --醴陵
      elsif (xz_id='430281') then
     Declare Cursor my_cur is

    select t2.rno,t2.cno,t2.t_ssmj,t2.t_qmks,t2.t_rote,t2.t_rote1
    from  sta_fixed t1, sta_unifiedrp1 t2
    where t1.sta_id=t2.sta_id and sta_sdate=sdate
    and sta_edate=edate
    and t1.sta_mid=100
    order by rno,cno;
    
     begin
      my_type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
       my_type.STR_3 := '醴陵';

      open my_cur;
           loop
               fetch my_cur into my_type.STR_1,my_type.STR_2, my_type.NUM_1,
               my_type.NUM_2, my_type.NUM_3, my_type.NUM_4;
               exit when my_cur%notfound;

               pipe row(my_type);
           end loop;
      close my_cur;
    return;
    
    end;
    
    
  end if;
 
    
  end;
 
end co_get_jsb_b1;
/
