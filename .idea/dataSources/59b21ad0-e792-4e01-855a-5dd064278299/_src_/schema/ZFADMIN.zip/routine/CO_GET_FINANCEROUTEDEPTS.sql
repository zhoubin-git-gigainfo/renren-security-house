CREATE function co_get_financeRouteDeptS(WFNO in number) Return integer is
  v_resu integer;
  v_apply_num number(15,2);
  v_item_id varchar2(100);
  v_useq number;
  v_deptid number;
  v_ifinance number;
begin
    select apply_num,item_id,useq  into v_apply_num,v_item_id,v_useq from tf_apply_bu a,ta_bscommon b where a.sseq=b.sseq and b.appseq=WFNO;
    select co_get_getDept(v_useq) into v_deptid from dual;
    select ifinance into v_ifinance from sysorgan where oseq=v_deptid;
    --是否是保障处
    IF (v_deptid=100000077167 and v_item_id in ('504020112','504020113','504020114','504020122')) then
       v_resu:=1;
    else
       v_resu:=0;
    End IF;
    return v_resu;
end co_get_financeRouteDeptS;


/
