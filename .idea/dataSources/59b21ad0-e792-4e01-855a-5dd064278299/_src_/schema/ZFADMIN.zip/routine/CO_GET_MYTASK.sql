CREATE function co_get_MyTask(App_no in number,user_id in number) return number
  is
  Recs integer;
  v_mj number(12);
begin
----如果是待办业务，可显示
  Select Count(*) into Recs 
    From apptasks Where tappseq=App_no and tuser=user_id AND tstate>0;
  If Recs>0 Then Return 1; End if;
  
--是否为管理员
  Select Count(*) into Recs from AppWorkFlow,AppDefine 
   where appseq=App_no and APPBID=BID
     and instr(','||adminid||',',','||to_char(user_id)||',')>0;
  If Recs>0 Then Return 1; End if;
  
--参与处理？  
  Select Count(*) into Recs 
    From apptasks Where tappseq=App_no and tuser=user_id;
    
  If Recs>0 Then --参与处理人，再去判断是否为平件
      Select Count(*) into v_mj --586=平件
        From sv_wfapp Where appseq=App_no and APPSECRECY=586;
      If Recs>0 Then Return 1; End if;  --参与处理并且是平件
  Else --未参与处理
      Select Count(*) into Recs From SysUserOrg,sysorgan  --是否为机要文书
       where USEQ=user_id and SysUserOrg.oseq=sysorgan.oseq
         and (OCATLOG=80 or OCATLOG=82); 
      If Recs>0 Then Return 1; End if;
  End if;    
  
  Return 0;

end co_get_MyTask;


/
