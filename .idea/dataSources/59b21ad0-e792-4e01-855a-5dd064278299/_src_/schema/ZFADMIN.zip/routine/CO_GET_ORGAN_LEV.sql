CREATE function CO_GET_ORGAN_LEV(stroseq in number)
return varchar2 is
strOrganLev varchar2(3000);
stroparent number;
stroname varchar2(200);
recs integer;
begin
  strOrganLev:='';
   select count(*) into recs from sv_organ where oseq=stroseq;
   stroparent:=stroseq;
   while  recs>0 loop
      select oparent,oname into stroparent,stroname from sv_organ where oseq=stroparent;
         strOrganLev:= stroname||'/'||strOrganLev; 
      select count(*) into recs from sv_organ where oseq=stroparent;
   end loop;
  return strOrganLev;
end;


/
