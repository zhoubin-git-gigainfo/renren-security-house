CREATE function cre_sd_indexdata(SD_ID number,SD_Type number) return clob is
  Result clob;
  l_Sql varchar2(4000);
  v_tmp varchar2(10);
begin

  if SD_Type=1 Then  --建栋
     l_Sql:='Select ''ID''||to_char(SID) 编号,metno 用户码,ddesc 区, lname 坐落,bdesc 栋名,Decode(BSTATE,''11'',''期房'',''12'',''现房'',''13'',''待拆'',''14'',''灭失'',null) 状态,bstru 结构,buse 用途,lcout 层数,bfete 建设年代,pno 地号,pcardno 证号,co_convert_code(PUID,'') 土地用途,co_convert_code(PYID,'') 取得方式,UYEAR 使用年限 From tu_bldg,tu_plot Where sid=#SD_ID# and tu_bldg.plotid=tu_plot.plotid(+)';
     v_tmp:='栋';
  Else
     l_Sql:='Select ''ID''||to_char(Hid) 编号,tu_bldg.metno 用户码,ddesc 区, lname 坐落,bdesc 栋名,Decode(hno,hdesc,hno,hno||''/''||hdesc) 房号,Decode(BSTATE,''11'',''期房'',''12'',''现房'',''13'',''待拆'',''14'',''灭失'',null) 状态,co_convert_code(tu_house.bstru,null) 结构,co_convert_code(tu_house.huse,null) 用途,lcout 层数,bfete 建设年代  From tu_bldg,tu_house where hid=#SD_ID# and tu_bldg.sid=tu_house.sid';
     v_tmp:='户';
  End if;
  l_sql:=Replace(l_Sql,'#SD_ID#',to_char(SD_ID));
  Result:=co_get_xml(l_Sql,'房屋',v_tmp);
  return(Result);
end cre_sd_indexdata;


/
