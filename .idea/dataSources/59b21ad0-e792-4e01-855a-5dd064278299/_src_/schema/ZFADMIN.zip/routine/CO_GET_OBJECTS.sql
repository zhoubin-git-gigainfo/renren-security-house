CREATE function CO_GET_OBJECTS(OBJ_ARRY in co_key_array,OCount in Number)
RETURN co_table PIPELINED
IS
  My_Type   co_basic;
  i         integer;
begin
  i:=0;
   FOR i IN 1 .. OCount LOOP
       My_Type:=co_basic(i,OBJ_ARRY(i),1,2,3,4,5,'1','2','3','4','5',sysdate,sysdate);
       PIPE ROW (My_Type);
  END LOOP;

  RETURN;
end;


/
