CREATE FUNCTION co_get_sumstr(Field_name varchar2 )
RETURN varchar2
PARALLEL_ENABLE AGGREGATE USING co_sumstr;


/
