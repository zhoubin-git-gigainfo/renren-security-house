CREATE function esf_getSechlistingSseq(v_sseq number)
return number
is
retSseq number;
v_index number;
v_md_id number;
v_sid number;
begin
  retSseq := 0;
  v_index := 0;

  --找到当前合同业务的经济机构MD_ID
  select count(md_id) into v_index from ta_mainbody
  where apptype=3 and f_date is null and sseq=v_sseq;

  if(0=v_index) then
    return retSseq;
  end if;

  select md_id into v_md_id from ta_mainbody where apptype=3
  and f_date is null and sseq=v_sseq;

  v_index := 0;
  --找到当前合同业务的房子SID
  select count(sd_id) into v_index from taq_sdlist where sseq=v_sseq and rownum=1;

  if(0=v_index) then
    return retSseq;
  end if;

  select sd_id into v_sid from taq_sdlist where sseq=v_sseq and rownum=1;

  v_index := 0;
  --通过关系找到挂牌业务号
  select count(bid) into v_index from To_Relation where f_date is null
  and modality=0 and apptype=2 and mid=v_md_id and sid=v_sid;

  if(0=v_index) then
    return retSseq;
  end if;

  select bid into retSseq from To_Relation where f_date is null
  and modality=0 and apptype=2 and mid=v_md_id and sid=v_sid;

  return retSseq;

end;
/
