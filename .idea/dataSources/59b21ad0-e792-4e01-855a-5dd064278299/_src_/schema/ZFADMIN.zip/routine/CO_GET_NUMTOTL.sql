CREATE function co_get_NumTotl(Key_name in varchar2,Key_Val in number,Col_Name in varchar2,Tab_Name  in varchar2,expStr in varchar2) return number is
  Result number;--number;
  str    varchar2(32767);
begin
    str:='Select Sum(nvl('||col_name||',0)) from '|| tab_name || ' where ' || key_name || '='||to_char(Key_Val);
    If not expStr is null then
       str:=str||' and '||expStr;
    End if;
    execute immediate str into Result;
    return(Result);
end co_get_NumTotl;


/
