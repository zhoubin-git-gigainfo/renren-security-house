CREATE function CO_GET_FUNCAREAONE(area in VARCHAR2,strclh in number,strcc in VARCHAR2)
return VARCHAR2 is
   strtemp varchar2(4000);
   strtemp1 varchar2(4000);
   strone  varchar2(4000);
   strlayer  varchar2(200);
   strshouse varchar2(500);
   strehouse varchar2(500);
   formatarea varchar2(4000);
   intfhlen integer;
   strlayer1 varchar2(500);
   strlayer2 varchar2(500);
   strlayer3 varchar2(500);
begin
  strtemp:=area;
  strone:=strtemp;
  strlayer:=strcc;
  /*非标准层*/
  intfhlen:=-co_get_fhlen(strclh);
  if (instr(strtemp,'~',1,1)>0) then
  begin
    while instr(strtemp,'~',1,1)>0
    loop
       strtemp1:=substr(strtemp,1,instr(strtemp,'~',1,1)-1);
       formatarea:=formatarea||co_get_functrans(strtemp1,strclh,strlayer,1);
       strtemp:=substr(strtemp,instr(strtemp,'~',1,1)+1,length(strtemp)-instr(strtemp,'~',1,1));
    end loop;
       formatarea:=formatarea||co_get_functrans(strtemp,strclh,strlayer,1);
   end;
   else
   begin
     formatarea:=formatarea||co_get_functrans(strone,strclh,strlayer,0);
   end;    
   end if;
   
/*标准层*/
  strlayer1:=substr('000'||strlayer,-2);
  if length(co_get_samefloor(strclh,strlayer1))>0 then
  begin
      strlayer2:=co_get_samefloor(strclh,strlayer1);
      while(instr(strlayer2,',',1,1)>0)
      loop 
        strlayer3:=substr(strlayer2,1,2); 
        strlayer2:=substr(strlayer2,instr(strlayer2,',',1,1)+1,length(strlayer2)-instr(strlayer2,',',1,1));
        intfhlen:=-co_get_fhlen(strclh);
       strtemp:=area;      
        if (instr(strtemp,'~',1,1)>0) then
        begin
          while instr(strtemp,'~',1,1)>0
          loop
             strtemp1:=substr(strtemp,1,instr(strtemp,'~',1,1)-1);
             formatarea:=formatarea||','||co_get_functrans(strtemp1,strclh,strlayer3,1);
             strtemp:=substr(strtemp,instr(strtemp,'~',1,1)+1,length(strtemp)-instr(strtemp,'~',1,1));
          end loop;
             formatarea:=formatarea||co_get_functrans(strtemp,strclh,strlayer3,1);
         end;
         else
         begin
           formatarea:=formatarea||','||co_get_functrans(strone,strclh,strlayer3,0);
         end;    
         end if;               
      end loop;
     /*标准层最后一层*/ 
       strtemp:=area;     
       if (instr(strtemp,'~',1,1)>0) then
        begin
          while instr(strtemp,'~',1,1)>0
          loop
             strtemp1:=substr(strtemp,1,instr(strtemp,'~',1,1)-1);
             formatarea:=formatarea||','||co_get_functrans(strtemp1,strclh,strlayer2,1);
             strtemp:=substr(strtemp,instr(strtemp,'~',1,1)+1,length(strtemp)-instr(strtemp,'~',1,1));
          end loop;
             formatarea:=formatarea||co_get_functrans(strtemp,strclh,strlayer2,1);
         end;
         else
         begin
           formatarea:=formatarea||','||co_get_functrans(strone,strclh,strlayer2,0);
         end;    
         end if;
  end;
  end if;   
   
   
  return formatarea;
end;


/
