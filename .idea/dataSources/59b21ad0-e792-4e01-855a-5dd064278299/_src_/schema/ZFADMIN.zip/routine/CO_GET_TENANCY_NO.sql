CREATE function  co_get_tenancy_no  return varchar2 is

  Result varchar2(40);
  v_year varchar2(8);
  v_tno varchar2(8);
/*代码转换
  输入:
     cid—代码ID
     ckey—装换
  输出
     Result—代码说明
*/
begin
  select to_char(sysdate,'yyyymmdd') year, co_get_seq('TENANCYNO') tno into v_year, v_tno from dual;
  if length(v_tno)=1 then
    v_tno:='00000'||v_tno;
    end if;
    if length(v_tno)=2 then
      v_tno:='0000'||v_tno;
      end if;
    if length(v_tno)=3 then
      v_tno:='000'||v_tno;
      end if;
     if length(v_tno)=4 then
      v_tno:='00'||v_tno;
      end if;
      if length(v_tno)=5 then
      v_tno:='0'||v_tno;
    
     end if;
  Result  :=v_year||v_tno;

  Return(Result);
  
  --Exception when others then return '未指定';
end co_get_tenancy_no;
/
