CREATE function co_apptype_code(apptype in number,bid in varchar2) return varchar2 is
  Result varchar2(40);
begin
--Results varchar2(10);
     Select name into Result
     FROM ( SELECT NVL((Select name
              From ts_code
             Where bk_hue = 'APPLYTYPE'
               and cname = to_char(apptype)
               and instr(ckey, bid) > 0),
            (Select name
               From (select name, bk_hue, cname, ckey from ts_code)
              Where bk_hue = 'APPLYTYPE'
                and cname = to_char(apptype)
                and ckey = 'DEFAULT')) name
   FROM DUAL) ;
     --  From (select name,bk_hue,cname,ckey from ts_code)
     --  Where bk_hue='APPLYTYPE' and cname=apptype||'' and instr(ckey,bid||',')>0;
     --  dbms_output.put_line('通过');  
     --if Result is null then--假如没有定义则使用默认的ckey='DEFAULT'
      -- Select name into Result
      --  From (select name,bk_hue,cname,ckey from ts_code)
      -- Where bk_hue='APPLYTYPE' and cname=apptype||'' and ckey='DEFAULT';
    -- End if;
  Return(Result);
 -- Exception when others then return '不详';
    Exception when others then
       -- dbms_output.put_line(sqlcode||'：'||sqlerrm);  
       return '';
end co_apptype_code;


/
