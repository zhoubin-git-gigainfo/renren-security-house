CREATE function CO_GET_APPLY(BID in number)
return fc_type is
  Result fc_type;
  v_name       varchar2(80);
  v_addr       varchar2(80);
  v_icno       varchar2(80);
  v_tel        varchar2(80);
  v_first      Integer;
Begin
--1、初始化自定义类型
  Result:=fc_type(0,0,'','','','');
  v_first:=0;
--3、获取用途组合名称和主用途编码
  DECLARE
     CURSOR MyUse IS
            Select agentname,ic_type||' '||ic_no,agenttelephone,agentaddress
              From ta_agent Where sseq=BID and maintypeid=1;
      BEGIN
        OPEN MyUse;
        LOOP
           FETCH MyUse INTO v_name,v_icno,v_tel,v_addr;
           EXIT WHEN MyUse%NOTFOUND;
           If v_first=0 Then
              Result.R_SCODE:=v_icno;
              Result.R_UCODE:=v_tel;
              Result.R_SNAME:=v_addr;
              v_first:=1;
           End if;
           If length(Result.R_UNAME)>0 then
              Result.R_UNAME:=Result.R_UNAME||'，';
           End if;
           If length(Result.R_UNAME||v_name)<=2048 then
              Result.R_UNAME:=Result.R_UNAME||v_name;
           End if;
        END loop;
        CLOSE MyUse;
     End;
  return(Result);
end co_get_Apply;


/
