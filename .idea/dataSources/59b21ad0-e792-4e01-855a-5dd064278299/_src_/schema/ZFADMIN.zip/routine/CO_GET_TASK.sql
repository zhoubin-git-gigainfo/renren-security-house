CREATE function co_get_Task(App_no in number,user_id in number)
  RETURN co_table PIPELINED is
  My_Type   co_basic;
begin

  My_Type:=co_basic(0,null,null,null,null,null,App_no,null,null,null,null,null,null,null);

  Select wfstate into My_Type.NUM_1 From appworkflow Where appseq=App_no;

  If My_Type.NUM_1=0 then
--     Select max(tseq),max('结束') into My_Type.id,My_Type.STR_1 From apptasks Where tappseq=App_no;
     Select max(tseq),max('结束') into My_Type.id,My_Type.STR_1 From apptasks Where tappseq=App_no;
     PIPE ROW (My_Type);
     return;
  End if;

  Select count(*) into My_Type.NUM_1 From apptasks Where tappseq=App_no and tuser=user_id and tstate>0;
  If My_Type.NUM_1>0 then
     Select min(tseq),max('待办') into My_Type.id,My_Type.key From apptasks Where tappseq=App_no and tuser=user_id and tstate>0;
     PIPE ROW (My_Type);
     return;
  End if;

  Select Count(*) into My_Type.NUM_1
    From (Select max(pt.tseq),sum(Decode(ct.tstate,0,1,0))
            From apptasks pt,apptasks ct
           Where pt.tappseq=App_no and ct.tappseq=App_no and pt.tactseq=ct.preactseq
             and pt.tuser=user_id and ct.preuser=user_id
           Group by pt.tappseq,pt.tuser
           having sum(Decode(ct.tstate,0,1,0))=0);

  If My_Type.NUM_1>0 then
     Select max(pt.tseq),max('可收回'),sum(Decode(ct.tstate,0,1,0)) into My_Type.id,My_Type.key,My_Type.NUM_1
       From apptasks pt,apptasks ct
      Where pt.tappseq=App_no and ct.tappseq=App_no and pt.tactseq=ct.preactseq
        and pt.tuser=user_id and ct.preuser=user_id
      Group by pt.tappseq,pt.tuser
      having sum(Decode(ct.tstate,0,1,0))=0;
      PIPE ROW (My_Type);
      return;
  End if;

  Select max(tseq),max('办理中') into My_Type.id,My_Type.key From apptasks Where tappseq=App_no;
  PIPE ROW (My_Type);
  
  return;

end co_get_Task;


/
