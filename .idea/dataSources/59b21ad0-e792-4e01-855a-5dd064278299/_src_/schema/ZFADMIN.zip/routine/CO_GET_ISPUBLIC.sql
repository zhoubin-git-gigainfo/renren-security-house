CREATE function co_get_IsPublic(v_SdId in number, v_PubFlag in number) return number is
  v_recs integer;
begin
  If v_PubFlag=145001 Then
     Select count(*) into v_recs From tu_state where stype='44' and sid=v_SdId;
     If v_recs=0 Then 
        Return 1;
     Else
        Return 0;
     End if;
  Else
     Return 1;
  End if;
end co_get_IsPublic;


/
