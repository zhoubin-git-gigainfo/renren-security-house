CREATE function CO_GET_onLayer(intSID in number)
return varchar is
   strlno varchar(200);
   strMinLno varchar(100);
   strMaxLno varchar(100);
begin
  select min(lno) into strMinLno from tu_layer where sid=intSID;
  select max(lno) into strMaxLno from tu_layer where sid=intSID;
  strlno:=strMinLno||'-'||strMaxLno;
  return strlno;
end;


/
