CREATE function CO_GET_BULink(Bu_No in number) return
 --varchar2 is
    co_table PIPELINED is
    My_Type     co_basic;
    v_UpLink    varchar2(32767);
    v_DnLink    varchar2(32767);
    v_Recs      Integer;
    v_Sql       varchar2(6000);
    type rc is ref cursor;
    cur    rc;
Begin
--1、初始化自定义类型

    My_Type:=co_basic(null,null,null,null,null,null,0,null,null,null,null,null,null,null);
    Select count(*) into v_Recs From tu_card Where bid=Bu_No;
    If v_Recs=0 Then 
       Return ;
    End if;
    Select 0,bid,cdno,ocdno into My_Type.id,My_Type.NUM_1,My_Type.STR_1,My_Type.STR_2 
      From tu_card Where bid=Bu_No;
    PIPE ROW (My_Type);
    v_UpLink:='~'||My_Type.STR_1;
    Loop
        Select count(*) into v_Recs From tu_card Where cdno=My_Type.STR_2;
        v_Sql:='Select '||to_char(My_Type.id-1)||',bid,cdno,ocdno From tu_card Where cdno=:x';
        Open cur for v_Sql using nvl(My_Type.STR_2,'~~~~~');
        Loop
            Fetch cur into My_Type.id,My_Type.NUM_1,My_Type.STR_1,My_Type.STR_2;
            Exit when cur%notfound;
            If Instr(v_UpLink,'~'||My_Type.STR_1)!=0 Then
               v_Recs:=0;
            End if;
            PIPE ROW (My_Type);
            v_UpLink:='~'||My_Type.STR_1||v_UpLink;       
        End loop;
        close cur;
        If v_Recs!=1 Then 
           Exit; 
        End if;
    End loop;

    Select 0,bid,cdno,ocdno into My_Type.id,My_Type.NUM_1,My_Type.STR_1,My_Type.STR_2 
      From tu_card Where bid=Bu_No;
    Loop
        Select count(*) into v_Recs From tu_card Where ocdno=My_Type.STR_1;
        v_Sql:='Select '||to_char(My_Type.id+1)||',bid,cdno,ocdno From tu_card Where ocdno=:x';
        Open cur for v_Sql using nvl(My_Type.STR_1,'~~~~~');
        Loop
            Fetch cur into My_Type.id,My_Type.NUM_1,My_Type.STR_1,My_Type.STR_2;
            Exit when cur%notfound;
            If Instr(v_UpLink,'~'||My_Type.STR_1)!=0 Then
               v_Recs:=0;
            End if;
            PIPE ROW (My_Type);
            v_UpLink:=v_UpLink||'~'||My_Type.STR_1;       
        End loop;
        close cur;
        If v_Recs!=1 Then 
           Exit; 
        End if;
    End loop;  
    Return ;
end CO_GET_BULink;


/
