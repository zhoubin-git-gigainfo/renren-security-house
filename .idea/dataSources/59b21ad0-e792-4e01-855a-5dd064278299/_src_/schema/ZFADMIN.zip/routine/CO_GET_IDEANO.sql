CREATE function CO_GET_IDEANO(Ref_Act in varchar2,Idea_No varchar2,Idta_title varchar2)
RETURN co_table PIPELINED
IS
    My_Type       co_basic;
    v_Star       integer;  
    v_End        integer;  
    v_Count      integer;
    v_RefID      varchar2(2048);
    v_RefNo      varchar2(2048);
    v_Title      varchar2(2048);
    v_ID         integer;
    v_key        varchar2(20);
    v_Tit        varchar2(200);
begin
  v_RefID:=Ref_Act||',';
  v_RefNo:=Idea_No||',';
  v_Title:=Idta_title||',';
  My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
  v_Count:=1;
  
  LOOP
    v_Star:= INSTR (v_RefID, ',', v_Count);
    If v_Star>0 Then
       --分割活动ID
       v_key:=Substr(v_RefID,1,v_Star-1);
       v_RefID:=substr(v_RefID,v_Star+1);
       --分割意见序号
       v_Star:= INSTR (v_RefNo, ',', v_Count);
       v_ID:=to_number(Substr(v_RefNo,1,v_Star-1)); 
       v_RefNo:=substr(v_RefNo,v_Star+1); 
       --分割意见标题
       v_Star:= INSTR (v_Title, ',', v_Count);
       v_Tit:=Substr(v_Title,1,v_Star-1); 
       v_Title:=substr(v_Title,v_Star+1);      
       My_Type := co_basic(v_ID,v_key,0,0,0,0,0,v_Tit,'','','','',null,null);
       PIPE ROW (My_Type);
       v_Count:=v_Count+1;
    Else
       Exit;
    End if;

  END LOOP;

  return;

  return;
end co_get_Ideano;


/
