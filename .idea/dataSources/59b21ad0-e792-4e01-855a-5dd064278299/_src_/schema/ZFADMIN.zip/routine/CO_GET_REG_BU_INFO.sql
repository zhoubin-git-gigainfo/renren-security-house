CREATE function co_get_Reg_BU_Info(Bu_No in number)  return clob is
/*  ============== 返回业务的信息数据（XML格式） =================
    输入：Bu_No=业务编号
    输出：Result=业务信息（内容：业务、主体、客体、权证、意见）
    接口：被过程co_set_reg_bu_info调用。
    =============================================================*/
  Result clob;
  v_BuNo     number;
  v_OldBuNo  number; 
  v_InfoDM   varchar2(20);
  v_val      varchar2(32767);
  v_tag      varchar2(20);
  l_sql      varchar2(32767);
  v_tmp      clob;
  v_UpdMod   varchar2(2);
  v_StCode   varchar2(2);
  v_MDList   varchar2(100);
  v_MDCount  Integer;
  v_StName   varchar2(60);
begin
    v_BuNo:=nvl(Bu_No,0);
    --v_SDID:=nvl(SD_ID,0);
    dbms_lob.createtemporary(Result, TRUE);
    Select distinct Bu_Pix,optmod,b.state_id,osseq  into v_InfoDM,v_UpdMod,v_StCode,v_OldBuNo
      From sv_bulists a,appdefine b
      where a.bseq=b.bseq and a.sseq=v_BuNo;
      
    If v_StCode='**' Then  --属于变更、换补证业务，基本业务类型及数据与原业务是一致的    If v_STCode='**' then
       If v_OldBuNo is null Then
          Select max(stype) into v_STCode from to_state t1,taq_olist t2
           Where t1.bid=t2.osseq and t1.sid=t2.hid and t2.sseq=v_BUNO;
       Else
          Select max(stype) into v_STCode from to_state where bid=v_OldBuNo;
       End if;
    End if;  
    
    Select count(*) into v_MDCount from ts_state Where st_code=v_StCode;
    If v_MDCount>0 then
       Select MD_list into v_MDList From ts_state Where st_code=v_StCode;
    end if;
    
--1、   获取业务、客体、权证、意见信息（由配置表sysconfig定义）

    Select '<权利方式>'||st_name||'</权利方式>' into v_StName from ts_state where st_code=v_StCode;
    
    Declare CURSOR cur_Sql IS --取出需要登记的自然状况信息DML Select语句
            Select cfgvalue From sysconfig Where cfgkey like v_InfoDM||'%' order by cfgkey;
    BEGIN
        OPEN cur_Sql;
        LOOP
            FETCH cur_Sql INTO v_val;
            EXIT WHEN cur_Sql%NOTFOUND;
            v_tag:=Substr(v_val,1,Instr(v_val,'=')-1);
            l_sql:=Substr(v_val,Instr(v_val,'=')+1);
            l_sql:=replace(l_sql,'#BU_NO#',to_char(v_BuNo));
            v_tmp:=co_get_xml(l_sql,v_Tag||'信息',v_tag);
            v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
            v_tmp:=replace(v_tmp,'<状态码>**</状态码>','<状态码>'||v_StCode||'</状态码>');
            v_tmp:=replace(v_tmp,'<权利方式>权利</权利方式>',v_StName);
            dbms_lob.append(Result,v_tmp);
        End loop;
        Close cur_Sql;
    End;
    
--2、主体信息  

    l_sql:='Select key 申请类别,num_2 编号,str_1 名称,co_convert_code(num_3,null)||str_2 证明,str_3 电话,str_4 地址,str_5 被代理人 from table(co_get_applys(#BU_NO#,0))';
    l_sql:=replace(l_sql,'#BU_NO#',to_char(v_BuNo));
    v_tmp:=co_get_xml(l_sql,'代理人信息','代理人');
    v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
    v_tmp:=replace(v_tmp,'<代理人/>','');
    dbms_lob.append(Result,v_tmp);

    Select cfgvalue into l_sql From Sysconfig Where cfgkey='MD_Apply';
    Select MD_list into v_MDList From ts_state Where st_code=v_StCode;
    l_sql:=Replace(replace(l_sql,'#BU_NO#',to_char(v_BuNo)),'#MD_List#',v_MDList);
    v_tmp:=co_get_xml(l_sql,'主体信息','主体');
    v_tmp:=replace(v_tmp,'<?xml version = ''1.0''?>','');
    v_tmp:=replace(v_tmp,'<主体信息/>','');
    dbms_lob.append(Result,v_tmp);
    
    Result:='<?xml version="1.0" encoding="UTF-8"?>'||chr(13)||'<SD_Info>'||Result||chr(13)||'</SD_Info>';

    Return(Result);
end co_get_Reg_bu_Info;


/
