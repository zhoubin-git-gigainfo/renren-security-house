CREATE function CO_GET_ACCEPT(BU_No in Number,Info_Type varchar2)
RETURN co_table PIPELINED
  /*输入参数说明：
  BU_No：业务号
  Info_Type：需要获取的业务数据类型
             AGENT-代理人
             APPLY-申请(委托)人               
  */
IS
  My_Type   co_basic;
  v_first   Integer;
  v_name    varchar2(80);
  v_addr    varchar2(80);
  v_icno    varchar2(80);
  v_tel     varchar2(80);
  v_zip     varchar2(80);
  --v_reg     varchar2(80);
  v_info    varchar2(80);
begin
--一、初始化自定义类型
  My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
  v_first:=0;
  v_info:=UPPER(Info_Type);
  
--二、通用业务信息

--1、取代理人或申请人信息(姓名、证件、电话、地址)
  If v_info='AGENT' Or v_info='APPLY' Then 
      DECLARE
         CURSOR MyCur IS
                Select agentname,ic_no,agenttelephone,agentaddress,agentzip
                  From ta_agent Where sseq=BU_No and maintypeid=Decode(v_info,'AGENT',0,1);
         BEGIN
            OPEN MyCur;
            LOOP
               FETCH MyCur INTO v_name,v_icno,v_tel,v_addr,v_zip;
               EXIT WHEN MyCur%NOTFOUND;
               If v_first=0 Then
                  My_Type.Str_2:=v_icno;
                  My_Type.Str_3:=v_tel;
                  My_Type.Str_4:=v_addr;
                  My_Type.Str_5:=v_zip;
                  v_first:=1;
               End if;
               If length(My_Type.Str_1)>0 then
                  My_Type.Str_1:=My_Type.Str_1||'，';
               End if;
               If length(My_Type.Str_1||v_name)<=2048 then
                  My_Type.Str_1:=My_Type.Str_1||v_name;
               End if;
            END loop;
            CLOSE MyCur;
            My_Type := co_basic(0,v_info,null,null,null,null,null,My_Type.Str_1,My_Type.Str_2,My_Type.Str_3,My_Type.Str_4,My_Type.Str_5,null,null);
            PIPE ROW (My_Type);
         End;
     End if;
     
--三、返回结果（）
     return;
end co_get_accept;


/
