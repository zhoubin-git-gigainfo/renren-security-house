CREATE function CO_GET_TAWFEE(v_paccount in varchar2,V_PTYPE IN NUMBER, V_FTYPE IN NUMBER)
return varchar2 is

  AMOUNT      NUMBER(15,3);

Begin
--1、初始化自定义类型
--3、获取用途组合名称和主用途编码
  --DECLARE

  IF(V_PTYPE!=0 ) THEN
select   sum(t2.bamount) into AMOUNT
           from taw_fee t2
          where t2.ptype = V_PTYPE
            and  t2.paccount = v_paccount;
END IF;

IF(V_FTYPE!=0 ) THEN
select   sum(t2.bamount) into AMOUNT
           from taw_fee t2
          where t2.Ftype = V_FTYPE
            and  t2.paccount = v_paccount;
END IF;

  return(AMOUNT);
end CO_GET_TAWFEE;


/
