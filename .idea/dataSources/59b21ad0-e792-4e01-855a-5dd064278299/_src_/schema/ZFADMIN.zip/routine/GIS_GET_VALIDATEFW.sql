CREATE function GIS_GET_ValidateFW(strTF in varchar2,strQiu in varchar2,strZH in varchar2,strSeq in varchar2)
return integer is
  Result integer;
   PRAGMA AUTONOMOUS_TRANSACTION; 
  newQiuID varchar2(10);
  fwcount integer;
begin
  Result:=0;
    select count(*) into fwcount from GIS_FWINFO where tfn=strTF and qiun=strQiu and fwn=strZH;
    commit;
    if (fwcount=0) then
    begin
        insert into gis_fwinfo(tfn,qiun,fwn,source) values(strTF,strQiu,strZH,strSeq);
         Result:=1;
         commit;
    end;
    else
       Result:=0;
    End if;
  return(Result);
end GIS_GET_ValidateFW;


/
