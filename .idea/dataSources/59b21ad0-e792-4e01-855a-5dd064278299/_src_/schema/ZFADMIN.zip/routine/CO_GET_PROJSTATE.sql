CREATE function co_get_projstate(pseq in number) return varchar2 is
  Result varchar2(10);
  
   v_yscount  number;
   v_zsstate number;
    v_wcstate number;
   
/*获取项目状态
  输入:
     pid—代码ID
    
*/
begin
   
 select count(*) into v_wcstate from to_state where 
    f_date is null and  stype ='38'    and sid=pseq and rownum=1;
 
    if  v_yscount=0 and v_wcstate=1 then
      return('完成');
      End if;   
   
select count(*) into v_yscount from to_state t1,tu_house t4,tu_bldg t2,tu_pbldg t3
where t1.f_date is null and
t1.sid=t4.hid  
and t4.sid=t2.sid  and t2.sid=t3.sid
 and stype='31' and t3.pid=pseq and rownum=1;

     
    if v_yscount=1 then
        return('在售');
     end if;
    
     select count(*) into v_zsstate from to_state where 
    f_date is null and (stype ='9'   ) and sid=pseq and rownum=1;
   
    if v_yscount=0 and v_zsstate=1 then
       return('筹建');
     end if;  
       
    
  Return(Result);
  --Exception when others then return '未指定'; 
end co_get_projstate;


/
