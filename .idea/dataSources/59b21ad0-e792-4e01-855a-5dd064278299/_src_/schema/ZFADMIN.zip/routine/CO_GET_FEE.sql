CREATE function CO_GET_FEE(BU_SEQ in number)
RETURN 
number 
--co_table PIPELINED
IS
    My_Type        co_basic;
    v_Parm         dbms_sql.Number_Table ;
    v_Vals         integer;
    v_Tmp          varchar2(60);
    v_BSEQ         number(12);
    v_BuType       Integer;
    IsFound        integer;
    v_Toal         number;
        
    type rc is ref cursor;
    cur    rc;
    l_Sql    varchar2(6000);


Begin
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    --My_Item:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);

    Select a.bseq,b.apptype into v_BSEQ,v_BuType from sv_bulists a,appdefine b Where a.sseq=BU_SEQ and a.bseq=b.bseq;
--一、计费依据
    v_Parm(1):=1;--缺省（业务数）
    v_Parm(2):=0;--确定价值
    v_Parm(3):=0;--贷款额
    v_Parm(4):=0;--客体数
    v_Parm(5):=0;--面积
    v_Parm(6):=1;
    v_Parm(7):=0;--发证数
    
    If v_BuType=2 or v_BuType=5 Then   --测量收费       
   
        If v_BSEQ=1806000 Then
           Select sum(barea) into v_Toal From tac_sdlist Where sseq=BU_SEQ;
        Else
           Select to_number(zjzmj) into v_Toal From ta_zxx Where sseq=BU_SEQ;
        End if;
        
        l_Sql:='Select '||to_char(v_Toal)||',Decode(count(distinct ta_hxx.useid),1,''单用途'',''多用途'')';
        l_Sql:=l_Sql||'||''/''||Decode(Instr(co_get_codepath(min(ta_hxx.useid)),''/110''),0,''非住宅'',''住宅'')';
        l_Sql:=l_Sql||' From ta_hxx,ta_zxx where ta_zxx.sseq=ta_hxx.sseq and ta_zxx.sseq='||BU_SEQ;
        
    End if;
  

    If v_BuType=6 Then   --档案收费
        l_sql:='Select 1,decode(cb_type,230,''私产'',''其他'') From ta_qarchives Where sseq='||BU_SEQ;
    End if;


    If v_BuType=4 Then  --登记收费
    
       --契税、地税、工本费参数
       l_Sql:='Select Sum(pprice),max(Decode(Instr(co_get_codepath(case when ascii(BuseID)<58 and ascii(BuseID)>48 then BuseID else ''0'' end),''/''||''110''),0,''非住宅'',''住宅''))||''/''||max(case when barea<144 Or parea<120 then ''普通'' else ''非普通'' end) From taq_sdlist  where sseq=#SSEQ#';
       l_Sql:=l_Sql||' union all Select sum(pprice) From taq_sdlist where sseq=#SSEQ#';--综合税
       l_Sql:=l_Sql||' union all Select cardcount-1 From taq_enrol where sseq=#SSEQ#'; --工本费
       l_Sql:=Replace(l_Sql,'#SSEQ#',to_char(BU_SEQ));

       If v_Parm(3)<=20000000 Then v_Tmp:='2K万'; End if;
       If v_Parm(3)>20000000 and v_Parm(3)<=50000000 Then v_Tmp:='5K万'; End if;
       If v_Parm(3)>50000000 and v_Parm(3)<=100000000 Then v_Tmp:='10K万'; End if;
       If v_Parm(3)>100000000 then v_Tmp:='1亿'; End if;


    End if;
    
    Declare CURSOR cur_TItem IS
            Select b.cid,b.name From ts_tariff a,ts_titem b Where a.bseq=v_BSEQ and a.iid=b.cid ;
    Begin
        Open cur_TItem;
        Loop
            Fetch cur_TItem Into My_Type.ID,v_Tmp;
            Exit When cur_TItem%NotFound;
            IsFound:=0;
            Declare CURSOR Cur_Sel IS
                    Select to_char(connect_by_isleaf),ver_val,MOD_tax,ltrim(sys_connect_by_path(ver_name,'/'),'/'),
                          ltrim(sys_connect_by_path(ver_mod,'/'),'/'),udesc,Icode,mod_bas
                     from ts_price start with ver_id=My_Type.ID connect by nocycle prior ver_id = parentid;
            Begin
                Open Cur_Sel;
                Loop
                   Fetch Cur_Sel Into My_Type.key,My_Type.num_1,My_Type.STR_3,My_Type.STR_1,My_Type.STR_5,My_Type.str_2,My_Type.str_3,v_Vals;
                   Exit When Cur_Sel%NotFound;
                   If v_Vals!=0 then 
                       My_Type.num_2:=v_Vals ;
                       IsFound:=1;
                       Exit; 
                   End if;
                   
                   Open cur for l_Sql ;
                   
                   Loop
                       Fetch cur Into My_Type.NUM_2,My_Type.str_4;
                       Exit when cur%notfound;
                       If My_Type.STR_4=My_Type.STR_5 Then
                          IsFound:=1;
                          exit;
                       End if;                     
                   end Loop;
                   Close cur;                           
   
                End loop;
                Close Cur_Sel;
            End;
            If IsFound=0 Then My_Type.num_2:=0; end if;
            --PIPE ROW (My_Type);
        End loop;
    
        Close cur_TItem;   
    End;
 
  Return 1;
End CO_GET_FEE;


/
