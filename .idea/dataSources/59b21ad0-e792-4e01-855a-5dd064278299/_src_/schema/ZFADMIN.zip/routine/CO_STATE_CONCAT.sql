CREATE function co_state_concat(objid in number,mscope in varchar2) return varchar2 is
  Result varchar2(4000);
begin
  select to_char(wm_concat(a.var)) into Result
            from (select t.sid,
                         t.st_name var-- wm_concat(t.st_name) over(order by t.v_date) var
                    from to_state t
                   where t.f_date is null and modality=0 and t.stype like '%'||mscope||'%'
                     and t.sid = objid order by v_date) a;

  Return(Result);
Exception
  when others then
    return '';
end co_state_concat;


/
