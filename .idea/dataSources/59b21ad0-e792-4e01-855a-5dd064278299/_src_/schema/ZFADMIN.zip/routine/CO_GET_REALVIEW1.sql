CREATE function CO_GET_REALVIEW1(SD_ID in number,vm_Type number)
--RETURN co_table PIPELINED
return number
  /*输入参数说明：
  Real_ID：房屋对象IDs
  ST_View: 业务视角
           1=房屋状态
           2=测量
           3=期房市场管理
           4=登记
           5=二手市场
  /*返回信息
  Key：生命周期状态
  Str_1：生命周期状态
  Str_2：业务视角状态
  Str_3: 限制状态
 */
IS
  My_Type   co_basic;
  v_date    date;
  v_code    varchar2(12);
  v_name    varchar2(20);
  v_color   varchar2(10);
  v_Sep     varchar2(1);
  v_recs    number;
Begin
--一、初始化自定义类型
  My_Type:=co_basic(SD_ID,'#FFFFFF',null,null,null,null,null,' ',' ',' ',null,null,null,null);

--1、、取生命周期状态
  --Select max(Decode(stype,'44',MDList,null)) into My_Type.Str_5 From tu_state Where sid=SD_ID;

  If vm_Type=4 Then
     Select co_get_strlists('sid',SD_ID,'droits','to_state','modality=0 and stype=''44''') into My_Type.Str_5 From dual;
  End if;
  If vm_Type=3 Then
     Select co_get_strlists('sid',SD_ID,'droits','to_state','modality=0 and stype=''33''') into My_Type.Str_5 From dual;
  End if;
  
--  Select bstate,ST_BGCLR into My_Type.Key,My_Type.str_1 From sv_realobj,ts_state Where OSEQ=SD_ID and bstate=st_code;
--#FF00CC
--2、、取限制状态
  DECLARE CURSOR MyCur IS
 /*         Select v_date,ts_state.st_code,ts_state.st_name,ST_BGCLR From tu_state,ts_state
           Where tu_state.stype=ts_state.st_code
             and ts_state.st_type in (Decode(vm_Type,0,st_type,vm_Type),9) 
             and tu_state.sid=SD_ID
           Order by ts_state.st_order;
           */
           
          Select v_date,ts_state.st_code,ts_state.st_name,ts_realview.ST_BGCLR
            From ts_code,ts_realview,ts_state,tu_state 
           Where id=vtype and ts_realview.st_id=ts_state.st_id and st_code=stype 
             and cname in (Decode(vm_Type,0,cname,to_char(vm_Type)) ,'9')
             and tu_state.sid=SD_ID Order by ts_realview.st_order;
  Begin
     OPEN MyCur;
     Loop
         FETCH MyCur INTO v_date,v_code,v_name,v_color;
         EXIT WHEN MyCur%NOTFOUND;
         My_Type.date1:=v_date;
         My_Type.key:=v_color;
          
         If Substr(v_code,1,1)='9' Then
            My_Type.Str_4:=v_color;
            If vm_Type=9 Then 
               My_Type.key:=v_color; 
            End if;
         Else
            My_Type.key:=v_color; 
         End if;

         If Instr(My_Type.Str_2,v_code)=0 Then
            My_Type.Str_2:=v_code||v_Sep||My_Type.Str_2;
            My_Type.Str_3:=My_Type.Str_3||v_Sep||v_name;
--            If v_code='33' or v_code='44' Then
--               Select count(*) into v_recs From tu_state where sid=SD_ID and (stype='33' or stype='44');
--               If v_recs>0 then
--                  Select MDList into My_Type.Str_5 From tu_state where sid=SD_ID and (stype='33' or stype='44');
--               End if;
--           End if;
         End if;
         v_Sep:=',';
     END loop;
     Select count(*) into v_recs From tu_house Where sattribute=145001 and hid=SD_ID;
     If v_recs>0 Then
        My_Type.key:='#CBC8BF';
     End if;
     CLOSE MyCur;
  End;

--三、返回结果（）

  --PIPE ROW (My_Type);
  Return 0;

end co_get_Realview1;


/
