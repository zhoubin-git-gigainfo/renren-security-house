CREATE function co_cost_construction(v_sid in Number)
  Return number is
  v_jinduid varchar2(100);
  v_aid     varchar2(100);
  --v_jindu   varchar2(100);
  v_progress varchar2(100);
  v_tfloors  number;
  v_lnum     number;
begin
  select max(aid) into v_aid from tu_bldgschedule where sid = v_sid;

  select MILESTONEID, TFLOORS, LNUM
    into v_jinduid, v_tfloors, v_lnum
    from tu_bldgschedule
   where aid = v_aid;

  select memo into v_progress from ts_code where id = v_jinduid;

  if v_progress is not null then
    return v_progress;
  
  else
    if (v_jinduid = '117003' or v_jinduid = '118006' or v_jinduid = 118010) then
    
      return round(30 + (50 / v_tfloors) * v_lnum, 2);
    
    end if;
  end if;
  -- Return 0;

End co_cost_construction;
/
