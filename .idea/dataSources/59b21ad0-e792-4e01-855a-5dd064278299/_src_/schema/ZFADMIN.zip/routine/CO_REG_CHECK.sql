CREATE function CO_Reg_Check(App_Seq number) Return varchar2 is
   vm_Msg0  varchar2(2048); 
   vm_Msg1  varchar2(2048);
   vm_Msg2  varchar2(2048);
   vm_needs varchar2(512);
   vm_state varchar2(512);   
Begin
--1、检测业务必须具备的状态
    Declare Cursor MyCur Is
            Select Distinct Needs,(Select to_char(wm_concat(Stype)) From tu_state Where sid=hid) ||','||
                   (Select bstate From tu_bldg tt1,tu_house tt2 Where tt1.sid=tt2.sid and tt2.hid=t4.hid) States
              From tu_house t4,appdefine t3,sv_bu_sdlists t2,sv_bulists t1
             Where t3.bseq=t1.bseq and t2.appseq=t1.appseq
               and (t4.sid=t2.sd_id or t4.hid=t2.sd_id or t4.lid=t2.sd_id)
               and t1.appseq=App_Seq;
    Begin
       Open MyCur;
       Loop
          Fetch MyCur Into vm_needs,vm_state;
          Exit When MyCur%NotFound;
          Declare Cursor NotState Is 
                  Select Str_1 From table(co_split('12,34,35,36')) Where InStr(vm_state,Str_1)=0;
          Begin
              Open NotState;
                     Loop
                        Fetch NotState Into vm_state;
                        Exit When NotState%NotFound;
                        If InStr(vm_Msg2,vm_state)=0 Then
                           vm_Msg2:=vm_Msg2||','||vm_state;
                        End if;
                     End loop;
              Close NotState; 
          End;
       End loop;
       Close MyCur;
    End;
    --vm_Msg2:='33';
    Select to_char(wm_concat(st_name)) Into vm_Msg2 From ts_state Where InStr(vm_Msg2,st_code)>0;
    
    If not vm_Msg2 Is null Then
       vm_Msg0:='因缺少必要的【'||vm_Msg2||'】状态';
    End if;
    
--2、查找业务不允许的状态
    Select to_char(wm_concat(States)) Into vm_Msg1
      From (Select Distinct (Select st_name From tu_state Where InStr(unneeds,stype)>0 and sid=hid) States--,t3.bname
              From tu_house t4,appdefine t3,sv_bu_sdlists t2,sv_bulists t1
             Where exists (Select 1 From tu_state Where wfseq=App_Seq and instr(unneeds,stype)>0 and sid=hid union
                           Select 1 From tu_bldg tt1,tu_house tt2 Where tt1.sid=tt2.sid and InStr(unneeds,tt1.bstate)>0 and tt2.hid=t4.hid)
               and t3.bseq=t1.bseq and t2.appseq=t1.appseq
               and (t4.sid=t2.sd_id or t4.hid=t2.sd_id or t4.lid=t2.sd_id)
               and t1.appseq=App_Seq);
                
--3、组织返回信息
    If not vm_Msg1 Is null Then
       If vm_Msg0 Is Null Then vm_Msg0:='因'; Else vm_Msg0:=vm_Msg0||'、'; End if;
       vm_Msg0:=vm_Msg0||'存在排斥的【'||vm_Msg1||'】状态';
    End if;
    
    If vm_Msg0 Is Null Then Return '0'; End If;
    Return vm_Msg0||'，产生冲突！';
    
End CO_Reg_Check;
/
