CREATE function CO_Split(str_List clob) return
    co_table PIPELINED is
    My_Type     co_basic;
    l_pos       integer;
    l_list      clob:=str_List;
Begin
--1、初始化自定义类型
       
    My_Type:=co_basic(1,null,null,null,null,1,1,null,null,null,null,null,null,null);
    If instr(l_list,',')=0 Then 
       My_Type.Id:=0;
    End if;
    loop
         l_pos:=instr(l_list,',');
         If  l_pos>0 Then
             If co_IS_NUM(substr(l_list,1,l_pos-1))=1 Then
                My_Type.num_1:=to_number(substr(l_list,1,l_pos-1));
             End if;
             My_Type.str_1:=substr(l_list,1,l_pos-1);
             PIPE ROW (My_Type);
             l_list:=substr(l_list,l_pos+1);
             My_Type.num_5:=My_Type.num_5+1;
         Else
             If co_IS_NUM(l_list)=1 Then
                My_Type.NUM_1:=to_number(l_list);
             End if;
             My_Type.str_1:=l_list;
             PIPE ROW (My_Type);
             exit;
         End if;
    End loop
    return ;
end CO_Split;


/
