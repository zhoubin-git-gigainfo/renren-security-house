CREATE function CO_GET_STRLISTS(key_name in varchar2,
    oseq in number,
    col_name in varchar2,
    tab_name in varchar2,
    rel_str  in varchar2)
return varchar2
as
    type rc is ref cursor;
    str    varchar2(32767);
    sep    varchar2(2) ;
    val    varchar2(512);
    cur    rc;
    qur    varchar2(3000);
begin
    qur:='Select Distinct '||col_name||' Str from '|| tab_name || ' where ' || key_name || ' = :x ';
    If not rel_str is null then
       qur:=qur||' and '||rel_str;
    End if;
    --qur:=qur||' Order by '||col_name;
    --return qur;
    Open cur for qur using nvl(oseq,-1);
    loop
        fetch cur into val;
        exit when cur%notfound;
        str := str || sep || val;
        sep := ',';
    end loop;
    close cur;
    return ltrim(rtrim(str,','),',');
    Exception when others then return null;
end;


/
