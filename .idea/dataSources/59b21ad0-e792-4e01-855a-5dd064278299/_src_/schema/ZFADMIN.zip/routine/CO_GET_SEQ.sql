CREATE function co_get_seq(Object_Type in varchar2) return number is
  Result number;
  isexists number;
Begin

 /* If upper(Object_Type)='MDID' or upper(Object_Type)='COREATTECH'  Then

  Execute immediate 'Select CO_SEQ_'||Object_Type||'.nextval@ZZFCALL From dual' into Result;

  else
    
*/
 Execute immediate 'Select CO_SEQ_'||Object_Type||'.nextval From dual' into Result;

    If upper(Object_Type)='BUNO' or upper(Object_Type)='WFNO'  Then


       Result:=Result+to_number(to_char(sysdate,'yyyy'))*10000000;

       select count(*)  into isexists from sv_bulists where appseq=Result or sseq=Result;

       while isexists>0
        LOOP
           Execute immediate 'Select CO_SEQ_'||Object_Type||'.nextval From dual' into Result;
           Result:=Result+to_number(to_char(sysdate,'yyyy'))*10000000;
           select count(*)  into isexists from sv_bulists where appseq=Result or sseq=Result;
       end LOOP;

    End if;
    If upper(Object_Type)='RECEIVE_NO' or upper(Object_Type)='RECEIVE_NO_DEPT' Then
         Result:=Result+to_number(to_char(sysdate,'yyyy'))*10000;
    End If;
  /*end if;*/
  return(Result);
End co_get_seq;
/
