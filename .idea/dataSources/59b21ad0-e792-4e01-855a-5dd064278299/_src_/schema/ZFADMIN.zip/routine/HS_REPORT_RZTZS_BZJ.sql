CREATE function hs_report_rztzs_bzj(v_sseq number, v_sqbh number)
return varchar2
is
retStr varchar2(100) := '相应住房';--返回值
v_index number := 0;
v_hid  number;
v_bzj number;
begin
     if(null = v_sseq or null = v_sqbh) then
         return retStr;
     end if;

     select count(*) into v_index from hs_selehouse_bu
     where sseq=v_sseq and sqbh=v_sqbh
     and type=0  and state=1;

     if(0 = v_index) then
        return retStr;
     end if;

     v_index := 0;

     select count(*) into v_index from hs_family
     where f_date is null and sqbh=v_sqbh;

     if(0 = v_index) then
        return retStr;
     end if;



     select hid into v_hid from hs_selehouse_bu
     where sseq=v_sseq and sqbh=v_sqbh
     and type=0  and state=1;

     v_index := 0;
     select count(*) into v_index from
     to_state where modality=0 and f_date is null and stype='HSGZF'
     and sid=v_hid;

     if(1 = v_index) then
        select cfgvalue into v_bzj from sysconfig where cfgkey='HS_GZFBZJ';
        retStr := v_bzj || '元整公租住房';
     end if;

     v_index := 0;
     select count(*) into v_index from
     to_state where modality=0 and f_date is null and stype='HSJJSYF'
     and sid=v_hid;

     if(1 = v_index) then
        select cfgvalue into v_bzj from sysconfig where cfgkey='HS_GZFBZJ';
        retStr := v_bzj || '元整公租住房';
     end if;

      v_index := 0;
     select count(*) into v_index from
     to_state where modality=0 and f_date is null and stype='HSLZF'
     and sid=v_hid;

     if(1 = v_index) then
        select cfgvalue into v_bzj from sysconfig where cfgkey='HS_LZFBZJ';
        retStr := v_bzj || '元整廉租住房';
     end if;

      v_index := 0;
     select count(*) into v_index from
     to_state where modality=0 and f_date is null and stype='HSZGGF'
     and sid=v_hid;

     if(1 = v_index) then
        select cfgvalue into v_bzj from sysconfig where cfgkey='HS_ZGFBZJ';
        retStr := v_bzj || '元整直管公房';
     end if;

     return retStr;
end;
/
