CREATE function co_convert_specodeid(pid in number,ckey varchar2) return varchar2 is
  Result varchar2(40);
/*代码转换
  输入:
     cid—代码ID
     ckey—装换
  输出
     Result—代码说明
*/
begin

     Select id into Result
       From (Select id,cname From ts_code
            Start with parentid=pid connect by prior id=parentid)
      Where cname=ckey;

  Return(Result);
  --Exception when others then return '未指定';
end co_convert_specodeid;
/
