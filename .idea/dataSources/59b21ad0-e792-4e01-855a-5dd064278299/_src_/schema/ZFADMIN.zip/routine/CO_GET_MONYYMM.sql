CREATE function CO_get_monYYMM(v_year in varchar2)
--取得yymm
return varchar2 is
  Result varchar2(6);
 vm_year  varchar2(4);
 vm_month varchar2(2);
 vm_ryear number(1);
 vm_date date;
begin
select to_date(v_year,'yyyy-mm-dd') into vm_date from dual;
/*select mod(to_number(to_char(vm_date,'yyyy'))-2000,4),to_char(vm_date,'mm') into vm_ryear, vm_month from dual;
-- if  vm_month='02' then
-- if vm_ryear=0 then
-- select to_char(vm_date+4,'yyyymm') into Result from dual;
  else
  select to_char(vm_date+3,'yyyymm') into Result from dual;
  end if;
  end if;

  if vm_month='01' or vm_month='03' or vm_month='05' or vm_month='07' or vm_month='08' or vm_month='10' or vm_month='12' then
  select to_char(vm_date+6,'yyyymm') into Result from dual;
  end if;

   if vm_month='04' or vm_month='06' or vm_month='09' or vm_month='11' then
  select to_char(vm_date+5,'yyyymm') into Result from dual;
    end if;*/
    select to_char(vm_date,'yyyymm') into Result from dual;

  return(Result);
end CO_get_monYYMM;


/
