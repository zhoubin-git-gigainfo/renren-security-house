CREATE function CO_Dym_Data(RootNode in varchar2,l_Tables in varchar2,l_Lables in varchar2,l_Column in varchar2,l_Scope in varchar2)
return clob is
    Result clob;
    type rc is ref cursor;
    cur    rc;
    v_Quy  varchar2(32767);
    v_Pos1 Integer;
    v_Pos2 Integer;
    v_Sub1 Varchar(200);
    v_Sub2 Varchar(200);
    v_tmp1 Varchar(4000);
    v_tmp2 Varchar(4000);
begin
    If l_Lables is null or l_Column is null then
       return v_Quy;
    End if;
    v_tmp1:=l_Lables||'@';
    v_tmp2:=l_Column||'@';
    Loop
       v_Pos1:=Instr(v_tmp1,'@');
       v_Pos2:=Instr(v_tmp2,'@');
       v_Sub1:=Substr(v_tmp1,1,v_Pos1-1);
       v_Sub2:=Substr(v_tmp2,1,v_Pos2-1);
       If  v_Sub1 is null or v_Sub2 is null Then Exit; End if;
       v_tmp1:=substr(v_tmp1,v_Pos1+1);
       v_tmp2:=substr(v_tmp2,v_Pos2+1);
       v_Quy:=v_Quy||'''<'||v_Sub1||'>''||'||v_Sub2||'||''</'||v_Sub1||'>''||chr(13)||';
    End loop;
    v_Quy:=rtrim(v_Quy,'char(13)||');
    v_Quy:='Select '||v_Quy||' From '||l_Tables||' Where '||l_Scope;
--    return v_Quy;
    Open cur for v_Quy;
    loop
        fetch cur into v_Quy;
        exit when cur%notfound;
        Result := Result ||'<'||RootNode||'>'||chr(13)|| v_Quy || chr(13)||'</'||RootNode||'>'||chr(13);
    end loop;
    close cur;
    Result:=Result;
    return Result;
end;


/
