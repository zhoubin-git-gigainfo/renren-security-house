CREATE function CO_get_monsdate(v_sseq in varchar2)
--取得起租日期
return varchar2 is
  Result varchar2(10);

begin
select sdate into Result from (select to_char(sdate,'yyyy-mm-dd') sdate from u_tenancy where sseq=v_sseq order by vflag,sdate) where rownum=1;
  return(Result);
end CO_get_monsdate;


/
