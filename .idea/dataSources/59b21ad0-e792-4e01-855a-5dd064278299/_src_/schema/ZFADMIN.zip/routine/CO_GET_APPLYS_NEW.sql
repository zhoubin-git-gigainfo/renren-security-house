CREATE function CO_GET_APPLYs_NEW(Bu_No in number,Apply_Type varchar2) return
 --varchar2 is
    co_table PIPELINED is
    My_Type     co_basic;
    v_optMod       char(20);
    v_StCode    char(20);
    v_MDCount   Integer;
    v_MDList    varchar2(2000);
    MD_Type     dbms_sql.varchar2_table;
    v_adhere    char(20);
    type rc is ref cursor;
    cur_MdList    rc;
    l_Query       varchar2(6000);
    v_scops       varchar2(200);
    v_OldBuNo     number;
Begin
--1、初始化自定义类型

    My_Type:=co_basic(null,null,null,null,null,null,0,null,null,null,null,null,null,null);
    if Apply_Type is null then
       v_scops:='0,1,2,3,4,5';
    Else
       v_scops:=Apply_Type;
    end if;


 Select distinct c.md_list||',',optmod,b.state_id,c.adhere, a.osseq
    into v_MDList,v_optMod,v_StCode,v_adhere,v_OldBuNo
      From sv_bulists a,appdefine b,ts_state c
     Where a.sseq=Bu_No and a.bseq=b.bseq and
     b.state_id=c.st_code(+) ;


    If v_StCode='**' Then  --属于变更、换补证业务，基本业务类型及数据与原业务是一致的
       If nvl(v_OldBuNo,0)>0 Then
          Select max(stype) into v_StCode from to_state t1,taq_olist t2
           Where t1.bid=t2.osseq and t1.sid=t2.hid and t2.sseq=Bu_No;
      Else
          Select max(stype) into v_StCode from to_state where bid=v_OldBuNo;
       End if;
      --Select  md_list into v_MDList from ts_state where st_code='45';
      Select  md_list into v_MDList from ts_state where st_code in (
      Select max(stype)   from to_state t1,taq_olist t2
           Where t1.bid=t2.osseq and t1.sid=t2.hid and t2.sseq=Bu_No
      );
    End if;

    v_MDCount:=1;
    MD_Type(1):='代理人';MD_Type(2):=null;MD_Type(3):=null;MD_Type(4):=null;MD_Type(5):=null;
    While Instr(v_MDList,',')>0 Loop
         v_MDCount:=v_MDCount+1;
         MD_Type(v_MDCount):=Substr(v_MDList,1,Instr(v_MDList,',')-1) ;
         v_MDList:=Substr(v_MDList,Instr(v_MDList,',')+1);
    End Loop;

     --ID=业务号；Key=主体类别名称
     --Str_1=名称；Str_2=证号；Str_3=电话；Str_4=地址；Str_5=权利说明
     --Num_1=类别（0-代理人、1-A方、2-B方、3-C方、4-原业务权利人）；
     --Num_2=主体ID；Num_3=证件类别ID；

    If Instr(v_scops,'0')>0 Then --代理人
       l_Query:='select * from (Select '||Bu_no||' Bu_no,0,md_id,agentname md_name,IC_TypeID,IC_No creno,agenttelephone,agentaddress,agentwhoname ';
       l_Query:=l_Query||'From sv_bulists a,ta_agent b Where a.sseq=:x and a.appseq=b.sseq and Maintypeid=0 and a.sseq=b.bseq ';
       l_Query:=l_Query||' union  ' ;
       l_Query:=l_Query|| 'Select '||Bu_no||' Bu_no,0,md_id,agentname md_name,IC_TypeID,IC_No creno,agenttelephone,agentaddress,agentwhoname ';
       l_Query:=l_Query||'From sv_tarbulists a,sv_tarbody_bu b Where a.sseq='||Bu_No || ' and Maintypeid=-1 and b.sseq=a.sseq ) ';

       My_Type.num_5:=0;
       Open cur_MdList for l_Query using nvl(Bu_No,-1);
       loop
           Fetch cur_MdList into My_Type.id,My_Type.Num_1,My_Type.Num_2,My_Type.Str_1,My_Type.Num_3,My_Type.Str_2,My_Type.Str_3,My_Type.Str_4,My_Type.Str_5;
           exit when cur_MdList%notfound;
           My_Type.key:=MD_Type(My_Type.num_1+1);
           PIPE ROW (My_Type);
           --My_Type.num_5:=My_Type.num_5+1;
       end loop;
       close cur_MdList;
    End if;

    If Instr(v_scops,'1')>0 Then --权利申请人（A方）
      l_Query:=' Select '||Bu_no||' Bu_no,Maintypeid,md_id,agentname md_name,IC_TypeID,IC_No creno,agenttelephone,agentaddress,co_convert_code(dtype,null)||Decode(dtype,84002,gpart,null ) ';
    l_Query:=l_Query||'From taq_enrol a,ta_agent b Where a.sseq=b.sseq and Maintypeid between 1 and 4 and a.sseq=:x order by Maintypeid';

 --l_Query:=' Select '||Bu_no||' Bu_no,Maintypeid,md_id,agentname md_name,IC_TypeID,IC_No creno,agenttelephone,agentaddress,ano ';
    --    l_Query:=l_Query||'From taq_enrol a,ta_agent b Where a.sseq=b.sseq and Maintypeid between 1 and 4 and a.sseq=:x order by Maintypeid,ano';


     My_Type.num_5:=0;
       Open cur_MdList for l_Query using nvl(Bu_No,-1);
       loop
           Fetch cur_MdList into My_Type.id,My_Type.Num_1,My_Type.Num_2,My_Type.Str_1,My_Type.Num_3,My_Type.Str_2,My_Type.Str_3,My_Type.Str_4,My_Type.Str_5;
           exit when cur_MdList%notfound;
           My_Type.key:=MD_Type(My_Type.num_1+1);
           PIPE ROW (My_Type);
           --My_Type.num_5:=My_Type.num_5+1;
       end loop;
       close cur_MdList;
    End if;
 /*
    If Instr(v_scops,'3')>0 Then --债务人（C方）
       l_Query:='Select '||Bu_no||' Bu_no,3,md_id,agentname md_name,IC_TypeID,IC_No creno,agenttelephone,agentaddress,null ';
       l_Query:=l_Query||'From taq_enrol a,ta_agent b Where a.sseq=:x and a.sseq=b.sseq and Maintypeid=3';
       My_Type.num_5:=0;
       Open cur_MdList for l_Query using nvl(Bu_No,-1);
       loop
           Fetch cur_MdList into My_Type.id,My_Type.Num_1,My_Type.Num_2,My_Type.Str_1,My_Type.Num_3,My_Type.Str_2,My_Type.Str_3,My_Type.Str_4,My_Type.Str_5;
           exit when cur_MdList%notfound;
           My_Type.key:=MD_Type(My_Type.num_1+1);
           PIPE ROW (My_Type);
           My_Type.num_5:=My_Type.num_5+1;
       end loop;
       close cur_MdList;
    End if;

    If Instr(v_scops,'4')>0 Then --原业务权利人（他项权利人、预告&异议申请人、查封机构）
       l_Query:='Select a.osseq,4,md_id,agentname md_name,IC_TypeID,IC_No creno,agenttelephone,agentaddress,co_convert_code(dtype,null)||Decode(dtype,84002,gpart,null) ';
       l_Query:=l_Query||'From taq_enrol a,ta_agent b Where a.sseq=:x and a.osseq=b.sseq and Maintypeid=1';
       My_Type.num_5:=0;

       Open cur_MdList for l_Query using nvl(Bu_No,-1);
       loop
           Fetch cur_MdList into My_Type.id,My_Type.Num_1,My_Type.Num_2,My_Type.Str_1,My_Type.Num_3,My_Type.Str_2,My_Type.Str_3,My_Type.Str_4,My_Type.Str_5;
           exit when cur_MdList%notfound;
           My_Type.key:=MD_Type(My_Type.num_1+1);
           PIPE ROW (My_Type);
           My_Type.num_5:=My_Type.num_5+1;
       end loop;
       close cur_MdList;
    End if;

    Select t2.state_id into v_STDM From sv_bulists t1,appdefine t2
     where sseq=Bu_No and t1.bseq=t2.bseq ;

    If Instr(v_scops,'2')>0 and Instr('45,46,47',v_STDM)>0 Then --作为当前业务的业务承担方（抵押、地域、转移预告）
       l_Query:='Select distinct 0,2,t4.Md_id,t4.md_name,t4.ic_type,t4.ic_no,t4.md_tel,t4.md_addr,null ';
       l_Query:=l_Query||'From sv_bu_sdlists t1,to_relation t2,tu_state t3,tm_mainbody t4 ';
       l_Query:=l_Query||'Where t1.sseq=:x and t1.sd_id=t2.sid and t2.bid=t3.bid and stype='''||v_adhere||''' and mid=md_id';

       My_Type.num_5:=0;
       Open cur_MdList for l_Query using nvl(Bu_No,-1);
       loop
           Fetch cur_MdList into My_Type.id,My_Type.Num_1,My_Type.Num_2,My_Type.Str_1,My_Type.Num_3,My_Type.Str_2,My_Type.Str_3,My_Type.Str_4,My_Type.Str_5;
           exit when cur_MdList%notfound;
           My_Type.key:=MD_Type(My_Type.num_1+1);
           PIPE ROW (My_Type);
           My_Type.num_5:=My_Type.num_5+1;
       End Loop;
       close cur_MdList;
    End if;
 */
    return ;
end CO_GET_APPLYs_NEW;
/
