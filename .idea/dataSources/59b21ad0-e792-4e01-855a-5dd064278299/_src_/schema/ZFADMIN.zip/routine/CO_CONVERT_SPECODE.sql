CREATE function co_convert_specode(cid in number,pid in number,ckey varchar2) return varchar2 is
  Result varchar2(40);
/*代码转换
  输入:
     cid—代码ID
     ckey—装换
  输出
     Result—代码说明
*/
begin
  If ckey is null then --直接代码转换
     Select ts_code.name into Result from ts_code where id=cid and parentid=pid ;
  Else
     Select name into Result
       From (Select name,cname From ts_code
            Start with id=cid connect by prior id=parentid)
      Where cname=ckey;
  End if;
  Return(Result);
  --Exception when others then return '未指定';
end co_convert_specode;


/
