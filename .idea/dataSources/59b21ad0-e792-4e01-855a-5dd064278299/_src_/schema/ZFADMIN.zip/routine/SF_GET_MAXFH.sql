CREATE function SF_GET_MAXFH(intSeq in number)
return integer is
  Result integer;
  v_ename varchar2(60);
  n_value varchar2(60);
begin
  Result:='';
  DECLARE
     CURSOR c_emp IS
          Select name,sum(to_number(jzmj)) as totmj From ta_hxx,ts_code
                 Where ridgepoleno=zid
                   and cc=DECODE(CNO,'',CC,CNO)
                   and useid=id and sseq=intSeq
                 Group by name
                 Order by sum(to_number(jzmj)) desc ;
     BEGIN
        OPEN c_emp;
        LOOP
           FETCH c_emp INTO v_ename,n_value;
           EXIT WHEN c_emp%NOTFOUND;
           If length(Result)>0 then
              Result:=Result||'，';
           End if;
           If length(Result||v_ename)<=512 then
              Result:=Result||v_ename;
           End if;
        END loop;
        CLOSE c_emp;
     End;
  return(Result);
end SF_GET_MAXFH;


/
