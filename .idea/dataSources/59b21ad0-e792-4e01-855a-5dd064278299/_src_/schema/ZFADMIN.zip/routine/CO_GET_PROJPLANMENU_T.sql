CREATE function CO_GET_projplanmenu_t(App_bseq integer,SD_IDs in varchar2 ,objtype in integer)
 -- RETURN co_table PIPELINED is
  RETURN number is
  PRAGMA AUTONOMOUS_TRANSACTION;
  My_Type         co_basic;
  v_Recs          integer;
  Menu_Type       integer;
  v_bseq          number(12);
  v_bid           varchar2(20);
  v_bname         varchar2(60);
  v_needs         varchar2(200);
  v_unneeds       varchar2(200);
  v_group         varchar2(200);
  v_bath          integer;
  v_Single        integer default 0;
  v_More          integer default 0;
  v_unite         integer default 0;
  v_MenuID        integer default 10;
  v_prjCount       integer;
   v_sdCount       integer;
  v_houseCount       integer;
  v_gwfseq        number(12);
  v_stratobj         varchar2(30);

  v_WkNo            integer default 1;
  v_tempbscount   integer;

Begin
--1、初始化自定义类型
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    Select apptype,co_seq_work.nextval,adminform into Menu_Type,v_WkNo,v_stratobj
      From Appdefine Where bseq=app_bseq;

    --建立客体临时数据列表
    Insert into My_SDList(NO,sd_id) Select distinct v_WkNo,to_number(str_1) From table(co_get_split(SD_IDs));

--打印一下参数
dbms_output.put_line('参数objtype:'|| objtype || '   apptype:' || Menu_type);

    --如果客体有业务在办
     If objtype=5   then
        Rollback;
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:='单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        --PIPE ROW (My_Type);

        If Menu_Type=219 Then
            My_Type.id:=2;
            My_Type.key:='ZFBZ103';
            My_Type.str_1:='项目申报';
            My_Type.num_1:=1;
            My_Type.str_2:='130010152193';
            My_Type.str_3:='ZFBZ103';
            My_Type.num_2:=100001;
            --PIPE ROW (My_Type);
        End if;   
--        Return ;
        Return 0;
    End if;



    Select Count(*) into v_recs From to_state a,appdefine b,My_SDList c
     Where a.bseq=b.bseq and apptype=Menu_Type and modality=1 and a.sid=c.sd_id and c.no=v_WkNo ;

    If v_Recs>0 Then
       Rollback;
       --return ;
       return 0;
    End if;

    --计算客体数量->v_sdCount变量
    -----启动对象是项目库对象
    if objtype=6 then
    Select count(distinct t1.xmbh) into v_sdCount From hs_projlib t1,My_SDList t2
     Where (t1.xmbh=t2.SD_ID )
       and t2.no=v_WkNo;
       v_stratobj:='projlib';
       
   elsif  objtype=7 then
    Select count(distinct t1.sqbh) into v_sdCount From hs_projplan t1,My_SDList t2
     Where (t1.sqbh=t2.SD_ID )
       and t2.no=v_WkNo;
        v_stratobj:='projplan';

    end if;

    
    commit;

   if(v_sdCount=0)
     Then
       Rollback;
       --Return ;
       Return 0;
    end if;



    --计算所有状态和客体数my_stlist）
    Insert into my_stlist(NO,stcode,stcount) Select v_WkNo,stype,sum(1) totl
                            From (Select distinct t2.sid,t2.stype from  tu_state t2,My_SDList T3
                           Where   t2.sid=t3.sd_id   and no=v_WkNo)-- and nvl(t1.sattribute,0)!=145001)
                           Group by Stype;

    --生命周期状态
    Insert into my_stlist(NO,stcode,stcount) Select v_WkNo,t0.bstate,count(*) From tu_bldg t0 ,my_sdlist t2
                           Where  t0.sid=t2.sd_id   and no=v_WkNo
                           Group by bstate;

    --测量状态
    Insert into my_stlist(NO,stcode,stcount) Select v_WkNo,t0.sstate,count(*) From tu_bldg t0,my_sdlist t2
                           Where t0.sid=t2.sd_id   and no=v_WkNo
                           Group by sstate;
     


    Commit;
   dbms_output.put_line(App_bseq ||'：'||v_stratobj||'：'||v_WkNo);


    DECLARE CURSOR MyCur IS

           Select tt0.BSEQ,BID,tt0.BNAME,tt0.needs,tt0.unneeds,
           Replace(','||bugroup||',',' ','') bugroup,isbath,Gwfseq
              From Appdefine tt0,ts_state tt2
             Where tt2.st_code(+)= tt0.state_id and co_get_SDState_new(tt0.BSEQ,v_WkNo,v_sdCount)=1
               and tt0.BSEQ!=App_bseq and tt0.apptype=Menu_Type
                 and      instr( adminform,  v_stratobj)>0
             Order by tt2.st_order,decode(Optmod,'01',1,'10',9,2),bid;



    Begin
       OPEN MyCur;
       LOOP
           FETCH MyCur INTO v_bseq,v_bid,v_bname,v_needs,v_unneeds,v_group,v_bath,v_gwfseq;
           EXIT WHEN MyCur%NOTFOUND;

           v_Single:=10000;
           My_Type.id:=v_MenuID;
           My_Type.key:=v_bid;
           My_Type.str_1:=v_bname;
           My_Type.num_1:=1;
           My_Type.str_2:=to_char(v_bseq);
           My_Type.str_3:=v_bid;
           My_Type.num_2:=v_Single+v_MenuID;
           My_Type.num_5:=null;
           --PIPE ROW (My_Type);
           v_MenuID:=v_MenuID+1;

           if v_bath=1 Then
               v_More:=20000;
               My_Type.id:=v_MenuID;
               My_Type.key:=v_bid;
               My_Type.str_1:=v_bname;
               My_Type.num_1:=2;
               My_Type.str_2:=to_char(v_bseq);
               My_Type.str_3:=v_bid;
               My_Type.num_2:=v_More+v_MenuID;
               My_Type.num_5:=null;
               --PIPE ROW (My_Type);
               v_MenuID:=v_MenuID+1;
           End if;

           If  v_group!=',,' Then
               v_unite:=30000;
               My_Type.id:=v_MenuID;
               My_Type.key:=v_bid;
               My_Type.str_1:=v_bname;
               My_Type.num_1:=3;
               My_Type.num_5:=v_gwfseq;
               My_Type.str_2:=to_char(v_bseq);
               My_Type.str_3:=v_bid;
               My_Type.num_2:=v_unite+v_MenuID;
               --PIPE ROW (My_Type);
               v_MenuID:=v_MenuID+1;

               DECLARE CURSOR MyChildMenu IS
                       Select BID,My_Type.id,BNAME,My_Type.str_2||','||TO_CHAR(BSEQ),My_Type.str_3||','||BID
                        From Appdefine
                        Where instr(v_group,','||to_char(bseq)||',')>0
                        order by Decode(State_Id,'00','50',State_Id),decode(Optmod,'01',1,'10',9,2),bid;
               Begin
                   Open MyChildMenu;
                   LOOP
                       FETCH MyChildMenu INTO My_Type.KEY,My_Type.num_1,My_Type.str_1,My_Type.str_2,My_Type.str_3;
                       EXIT WHEN MyChildMenu%NOTFOUND;
                       My_Type.id:=v_MenuID;
                       My_Type.num_2:=v_unite+v_MenuID;
                       --PIPE ROW (My_Type);
                       v_MenuID:=v_MenuID+1;
                   End loop;
                   CLOSE MyChildMenu;
               End;
           End if;

       END loop;
       CLOSE MyCur;
    End;

    If v_Single=10000 Then
      My_type.id:=1;
      My_type.KEY:='1';
      My_type.str_1:='单笔业务';
      My_type.num_1:=-1;
      My_type.num_2:=10000;
      --PIPE ROW (My_Type);
  -- End if;
    elsif v_More=20000 Then
      My_type.id:=2;
      My_type.KEY:='2';
      My_type.str_1:='批量业务';
      My_type.num_1:=-1;
      My_type.num_2:=20000;
      --PIPE ROW (My_Type);
  -- End if;
    elsif v_unite=30000 Then
      My_type.id:=3;
      My_type.KEY:='3';
      My_type.str_1:='组合业务';
      My_type.num_1:=-1;
      My_type.num_2:=30000;
      --PIPE ROW (My_Type);
     else

      -- RAISE_APPLICATION_ERROR(-20999,'请选择正确的！');

       Select  count(*) into v_tempbscount
              From Appdefine tt0,ts_state tt2
             Where tt2.st_code(+)= tt0.state_id and co_get_SDState(tt0.BSEQ,v_WkNo,v_sdCount)=1
               and tt0.BSEQ!=App_bseq and tt0.apptype=Menu_Type
                -- and      instr( adminform,  v_stratobj)>0
             Order by tt2.st_order,decode(Optmod,'01',1,'10',9,2),bid;

      My_type.id:=3;
      My_type.KEY:='3';
      My_type.str_1:='不满足业务办理条件';

      if v_tempbscount>0 then


          My_type.str_1:='请选择正确的启动对象！';


      end if;
      My_type.num_1:=-1;
      My_type.num_2:=30000;
      --PIPE ROW (My_Type);
    End if;
    --Return ;
    Return 0;


end;
--end ;


/
