CREATE function SF_GETSCOPE(OrgID in integer,OrgType in integer,roleID in integer)
return varchar2 as

	  OrgSeq integer;
    OrgCat integer;
    OrgCode varchar2(512);
    OrgScop integer;
Begin
   If OrgType=0 Then Return '%'; End if;
-- rgSeq:=OrgID;--按起草部门
   OrgSeq:=roleID; --按提交人
   OrgScop:=OrgType; --98、所属部门

   Loop
      Select SysOrgan.Oparent,SysOrgan.OType,SysOrgan.OCODE||'%' into OrgSeq,OrgCat,OrgCode From SysOrgan Where Oseq=OrgSeq;
      If  OrgScop!=98 and OrgCat=OrgType Then Exit; End if;
      If  OrgScop=98 and OrgCat!=4 Then Exit; End if;
      OrgCode:='~';
      If OrgSeq=-1 Then Exit; End If;
   End Loop;
   Return OrgCode;
End ;


/
