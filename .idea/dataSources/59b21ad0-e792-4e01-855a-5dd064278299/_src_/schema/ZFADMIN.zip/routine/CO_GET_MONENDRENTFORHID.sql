CREATE function CO_get_monEndrentForHid(v_sseq in varchar2,v_hid in varchar2,v_yymm in varchar2)
--取得月初结余
return varchar2 is
  Result number(10,2);
 vm_sumys  number(10,2);
 vm_sumsh number(10,2);
 vm_sumjm number(10,2);
begin
 select nvl(sum(ffee),0) into vm_sumys from u_account where vflag=0 and yymm<=to_number(v_yymm) and (ftype=1 or ftype=4) and sseq=v_sseq;
 select nvl(sum(sfee),0) into vm_sumjm from u_account where vflag=0 and yymm<=to_number(v_yymm) and ftype=5 and sseq=v_sseq;
 select nvl(sum(sfee),0) into vm_sumsh from u_account where vflag=0 and yymm<=to_number(v_yymm) and (ftype=3 or ftype=6) and sseq=v_sseq;
 Result:=vm_sumsh+vm_sumjm-vm_sumys;
  return(Result);
end CO_get_monEndrentForHid;


/
