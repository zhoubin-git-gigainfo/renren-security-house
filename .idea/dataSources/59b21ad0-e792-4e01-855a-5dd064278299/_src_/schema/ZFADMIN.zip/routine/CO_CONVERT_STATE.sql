CREATE function co_convert_state(stcode in varchar2) return varchar2 is
  Result varchar2(40);
/*代码转换
  输入:
     cid—代码ID
     ckey—装换
  输出
     Result—代码说明
*/
begin

     Select t1.st_name into Result from ts_state t1 where st_code=stcode;

  Return(Result);
  Exception when others then return ' ';
end co_convert_state;
/
