CREATE function CO_GET_prjmenu(App_bseq integer,SD_IDs in varchar2 ,objtype in integer)
  RETURN co_table PIPELINED is
  --RETURN number is
  PRAGMA AUTONOMOUS_TRANSACTION;
  My_Type         co_basic;
  v_Recs          integer;
  Menu_Type       integer;
  v_bseq          number(12);
  v_bid           varchar2(20);
  v_bname         varchar2(60);
  v_needs         varchar2(200);
  v_unneeds       varchar2(200);
  v_group         varchar2(200);
  v_bath          integer;
  v_Single        integer default 0;
  v_More          integer default 0;
  v_unite         integer default 0;
  v_MenuID        integer default 10;
  v_prjCount       integer;
   v_sdCount       integer;
  v_houseCount       integer;
  v_gwfseq        number(12);
  v_stratobj         varchar2(30);

  --Type strArray  is table of varchar2(10);
  --Type numArray  Is table of number;
  --v_StCode        strArray:=strArray();
  --v_StTotl        numArray:=numArray();
  v_WkNo            integer default 1;
  v_tempbscount   integer;
    v_affair_config_count number;

Begin
--1、初始化自定义类型
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    Select apptype,co_seq_work.nextval,adminform into Menu_Type,v_WkNo,v_stratobj
      From Appdefine Where bseq=app_bseq;

    --execute immediate l_sql;
    --l_sql:='CREATE GLOBAL TEMPORARY table My_SDList (SD_ID number(12)) ON COMMIT DELETE ROWS';
    --l_sql:='CREATE GLOBAL TEMPORARY table My_STList (STCODE varchar2(10),STCount number(12)) ON COMMIT DELETE ROWS';
    --execute immediate l_sql;

    --建立客体临时数据列表

    Insert into My_SDList (No,Sd_Id)  Select distinct v_WkNo,to_number(str_1) From table(co_get_split(SD_IDs));

    --如果客体有业务在办
    
  

     If objtype=1  then
        Rollback;
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:='单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        PIPE ROW (My_Type);
        If Menu_Type=40 Then
            My_Type.id:=2;
            My_Type.key:='SCGL201';
            My_Type.str_1:='项目入网';
            My_Type.num_1:=1;
            My_Type.str_2:='100000003015';
            My_Type.str_3:='SCGL201';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
        End if;
        Return ;
    End if;

  If objtype=11   then
        Rollback;
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:='单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        PIPE ROW (My_Type);
        If Menu_Type=180 Then
            My_Type.id:=2;
            My_Type.key:='DBYW29';
            My_Type.str_1:='开发项目阶段性担保退费';
            My_Type.num_1:=1;
            My_Type.str_2:='100000206005';
            My_Type.str_3:='DBYW29';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
        End if;
        Return ;
    End if;  
     If objtype=14   then
        Rollback;
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:='单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        PIPE ROW (My_Type);
        If Menu_Type=182 Then
            My_Type.id:=2;
            My_Type.key:='DBYW35';
            My_Type.str_1:='逾期数据导入';
            My_Type.num_1:=1;
            My_Type.str_2:='100000202353';
            My_Type.str_3:='DBYW35';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
        End if;
        Return ;
    End if;
    
      If objtype=15   then
        Rollback;
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:='单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        PIPE ROW (My_Type);
        If Menu_Type=183 Then
            My_Type.id:=2;
            My_Type.key:='DBYW37';
            My_Type.str_1:='公积金保证金追加';
            My_Type.num_1:=1;
            My_Type.str_2:='100000202359';
            My_Type.str_3:='DBYW37';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
        End if;
        Return ;
    End if;
    
     
   
    If objtype=2 and App_bseq=130101522290 and '1000' =SD_IDs   then
        Rollback;
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:=v_bname;--'单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        PIPE ROW (My_Type);
        If Menu_Type=113 Then
            My_Type.id:=2;
            My_Type.key:='CGGL14';
            My_Type.str_1:='房屋竣工测量图上图';
            My_Type.num_1:=1;
            My_Type.str_2:='130101532289';
            My_Type.str_3:='CGGL14';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
        End if;
        Return ;
    End if;

    Select Count(*) into v_recs From to_state a,appdefine b,My_SDList c
     Where a.bseq=b.bseq and apptype=Menu_Type and modality=1 and a.sid=c.sd_id and c.no=v_WkNo ;

---配置 在办状态检测开始 
v_affair_config_count:=0;
  select count(*) into v_affair_config_count from ta_affair_config where startbseq=app_bseq;
   if v_affair_config_count>0 then
   v_recs:=0;
  select count(*) into v_recs from to_state a,ta_affair_config b,my_sdlist c
   where b.startbseq=app_bseq and a.stype=b.checkstate and a.modality=1 and a.sid=c.sd_id and c.no=v_WkNo;
    end if;
    --结束


    If v_Recs>0 Then
       Rollback;
       return ;
    End if;

    --计算客体数量->v_sdCount变量
    -----启动对象是项目对象
    if objtype=2 then
    Select count(*) into v_sdCount From tu_proj t1,My_SDList t2
     Where (t1.pid=t2.SD_ID )
       --and nvl(t1.sattribute,0)!=145001
       and t2.no=v_WkNo;
       v_stratobj:='proj';


     -----启动对象是楼栋对象
   elsif  objtype=3 then
    Select count(*) into v_sdCount From tu_bldg t1,My_SDList t2
     Where (t1.sid=t2.SD_ID )
       --and nvl(t1.sattribute,0)!=145001
       and t2.no=v_WkNo;
        v_stratobj:='bldg';

    -----启动对象是户对象
   elsif  objtype=4 then
    Select count(*) into v_sdCount From tu_house t1,My_SDList t2
     Where (t1.sid=t2.SD_ID or t1.lid=t2.SD_ID or t1.hid=t2.SD_ID)
       --and nvl(t1.sattribute,0)!=145001
       and t2.no=v_WkNo;
         v_stratobj:='house';
         
          -----启动对象是协议
   elsif  objtype=16 then
    Select count(*) into v_sdCount From tat_agreement t1,My_SDList t2
     Where t1.id=t2.SD_ID
       and t2.no=v_WkNo;
         v_stratobj:='agreement';


    end if;





   -- If ( instr(v_stratobj,'bldg')>=0    and v_sdCount=0) or  ( instr(v_stratobj,'proj')>=0  and v_prjCount=0)
   --   or    (instr(v_stratobj,'house')>=0  and v_houseCount=0)
   if(v_sdCount=0)
     Then
       Rollback;
       Return ;
    end if;



    --计算所有状态和客体数my_stlist）
    Insert into my_stlist(no,stcode,stcount) Select v_WkNo,stype,sum(1) totl
                            From (Select distinct t2.sid,t2.stype from  tu_state t2,My_SDList T3
                           Where   t2.sid=t3.sd_id   and no=v_WkNo)-- and nvl(t1.sattribute,0)!=145001)
                           Group by Stype;

    --生命周期状态
    Insert into my_stlist(no,stcode,stcount) Select v_WkNo,t0.bstate,count(*) From tu_bldg t0 ,my_sdlist t2
                           Where  t0.sid=t2.sd_id   and no=v_WkNo
                           Group by bstate;

    --测量状态
    Insert into my_stlist(no,stcode,stcount) Select v_WkNo,t0.sstate,count(*) From tu_bldg t0,my_sdlist t2
                           Where t0.sid=t2.sd_id   and no=v_WkNo
                           Group by sstate;



    Commit;
   dbms_output.put_line(App_bseq ||'：'||v_stratobj||'：'||v_WkNo);


    DECLARE CURSOR MyCur IS
    /*        Select tt0.BSEQ,BID,tt0.BNAME,tt0.needs,tt0.unneeds,Replace(','||bugroup||',',' ',''),isbath,Gwfseq
              From Appdefine tt0,
                   (Select distinct bseq from sv_budefine t1,my_stlist t2
                     Where t2.stcode like nvl(t1.stcode,'%') and apptype=Menu_Type and type=0 and stcount>=1 and no=v_WkNo) tt1
             Where tt0.bseq=tt1.bseq and tt0.apptype=Menu_Type
             AND tt0.bseq<> App_bseq
               and tt0.bseq not in (Select distinct bseq From sv_budefine t1,my_stlist t2
                                     Where t2.stcode like t1.stcode and apptype=Menu_Type and type=1 and no=v_WkNo)
                   and      instr( adminform,  v_stratobj)>0

                                             Order by Decode(State_Id,'00','50',State_Id),decode(Optmod,'01',1,'10',9,2),bid


                                     ;*/
           Select tt0.BSEQ,BID,tt0.BNAME,tt0.needs,tt0.unneeds,
           Replace(','||bugroup||',',' ','') bugroup,isbath,Gwfseq
              From Appdefine tt0,ts_state tt2
             Where tt2.st_code(+)= tt0.state_id  and co_get_SDState(tt0.BSEQ,v_WkNo,v_sdCount)=1
               and tt0.BSEQ!=App_bseq and tt0.apptype=Menu_Type
                 and      instr( adminform,  v_stratobj)>0
                 and not exists(
               select  1 from sysfunction t4 where  tt0.bid=t4.fparam
               )
                 
             Order by tt2.st_order,decode(Optmod,'01',1,'10',9,2),bid;



    Begin
       OPEN MyCur;
       LOOP
           FETCH MyCur INTO v_bseq,v_bid,v_bname,v_needs,v_unneeds,v_group,v_bath,v_gwfseq;
           EXIT WHEN MyCur%NOTFOUND;

           v_Single:=10000;
           My_Type.id:=v_MenuID;
           My_Type.key:=v_bid;
           My_Type.str_1:=v_bname;
           My_Type.num_1:=1;
           My_Type.str_2:=to_char(v_bseq);
           My_Type.str_3:=v_bid;
           My_Type.num_2:=v_Single+v_MenuID;
           My_Type.num_5:=null;
           PIPE ROW (My_Type);
           v_MenuID:=v_MenuID+1;

           if v_bath=1 Then
               v_More:=20000;
               My_Type.id:=v_MenuID;
               My_Type.key:=v_bid;
               My_Type.str_1:=v_bname;
               My_Type.num_1:=2;
               My_Type.str_2:=to_char(v_bseq);
               My_Type.str_3:=v_bid;
               My_Type.num_2:=v_More+v_MenuID;
               My_Type.num_5:=null;
               PIPE ROW (My_Type);
               v_MenuID:=v_MenuID+1;
           End if;

           If  v_group!=',,' Then
               v_unite:=30000;
               My_Type.id:=v_MenuID;
               My_Type.key:=v_bid;
               My_Type.str_1:=v_bname;
               My_Type.num_1:=3;
               My_Type.num_5:=v_gwfseq;
               My_Type.str_2:=to_char(v_bseq);
               My_Type.str_3:=v_bid;
               My_Type.num_2:=v_unite+v_MenuID;
               PIPE ROW (My_Type);
               v_MenuID:=v_MenuID+1;

               DECLARE CURSOR MyChildMenu IS
                       Select BID,My_Type.id,BNAME,My_Type.str_2||','||TO_CHAR(BSEQ),My_Type.str_3||','||BID
                        From Appdefine
                        Where instr(v_group,','||to_char(bseq)||',')>0
                        order by Decode(State_Id,'00','50',State_Id),decode(Optmod,'01',1,'10',9,2),bid;
               Begin
                   Open MyChildMenu;
                   LOOP
                       FETCH MyChildMenu INTO My_Type.KEY,My_Type.num_1,My_Type.str_1,My_Type.str_2,My_Type.str_3;
                       EXIT WHEN MyChildMenu%NOTFOUND;
                       My_Type.id:=v_MenuID;
                       My_Type.num_2:=v_unite+v_MenuID;
                       PIPE ROW (My_Type);
                       v_MenuID:=v_MenuID+1;
                   End loop;
                   CLOSE MyChildMenu;
               End;
           End if;

       END loop;
       CLOSE MyCur;
    End;

    If v_Single=10000 Then
      My_type.id:=1;
      My_type.KEY:='1';
      My_type.str_1:='单笔业务';
      My_type.num_1:=-1;
      My_type.num_2:=10000;
      PIPE ROW (My_Type);
  End if;
   if v_More=20000 Then
      My_type.id:=2;
      My_type.KEY:='2';
      My_type.str_1:='批量业务';
      My_type.num_1:=-1;
      My_type.num_2:=20000;
      PIPE ROW (My_Type);
   End if;
    if v_unite=30000 Then
      My_type.id:=3;
      My_type.KEY:='3';
      My_type.str_1:='组合业务';
      My_type.num_1:=-1;
      My_type.num_2:=30000;
      PIPE ROW (My_Type);
     end if;

      -- RAISE_APPLICATION_ERROR(-20999,'请选择正确的！');
      if v_Single!=10000 and v_More!=20000 and v_unite!=30000 then
        
       Select  count(*) into v_tempbscount
              From Appdefine tt0,ts_state tt2
             Where tt2.st_code(+)= tt0.state_id and co_get_SDState_new(tt0.BSEQ,v_WkNo,v_sdCount)=1
               and tt0.BSEQ!=App_bseq and tt0.apptype=Menu_Type
                -- and      instr( adminform,  v_stratobj)>0
             Order by tt2.st_order,decode(Optmod,'01',1,'10',9,2),bid;

      My_type.id:=3;
      My_type.KEY:='3';
      My_type.str_1:='不满足业务办理条件';

      if v_tempbscount>0 then
          My_type.str_1:='请选择正确的启动对象！';
          
      end if;
      My_type.num_1:=-1;
      My_type.num_2:=30000;
      PIPE ROW (My_Type);
    End if;
    Return ;


end;
--end ;


/
