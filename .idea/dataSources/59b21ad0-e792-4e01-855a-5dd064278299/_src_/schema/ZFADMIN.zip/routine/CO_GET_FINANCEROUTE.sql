CREATE function co_get_financeRoute(WFNO in number,tag number) Return integer is
  v_resu integer;
  v_apply_num number(15,2);
  v_item_id varchar2(100);
  v_useq number;
  v_deptid number;
  v_ifinance number;
begin
    select apply_num,item_id,useq  into v_apply_num,v_item_id,v_useq from tf_apply_bu a,ta_bscommon b where a.sseq=b.sseq and b.appseq=WFNO;
    select co_get_getDept(v_useq) into v_deptid from dual;
    select ifinance into v_ifinance from sysorgan where oseq=v_deptid;
    --是独立财务
    IF (v_ifinance=1) then
    --招待费
    IF (v_item_id='5040104') then
    begin
      --部门领导提交
       If (tag=1) then
         IF (v_apply_num<1000) then
             v_resu:=1;
         End IF;
         IF ((v_apply_num>=1000) and (v_apply_num<2000))  then
             v_resu:=2;
         End IF;
         IF (v_apply_num>=2000) then
             v_resu:=3;
         End IF;
       End If;
       --分管领导提交
       If (tag=2) then
         IF ((v_apply_num>=1000) and (v_apply_num<2000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管局长提交
       If (tag=3) then
         IF ((v_apply_num>=2000) and (v_apply_num<3000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
      end;
      else
      --非招待费
      begin
      --部门领导提交
       If (tag=1) then
         IF (v_apply_num<1000) then
             v_resu:=1;
         End IF;
         IF ((v_apply_num>=1000) and (v_apply_num<2000))  then
             v_resu:=2;
         End IF;
         IF (v_apply_num>=2000) then
             v_resu:=3;
         End IF;
       End If;
       --分管领导提交
       If (tag=2) then
         IF ((v_apply_num>=1000) and (v_apply_num<2000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管局长提交
       If (tag=3) then
         IF ((v_apply_num>=2000) and (v_apply_num<5000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
      end;
    End IF;
   End IF;



    --非独立财务
    IF (v_ifinance=0) then
    --招待费
    IF (v_item_id='5040104') then
    begin
      --部门领导提交
       If (tag=1) then
         IF (v_apply_num<1000) then
             v_resu:=1;
         End IF;
         IF ((v_apply_num>=1000) and (v_apply_num<2000))  then
             v_resu:=2;
         End IF;
         IF (v_apply_num>=2000) then
             v_resu:=3;
         End IF;
       End If;
       --分管领导提交
       --分管领导提交
       If (tag=2) then
         IF (v_apply_num<2000)  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管局长提交
       If (tag=3) then
         IF ((v_apply_num>=2000) and (v_apply_num<3000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
      end;
      else
      --非招待费
      begin
      --部门领导提交
       If (tag=1) then
         IF (v_apply_num<1000) then
             v_resu:=1;
         End IF;
         IF ((v_apply_num>=1000) and (v_apply_num<2000))  then
             v_resu:=2;
         End IF;
         IF (v_apply_num>=2000) then
             v_resu:=3;
         End IF;
       End If;
       --分管领导提交
       If (tag=2) then
         IF (v_apply_num<2000)  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管局长提交
       If (tag=3) then
         IF ((v_apply_num>=2000) and (v_apply_num<5000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
      end;
    End IF;
   End IF;
   --局财务提交
/*      If (tag=4) then
         IF (v_apply_num<1000) then
             v_resu:=1;
         else
             v_resu:=0;
         end if;
      End if;*/

    return v_resu;
end co_get_financeRoute;


/
