CREATE function   DX_MONEY( MONEY    number)   return   varchar2   as

      V_MONEY VARCHAR2(150);
      RV_MONEY0 VARCHAR2(20);
      RV_MONEY1 VARCHAR2(4);RV_MONEY2 VARCHAR2(4);V_MONEY0 VARCHAR2(20);
V_MONEY1 VARCHAR2(4);
V_MONEY2 VARCHAR2(4);
V_MONEY3 VARCHAR2(4);
V_MONEY4 VARCHAR2(4);
V_MONEY5 VARCHAR2(4);
V_MONEY6 VARCHAR2(4);
V_MONEY7 VARCHAR2(4);
V_MONEY8 VARCHAR2(4);
V_MONEY9 VARCHAR2(4);
V_MONEY10 VARCHAR2(4);
V_MONEY11 VARCHAR2(4);
V_MONEY12 VARCHAR2(4);
RPV_MONEY1 VARCHAR2(4);
RPV_MONEY2 VARCHAR2(4);
PV_MONEY0 VARCHAR2(14);
PV_MONEY1 VARCHAR2(4);
PV_MONEY2 VARCHAR2(4);
PV_MONEY3 VARCHAR2(4);
PV_MONEY4 VARCHAR2(4);
PV_MONEY5 VARCHAR2(4);
PV_MONEY6 VARCHAR2(4);
PV_MONEY7 VARCHAR2(4);
PV_MONEY8 VARCHAR2(4);
PV_MONEY9 VARCHAR2(4);
PV_MONEY10 VARCHAR2(4);
PV_MONEY11 VARCHAR2(4);
PV_MONEY12 VARCHAR2(4);
begin
V_MONEY0:=LTRIM(RTRIM(TO_CHAR(FLOOR(MONEY))));
RV_MONEY0:=LTRIM(RTRIM(TO_CHAR(FLOOR(MONEY*100))));
RV_MONEY1:=SUBSTR(RV_MONEY0,LENGTH(RV_MONEY0),1);
IF LENGTH(RV_MONEY0)>1 THEN
RV_MONEY2:=SUBSTR(RV_MONEY0,LENGTH(RV_MONEY0)-1,1);
ELSE
RV_MONEY2:='0';
END IF;
V_MONEY1:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0),1);
IF LENGTH(V_MONEY0)-1>0 THEN
V_MONEY2:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-1,1);
ELSE V_MONEY2:=0;
END IF;
IF LENGTH(V_MONEY0)-2>0 THEN
V_MONEY3:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-2,1);
ELSE V_MONEY3:=0;
END IF;
IF LENGTH(V_MONEY0)-3>0 THEN
V_MONEY4:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-3,1);
ELSE V_MONEY4:=0;
END IF;
IF LENGTH(V_MONEY0)-4>0 THEN
V_MONEY5:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-4,1);
ELSE V_MONEY5:=0;
END IF;
IF LENGTH(V_MONEY0)-5>0 THEN
V_MONEY6:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-5,1);
ELSE V_MONEY6:=0;
END IF;
IF LENGTH(V_MONEY0)-6>0 THEN
V_MONEY7:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-6,1);
ELSE V_MONEY7:=0;
END IF;
IF LENGTH(V_MONEY0)-7>0 THEN
V_MONEY8:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-7,1);
ELSE V_MONEY8:=0;
END IF;
IF LENGTH(V_MONEY0)-8>0 THEN
V_MONEY9:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-8,1);
ELSE V_MONEY9:=0;
END IF;
IF LENGTH(V_MONEY0)-9>0 THEN
V_MONEY10:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-9,1);
ELSE V_MONEY10:=0;
END IF;
IF LENGTH(V_MONEY0)-10>0 THEN
V_MONEY11:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-10,1);
ELSE V_MONEY11:=0;
END IF;
IF LENGTH(V_MONEY0)-11>0 THEN
V_MONEY12:=SUBSTR(V_MONEY0,LENGTH(V_MONEY0)-11,1);
ELSE V_MONEY12:=0;
END IF;

select DECODE(RV_MONEY1,'0','','1','壹分','2','贰分','3','参分','4','肆分','5','伍分',
'6','陆分','7','柒分','8','扒分','9','玖分') into rpv_money1 from dual;
select DECODE(RV_MONEY2,'0','','1','壹角','2','贰角','3','参角','4','肆角','5','伍角',
'6','陆角','7','柒角','8','扒角','9','玖角') into rpv_money2 from dual;
select DECODE(V_MONEY1,'0','元整','1','壹元','2','贰元','3','参元','4','肆元','5','伍元',
'6','陆元','7','柒元','8','扒元','9','玖元') into pv_money1 from dual;
select DECODE(V_MONEY2,'0','','1','壹拾','2','贰拾','3','参拾','4','肆拾','5','伍拾',
'6','陆拾','7','柒拾','8','扒拾','9','玖拾') into pv_money2 from dual;
select DECODE(V_MONEY3,'0','','1','壹佰','2','贰佰','3','参佰','4','肆佰','5','伍佰',
'6','陆佰','7','柒佰','8','扒佰','9','玖佰') into pv_money3 from dual;
select DECODE(V_MONEY4,'0','','1','壹仟','2','贰仟','3','参仟','4','肆仟','5','伍仟',
'6','陆仟','7','柒仟','8','扒仟','9','玖仟') into pv_money4 from dual;
select DECODE(V_MONEY5,'0','万','1','壹万','2','贰万','3','参万','4','肆万','5','伍万',
'6','陆万','7','柒万','8','扒万','9','玖万') into pv_money5 from dual;
select DECODE(V_MONEY6,'0','','1','壹拾','2','贰拾','3','参拾','4','肆拾','5','伍拾',
'6','陆拾','7','柒拾','8','扒拾','9','玖拾') into pv_money6 from dual;
select DECODE(V_MONEY7,'0','','1','壹佰','2','贰佰','3','参佰','4','肆佰','5','伍佰',
'6','陆佰','7','柒佰','8','扒佰','9','玖佰') into pv_money7 from dual;
select DECODE(V_MONEY8,'0','','1','壹仟','2','贰仟','3','参仟','4','肆仟','5','伍仟',
'6','陆仟','7','柒仟','8','扒仟','9','玖仟') into pv_money8 from dual;
select DECODE(V_MONEY9,'0','','1','壹亿','2','贰亿','3','参亿','4','肆亿','5','伍亿',
'6','陆亿','7','柒亿','8','扒亿','9','玖亿') into pv_money9 from dual;
select DECODE(V_MONEY10,'0','','1','壹拾','2','贰拾','3','参拾','4','肆拾','5','伍拾',
'6','陆拾','7','柒拾','8','扒拾','9','玖拾') into pv_money10 from dual;
select DECODE(V_MONEY11,'0','','1','壹佰','2','贰佰','3','参佰','4','肆佰','5','伍佰',
'6','陆佰','7','柒佰','8','扒佰','9','玖佰') into pv_money11 from dual;
select DECODE(V_MONEY12,'0','','1','壹仟','2','贰仟','3','参仟','4','肆仟','5','伍仟',
'6','陆仟','7','柒仟','8','扒仟','9','玖仟') into pv_money12 from dual;
V_MONEY:=PV_MONEY12||PV_MONEY11||PV_MONEY10||PV_MONEY9||PV_MONEY8||
PV_MONEY7||PV_MONEY6||PV_MONEY5||PV_MONEY4||PV_MONEY3||PV_MONEY2||PV_MONEY1||
RPV_MONEY2||RPV_MONEY1;

      return   V_MONEY;
  end   DX_MONEY;


/
