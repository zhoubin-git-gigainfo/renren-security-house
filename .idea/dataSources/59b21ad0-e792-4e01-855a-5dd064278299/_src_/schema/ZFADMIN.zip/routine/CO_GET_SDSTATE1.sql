CREATE function CO_GET_SDSTATE1(v_Reals in varchar2,IsNeeds in varchar2,UnNeeds in varchar2)
RETURN number

IS
  v_SDList  varchar2(32767);
  v_STList  varchar2(500);
  v_Recs1   integer default 1;
  v_Recs2   integer default 0;
  v_MaxDM   varchar2(100);
  v_MinDM   varchar2(100);
  v_spos     integer default 1;
  v_epos     integer default 0;
  v_spos1    integer default 1;
  v_epos1    integer default 0;

begin
   v_SDList:=v_Reals||',';
     
   If IsNeeds is null and UnNeeds is null then return 1; end if;
   While v_Recs1>0 and v_Recs2=0 loop
       v_epos:=instr(v_SDList,',',v_spos);
       v_MaxDM:=substr(v_SDList,v_spos,v_epos-v_spos);
       if v_MaxDM is null then exit;end if;
       v_spos:=v_epos+1;
       While v_Recs1>0 loop
           v_epos1:=instr(v_STList,',',v_spos1);
           v_MinDM:=substr(v_STList,v_spos1,v_epos1-v_spos1);
           if v_MinDM is null then exit;end if;
           v_spos1:=v_epos1+1;
           Select count(*) into v_recs1 from tu_state where sid=to_number(v_MaxDM)
              and stype=v_MinDM;
       End loop;
       v_spos1:=1;   v_epos1:=0;
       While v_Recs1>0 and v_Recs2=0 loop
           v_epos1:=instr(UnNeeds||',',',',v_spos1);
           v_MinDM:=substr(UnNeeds||',',v_spos1,v_epos1-v_spos1);
           if v_MinDM is null then exit;end if;
           v_spos1:=v_epos1+1;
           Select count(*) into v_recs2 from tu_state where sid=to_number(v_MaxDM)
              and stype=v_MinDM;       
       End loop;

   End loop;
   If v_Recs1>0 and v_Recs2=0 then 
      Return 1;
   else
      Return 0;
   End if;
End co_get_SDState1;


/
