CREATE function co_get_catlog(v_BuNo in number, v_StCode in varchar2) return varchar2 is
  Result varchar2(10);
  v_busseq varchar2(12);
begin
  v_busseq:=','||to_char(v_BuNo)||',';
  Select min(bm) into result From ts_catlog 
   Where (Instr(','||bulist||',',v_busseq)>0 or bulist='**')
     and (Instr(','||stlist||',',v_StCode)>0 or stlist='**');
  return(Result);
end co_get_catlog;


/
