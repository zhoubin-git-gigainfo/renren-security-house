CREATE FUNCTION num_to_bin (p_num NUMBER) RETURN VARCHAR2
 IS
    r_binstr   VARCHAR2 (32767);
   l_num      NUMBER           := p_num;
 BEGIN
   WHILE l_num != 0 LOOP
       r_binstr := TO_CHAR (MOD (l_num, 2)) || r_binstr;
      l_num := TRUNC (l_num / 2);
   END LOOP;

    RETURN r_binstr;
 END num_to_bin;
/
