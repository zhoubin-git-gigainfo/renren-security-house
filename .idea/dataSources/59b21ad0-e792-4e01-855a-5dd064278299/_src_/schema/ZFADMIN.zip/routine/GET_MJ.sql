CREATE function get_mj(v_useq number) return varchar2 is
  Result varchar2(200);
begin
  
Select to_char(wm_concat(secretlevel_name)) into Result From (
Select distinct secretlevel_name From APP_SECRETDOMAIN s3,app_usersecret s2,
(Select oseq From sv_organ s1 Start with s1.oseq=v_useq Connect by s1.oseq= prior s1.oparent) ss1
where s3.useq=domainnameid and s2.user_orgid= ss1.oseq);

  return(Result);
end get_mj;


/
