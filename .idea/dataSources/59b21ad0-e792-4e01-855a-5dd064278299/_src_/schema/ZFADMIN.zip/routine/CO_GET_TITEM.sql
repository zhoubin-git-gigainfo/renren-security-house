CREATE function co_get_Titem(BuNo in number) return
    --number is
    co_table PIPELINED is
    v_BSEQ       number;
    v_BuType     number;
    My_Type      co_basic;
    v_TName      varchar2(60);
    v_TID        number;
    l_prm        varchar2(6000);
    l_val        varchar2(6000);
    IsLeaf       integer;
    IsFound      integer;
    
    v_toal       number(10,2);
    l_sql        varchar2(32767);
begin
--初始化
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    
--取当前业务的业务号、业务类型
    Select a.bseq,b.apptype into v_BSEQ,v_BuType from sv_bulists a,appdefine b 
     Where a.sseq=BuNo and a.bseq=b.bseq;
     
--1、取业务计费参数（计费基数、单价的参数序列）
--1.1、测量
    If v_BuType=2 or v_BuType=5 Then   --测量收费
   
        If v_BSEQ=1806000 Then
           Select sum(barea) into v_Toal From tac_sdlist Where sseq=BuNo;
        Else
           l_sql:='Select to_number(ta_zxx.zjzmj),Decode(count(distinct ta_hxx.useid),1,0,1),Decode(Instr(co_get_codepath(min(ta_hxx.useid)),''/110''),0,0,1) From ta_hxx,ta_zxx where ta_zxx.sseq=ta_hxx.sseq and ta_zxx.sseq=:BuNo Group by to_number(ta_zxx.zjzmj)';
        End if;
    End if;

--循环层次1——取当前业务的收费项目
    Declare CURSOR cur_TItem IS
            Select b.cid,b.name From ts_tariff a,ts_titem b 
             Where a.bseq=v_BSEQ and a.iid=b.cid ;
    Begin
        Open cur_TItem;
        Loop
            Fetch cur_TItem Into v_TID,v_TName;
            Exit When cur_TItem%NotFound;
            IsFound:=0;
            Declare CURSOR sel_TItem IS
                Select connect_by_root ver_id,icode,ltrim(sys_connect_by_path(ver_name,'/'),'/'),udesc,
                       ver_val,0,bas_val,mod_tax,mod_tax,PARM_DML,vale_dml,connect_by_isleaf,sys_connect_by_path(parm_val,'/')
                  From ts_price start with ver_id=v_TID
                  Connect by nocycle prior ver_id = parentid;
            Begin
                 Open sel_TItem;
                 Loop
                 Fetch sel_TItem Into My_Type.id,My_Type.key,My_Type.str_1,My_Type.str_2,
                                      My_Type.num_1,My_Type.num_2,My_Type.num_3,My_Type.num_4,My_Type.num_5,
                                      l_prm,l_val,IsLeaf,My_Type.str_5;
                 Exit When sel_TItem%NotFound;
                 If IsLeaf=1 Then 
                    Execute immediate l_prm into My_Type.str_4 using BuNo;
                    If My_Type.str_4=My_Type.str_5 Then
                       IsFound:=1;
                       Execute immediate l_val into My_Type.num_2 using BuNo; 
                       PIPE ROW (My_Type);
                       Exit;
                    End if;
                 End if;
                 End loop;
                 Close sel_TItem;
                 --If IsFound=0 Then
                    --PIPE ROW (My_Type);
                 --End if;
            End;
        End Loop;
        Close cur_TItem;
    End;  
   

    return ;
end co_get_Titem;


/
