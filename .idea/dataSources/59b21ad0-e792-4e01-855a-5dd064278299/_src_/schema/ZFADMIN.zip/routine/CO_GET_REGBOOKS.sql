CREATE function CO_GET_RegBooks(v_SDId in number) return
/*
  输入参数
  v_SDId：客体Id
  v_ViewType：查询人（1=权利人，2=利害关系人，3=其他个人和组织）
  v_ViewScop：打印范围（1=当前有效，2=全部）
*/
 --varchar2 is
    co_table PIPELINED is
    My_Type     co_basic;


Begin
--1、初始化自定义类型

    My_Type:=co_basic(v_SDId,null,null,null,null,null,0,null,null,null,null,null,null,null);

  DECLARE CURSOR my_Quy IS
          Select 0,sd_id,'12' as stype,bu_name,decode(f_date,null,0,9) as modality,v_date,f_date From tu_regdata Where sd_id=v_SDId union
          Select 0,bid,stype,bu_name,modality,v_date,f_date From tu_applists,to_state Where bu_sseq=bid and stype>'40' and sid=v_SDId; --200000918996
  BEGIN
    OPEN my_Quy;
    LOOP
       My_Type:=co_basic(v_SDId,null,null,null,null,null,0,null,null,null,null,null,null,null);
       FETCH my_Quy INTO My_Type.key,My_Type.NUM_1,My_Type.STR_1,My_Type.STR_2,My_Type.NUM_2,My_Type.DATE1,My_Type.DATE2;
       EXIT WHEN my_Quy%NOTFOUND;

       If My_Type.STR_1>'10' and My_Type.STR_1<'20' Then
          My_Type.STR_3:='基本状况';
          My_Type.key:=My_Type.key+100;
       End if;
       If My_Type.STR_1>'40' and My_Type.STR_1<'50' Then
          My_Type.STR_3:='权利状况';
          My_Type.key:=My_Type.key+400;
          If My_Type.STR_1='44' Then My_Type.STR_4:='所有权';My_Type.key:=My_Type.key+10; End if;          
          If My_Type.STR_1='41' or My_Type.STR_1='45' or My_Type.STR_1='46'  or My_Type.STR_1='4A' or My_Type.STR_1='49' Then 
             My_Type.STR_4:='抵押权';My_Type.key:=My_Type.key+20; 
          End if;          
          If My_Type.STR_1='47'  Then 
             My_Type.STR_4:='地役权';My_Type.key:=My_Type.key+30; 
          End if; 
          If My_Type.STR_1='42' or My_Type.STR_1='43' or My_Type.STR_1='48' or My_Type.STR_1='49' Then 
             My_Type.STR_4:='预告权';My_Type.key:=My_Type.key+40; 
          End if;          
       End if;
       If My_Type.STR_1>'92' or My_Type.STR_1<'99' or My_Type.STR_1>'97'Then
          My_Type.STR_3:='其他状况';
          Select max(st_name) into My_Type.STR_4 From ts_state Where st_code=My_Type.STR_1;
          My_Type.key:=My_Type.key+900;
       End if;

       PIPE ROW (My_Type);
    END loop;
    CLOSE my_Quy;
  End;

  Exception when others then return;

  return ;
end CO_GET_RegBooks;


/
