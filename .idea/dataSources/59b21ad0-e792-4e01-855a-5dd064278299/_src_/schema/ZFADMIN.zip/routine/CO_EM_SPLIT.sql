CREATE function CO_em_Split(str_List varchar2,v_id number) return
    co_table PIPELINED is
    My_Type     co_basic;
    l_pos       integer;
    l_list      varchar2(32767):=str_List;
Begin
--1、初始化自定义类型

    My_Type:=co_basic(v_id,null,null,null,null,null,0,null,null,null,null,null,null,null);
    loop
         l_pos:=instr(l_list,',');
         If  l_pos>0 Then
             --My_Type.num_1:=to_number(substr(l_list,1,l_pos-1));
             My_Type.str_1:=substr(l_list,1,l_pos-1);
             PIPE ROW (My_Type);
             l_list:=substr(l_list,l_pos+1);
         Else
             --My_Type.NUM_1:=to_number(l_list);
             My_Type.str_1:=l_list;
             PIPE ROW (My_Type);
             exit;
         End if;
    End loop
    return ;
end CO_em_Split;


/
