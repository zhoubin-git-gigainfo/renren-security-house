CREATE function CO_GET_total(key_name in varchar2,
    v_val in number,
    col_name in varchar2,
    tab_name in varchar2,
    rel_str  in varchar2)
    return number
as
    ret    number;
    qur    varchar2(600);
begin
    Select decode(rel_str,null,null,' and '||rel_str) into  qur From dual;
    qur:='Select sum('||col_name||') from '||tab_name||' where '||key_name||'='||to_char(v_val)||qur;
    Execute immediate qur into ret; 
    if ret=0 then return null; else return ret;end if;
    Exception when others then
    return null; 
end;


/
