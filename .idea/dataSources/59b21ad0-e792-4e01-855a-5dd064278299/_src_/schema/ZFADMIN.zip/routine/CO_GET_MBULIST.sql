CREATE function CO_GET_MBUlist(App_bseq number,mdids in varchar2,mo_type integer)
--RETURN number is

 RETURN co_table PIPELINED is
  --RETURN number is
   PRAGMA AUTONOMOUS_TRANSACTION;
  My_Type         co_basic;
  v_Recs          integer;
  Menu_Type       number;
  v_bseq          number;
  v_bid           varchar2(20);
  v_bname         varchar2(60);
  v_needs         varchar2(200);
  v_unneeds       varchar2(200);
  v_group         varchar2(200);
  v_bath          integer;
  v_Single        integer default 100000;
  v_More          integer default 0;
  v_MenuID        integer default 10;
  v_sdCount       integer;
  v_gwfseq        number;
  v_wfseqs number;
  --Type strArray  is table of varchar2(10);
  --Type numArray  Is table of number;
  --v_StCode        strArray:=strArray();
  --v_StTotl        numArray:=numArray();
  v_WkNo          integer default 1;
 v_affair_config_count number;

Begin
--1、初始化自定义类型
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);

    Select apptype,co_seq_work.nextval into Menu_Type,v_WkNo
      From Appdefine Where bseq=app_bseq;

   Insert into My_SDList (No,Sd_Id) Select distinct v_WkNo,to_number(str_1) From table(co_get_split(mdids));

    --如果客体有业务在办

    /* delete to_mbstate
     where md_id in (
      Select  a.md_id  From to_mbstate a,appdefine b,My_SDList c
     Where a.bseq=b.bseq and apptype=20 and modality=1 and a.md_id=c.sd_id and c.no=v_WkNo

     );*/
     
      If Menu_Type=40  or Menu_Type=570 or Menu_Type=573 or  Menu_Type=80 Then
        Rollback;
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:='单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        PIPE ROW (My_Type);
        If Menu_Type=40 Then
            My_Type.id:=2;
            My_Type.key:='SCGL201';
            My_Type.str_1:='项目入网';
            My_Type.num_1:=1;
            My_Type.str_2:='100000003015';
            My_Type.str_3:='SCGL201';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
        End if;
          If Menu_Type=80 Then
            My_Type.id:=2;
            My_Type.key:='WYGL27';
            My_Type.str_1:='物业项目数据补录新增';
            My_Type.num_1:=1;
            My_Type.str_2:='100000197256';
            My_Type.str_3:='WYGL27';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
        End if;
        
           If Menu_Type=570 and  mdids is null
           then
            My_Type.id:=8;
            My_Type.key:='BYFZ39';
            My_Type.str_1:='新建白蚁预防药物屏障业务(非栋户)';
            My_Type.num_1:=1;
            My_Type.str_2:='100010164028';
            My_Type.str_3:='BYFZ39';
            My_Type.num_2:=100006;
            PIPE ROW (My_Type);
            
            My_Type.id:=9;
            My_Type.key:='BYFZ40';
            My_Type.str_1:='新建白蚁预防IPM业务(非栋户)';
            My_Type.num_1:=1;
            My_Type.str_2:='100010164030';
            My_Type.str_3:='BYFZ40';
            My_Type.num_2:=100007;
            PIPE ROW (My_Type);
            
             My_Type.id:=10;
            My_Type.key:='BYFZ41';
            My_Type.str_1:='白蚁灾害灭治药物灭杀业务管理(非栋户)';
            My_Type.num_1:=1;
            My_Type.str_2:='100010164031';
            My_Type.str_3:='BYFZ41';
            My_Type.num_2:=100008;
            PIPE ROW (My_Type);
            
                My_Type.id:=11;
            My_Type.key:='BYFZ42';
            My_Type.str_1:='白蚁灾害灭治IPM灭杀业务管理(非栋户)';
            My_Type.num_1:=1;
            My_Type.str_2:='100010164032';
            My_Type.str_3:='BYFZ42';
            My_Type.num_2:=100009;
            PIPE ROW (My_Type);
            
         End If;   
         
         
          If Menu_Type=573 Then
            My_Type.id:=2;
            My_Type.key:='BYFZ09';
            My_Type.str_1:='买药入库';
            My_Type.num_1:=1;
            My_Type.str_2:='100000093796';
            My_Type.str_3:='BYFZ09';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
            

            My_Type.id:=3;
            My_Type.key:='BYFZ11';
            My_Type.str_1:='领用出库';
            My_Type.num_1:=1;
            My_Type.str_2:='100000093796';
            My_Type.str_3:='BYFZ11';
            My_Type.num_2:=100002;
            PIPE ROW (My_Type);
            
            My_Type.id:=4;
            My_Type.key:='BYFZ12';
            My_Type.str_1:='报损出库';
            My_Type.num_1:=1;
            My_Type.str_2:='100000093796';
            My_Type.str_3:='BYFZ12';
            My_Type.num_2:=100003;
            PIPE ROW (My_Type);
            
            My_Type.id:=5;
            My_Type.key:='BYFZ13';
            My_Type.str_1:='卖药出库';
            My_Type.num_1:=1;
            My_Type.str_2:='100000093796';
            My_Type.str_3:='BYFZ13';
            My_Type.num_2:=100004;
            PIPE ROW (My_Type);
        End if;
        Return ;
    End if;
    

      Select Count(*)  into v_recs From to_mbstate a,My_SDList c
     Where -- a.bseq=b.bseq and 
    -- apptype=20 
     modality=1 and a.md_id=c.sd_id and c.no=v_WkNo ;
   
---配置 在办状态检测开始 
v_affair_config_count:=0;
  select count(*) into v_affair_config_count from ta_affair_config where startbseq=app_bseq;
   if v_affair_config_count>0 then
   v_recs:=0;
  select count(*) into v_recs from to_mbstate a,ta_affair_config b,my_sdlist c
   where b.startbseq=app_bseq and a.stype=b.checkstate and a.modality=1 and a.md_id=c.sd_id and c.no=v_WkNo;
    end if;
    --结束

    If v_Recs>0 Then
       Rollback;
       return ;
    End if; 

    --计算客体数量->v_sdCount变量
    Select count(*) into v_sdCount From My_SDList Where no=v_WkNo;

    If v_sdCount=0 and (Menu_Type=2 or Menu_Type=5 or Menu_Type=12) then
        Rollback;
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:='单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        PIPE ROW (My_Type);

        Return ;
    End if;

    If v_sdCount=0 Then
       Rollback;
       Return ;
    end if;

    --计算所有状态和客体数my_stlist）
    Insert into my_stlist (no,stcode,stcount) Select v_WkNo,stype,count(*) totl
                            From (Select distinct md_id,stype from to_mbstate t1,My_SDList t2
                                   Where md_id=sd_id  and no=v_WkNo  and stype>'0'
                                    and t1.f_date is null

                                  -- and stype is not null
                                   )
                                   w
                           Group by Stype;
     Insert into my_stlist (no,stcode,stcount) Select v_WkNo,mo_type,count(*)
                            From My_SDList where mo_type <>0;



    Commit;

     DECLARE CURSOR MyCur IS
            Select tt0.BSEQ,BID,tt0.BNAME,tt0.needs,tt0.unneeds,
            Replace(','||bugroup||',',' ','') bugroup,isbath,Gwfseq,wfseqs
              From Appdefine tt0,ts_mbstate tt2
             Where tt0.state_id=tt2.st_code and CO_GET_SDSTATE_NEW(tt0.BSEQ,v_WkNo,v_sdCount)=1
               and tt0.BSEQ!=App_bseq and tt0.apptype=Menu_Type
               and nvl(tt2.st_mtype,mo_type)=mo_type
                and ( (decode(v_recs,0,1,2)=2  and tt0.state_id='**' ) or  decode(v_recs,0,1,2)=1)
             Order by tt2.st_order,decode(Optmod,'01',1,'10',9,2),bid; 
             
             

    Begin
       OPEN MyCur;
       LOOP
           FETCH MyCur INTO v_bseq,v_bid,v_bname,v_needs,v_unneeds,v_group,v_bath,v_gwfseq,v_wfseqs;
           EXIT WHEN MyCur%NOTFOUND;

           My_Type.id:=v_MenuID;
           My_Type.key:=v_bid;
           My_Type.str_1:=v_bname;
           My_Type.num_1:=1;
           My_Type.str_2:=to_char(v_bseq);
           My_Type.str_3:=v_bid;
           My_Type.num_2:=v_Single+v_MenuID;
           My_Type.num_3:=v_wfseqs;
           PIPE ROW (My_Type);
           v_MenuID:=v_MenuID+1;

           if v_bath=1 Then
              v_More:=200000;
              My_Type.id:=v_MenuID;
              My_Type.key:=v_bid;
              My_Type.str_1:=v_bname;
              My_Type.num_1:=2;
              My_Type.str_2:=to_char(v_bseq);
              My_Type.str_3:=v_bid;
              My_Type.num_2:=v_More+v_MenuID;
              My_Type.num_5:=null;
              PIPE ROW (My_Type);
              v_MenuID:=v_MenuID+1;
          End if;

          If  v_group!=',,' Then
              Select co_get_sumstr(bseq),co_get_sumstr(bid),co_get_sumstr(bname)
                Into My_Type.str_2,My_Type.str_3,My_Type.str_1
                From appdefine Where instr(','||v_group||',',','||to_char(bseq)||',')>0;
              My_Type.id:=v_MenuID;
              My_Type.key:=v_bid;
              My_Type.str_1:=v_bname||'＋'||replace(My_Type.str_1,',','＋');
              My_Type.str_2:=to_char(v_bseq)||','||My_Type.str_2;
              My_Type.str_3:=v_bid||','||My_Type.str_3;
              My_Type.num_1:=1;
              My_Type.num_2:=v_Single+10000+v_MenuID;
              My_Type.num_5:=v_gwfseq;
              PIPE ROW (My_Type);
              v_MenuID:=v_MenuID+1;
              If v_bath=1 Then
                 My_Type.num_1:=2;
                 My_Type.num_2:=v_More+10000+v_MenuID;
                 PIPE ROW (My_Type);
                 v_MenuID:=v_MenuID+1;
              End if;
          End if;
       END loop;
       CLOSE MyCur;
    End;
    My_type.str_2:=null;
    My_type.str_3:=null;
    If v_Single=100000 Then
      My_type.id:=1;
      My_type.KEY:='1';
      My_type.str_1:='单笔业务';
      My_type.num_1:=-1;
      My_type.num_2:=100000;
      PIPE ROW (My_Type);
    End if;
    If v_More=200000 Then
      My_type.id:=2;
      My_type.KEY:='2';
      My_type.str_1:='批量业务';
      My_type.num_1:=-1;
      My_type.num_2:=200000;
      PIPE ROW (My_Type);
    End if;
    Return  ;
end ;


/
