CREATE function CO_GET_FHLEN(strclh in number)
return integer is
   Fhlen integer;
   strcc VARCHAR2(50);
   strfh VARCHAR2(50);
begin
  Fhlen:=0;
    DECLARE
     CURSOR cc_house IS
        select cc,max(fh) from ta_hxx where sseq=strclh group by cc;
     BEGIN
        OPEN cc_house;
        FETCH cc_house INTO strcc,strfh;
        Fhlen:=length(strfh)-length(to_char(to_number(strcc)));          
      CLOSE cc_house;
     END;
  return Fhlen;
end;


/
