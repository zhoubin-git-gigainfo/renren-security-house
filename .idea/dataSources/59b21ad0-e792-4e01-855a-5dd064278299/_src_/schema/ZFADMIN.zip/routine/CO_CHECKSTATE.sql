CREATE function CO_CHECKSTATE(BuSeq      in Number,
                                         v_WkNo     in number,
                                         v_SDCounts number) Return number is
  v_Counts     number;
  v_defneeds   varchar2(2048);
  v_needstates varchar2(100);
  v_states     varchar2(100);
  v_state      varchar2(100);
  
  v_tmpstate1 varchar2(100);
  v_tmpstate2 varchar2(100);
begin

  Select needs into v_defneeds From appdefine Where bseq = BuSeq;

  Select to_char(wm_concat(stcode)) into v_state From (select * 
  from  my_stlist Where no = v_WkNo order by stcode )  ;

  v_state := ',' || v_state || ',';

  Select to_char(wm_concat(column_value))
    into v_needstates
    From (Select column_value
            From table(co_split_new(v_defneeds, ','))
           Order by column_value);
  ----第一层循环
  Declare
    Cursor Cur_needs Is
      Select column_value From table(co_split_new(v_needstates, '||'));
  
  Begin
    Open Cur_needs;
    Loop
      Fetch Cur_needs
        into v_states;
      Exit when Cur_needs%notfound;
      If nvl(trim(v_states), ' ') != ' ' then
      
       -- insert into aaaa (a) values ('');
      
        Declare
          Cursor Cur_need2 Is
            Select column_value From table(co_split_new(v_states, '&&'));
        Begin
          Open Cur_need2;
        
          Loop
            Fetch Cur_need2
              into v_state;
          
           -- insert into aaaa (a) values ('');
           v_tmpstate1:=v_tmpstate1||v_state||',';
           
          End loop;
          Close Cur_need2;
          
          
             
        
          Exit when Cur_need2%notfound;
          
          if instr(  ','||v_tmpstate1,v_state)>0 then
            
          return 1;
             
           end if ;
        
        end;
      
      End if;
    
    End loop;
  
    Close Cur_needs;
  end;

  Return 0;

End CO_CHECKSTATE;


/
