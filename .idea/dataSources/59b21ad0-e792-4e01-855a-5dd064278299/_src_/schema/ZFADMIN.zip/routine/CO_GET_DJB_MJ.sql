CREATE function co_get_djb_mj(bu_no number)
  return varchar2 is
    v_barea float;
    v_onebarea float;
    vm_buno number;
    vm_recs number default 0;
    vm_clob clob;
    vm_zl   varchar2(4000) default '-';
    vm_lp1  number  ;
    vm_lp2  number  ;
    vm_val  varchar2(1000);
    vm_n    number default 1;
    vm_len  number;
begin

    dbms_lob.createtemporary(vm_clob, TRUE);
    select bu_info into vm_clob From tu_applists where bu_sseq=bu_no;

         vm_n:=1;
         v_barea:=0;
         loop
            vm_lp1:=Instr(vm_clob,'<建筑面积>',1,vm_n)+6;
            If vm_lp1=6 or vm_len=0 Then Exit; End if;
            vm_lp2:=Instr(vm_clob,'</建筑面积>',1,vm_n);
            v_onebarea:=to_number(substr(vm_clob,vm_lp1,vm_lp2-vm_lp1));
            vm_n:=vm_n+1;
            v_barea:=v_barea+v_onebarea;
/*            If Instr(vm_zl,vm_val)=0 Then
               vm_zl:=vm_zl||vm_val||',';
            End if;*/
         End loop;
    return(v_barea);

end co_get_djb_mj;


/
