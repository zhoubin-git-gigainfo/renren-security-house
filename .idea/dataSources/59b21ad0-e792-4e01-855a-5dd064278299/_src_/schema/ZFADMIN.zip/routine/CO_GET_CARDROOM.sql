CREATE function CO_GET_CardRoom(bu_no in number)
RETURN co_table PIPELINED IS
  My_Type   co_basic;
  v_Recs number;
  v_lsql varchar2(3000);
  type rc is ref cursor;
  cur    rc;
begin
--一、初始化
  My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);

  Select Count(*) into v_Recs From taq_sdlist where sseq=bu_no;
  If v_Recs>3 Then
     v_lsql:='Select to_char(max(totallayer)),sum(barea),sum(parea),null From taq_sdlist Where sseq=:x';
  Else
     v_lsql:='Select to_char(totallayer)||''/''||hdesc,barea,parea,husename From taq_sdlist where sseq=:x';
  End if;

  Open cur for v_lsql using bu_no;
  loop
      fetch cur into My_Type.str_1,My_Type.num_1,My_Type.num_2,My_Type.str_2;
      exit when cur%notfound;
      PIPE ROW (My_Type);
  end loop;
  close cur;

  Return ;

End CO_GET_CardRoom;


/
