CREATE function co_Get_RegNo(v_SdId in number) return number is
  Result number;
begin
  
  return(Result);
end co_Get_RegNo;


/
