CREATE function SF_GET_MaxLength(intSeq in number)
return integer is
  Result integer;
  maxFh number;
begin
  Result:=2;
  select max(countfh)  into maxFh  from (select cc,count(*) countfh from ta_hxx t where sseq=intSeq group by cc);
  if ((maxFh>0) and (maxFh<100)) then
      Result:=2;
  end if;
  if (maxFh>100) and (maxFh<1000) then
  Result:=3;
  end if;
  return(Result);
end SF_GET_MaxLength;


/
