CREATE function co_get_CardData(BU_NO number,Pix_Card varchar2) return varchar2 is
  Result clob;
  v_val  varchar2(6000);
  v_clob clob;
  v_Tag  varchar2(40);
  l_sql  varchar2(6000);
begin
  dbms_lob.createtemporary(Result, TRUE); 
  Declare CURSOR MyCur IS
          Select cfgvalue From sysconfig Where cfgkey like Pix_Card||'%' order by cfgkey;
  BEGIN
      OPEN MyCur;
      LOOP
          FETCH MyCur INTO v_val;
          EXIT WHEN MyCur%NOTFOUND;
          v_tag:=Substr(v_val,1,Instr(v_val,'=')-1);
          l_sql:=Substr(v_val,Instr(v_val,'=')+1);
          l_sql:=replace(l_sql,'#BU_NO#',to_char(BU_NO));
          v_clob:=(co_get_xml(l_sql,v_Tag||'列表',v_tag));
          v_clob:=replace(v_clob,'<?xml version = ''1.0''?>','');
          dbms_lob.append(Result,v_clob); 
      End loop;
  End;
  Result:='<?xml version="1.0" encoding="UTF-8"?>'||chr(13)||'<BU_Info>'||Result||chr(13)||'</BU_Info>';
  Return(Result);
end co_get_CardData;


/
