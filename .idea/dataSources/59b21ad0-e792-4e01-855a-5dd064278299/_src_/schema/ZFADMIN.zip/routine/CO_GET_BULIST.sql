CREATE function CO_GET_BULIST(App_bseq integer,vm_wkno in number)
RETURN co_table PIPELINED is
  --RETURN number is
  PRAGMA AUTONOMOUS_TRANSACTION;
  My_Type         co_basic;
  v_Recs          integer;
  Menu_Type       integer;
  v_bseq          number(12);
  v_bid           varchar2(20);
  v_bname         varchar2(60);
  v_needs         varchar2(200);
  v_unneeds       varchar2(200);
  v_group         varchar2(200);
  v_bath          integer;
  v_Single        integer default 100000;
  v_More          integer default 0;
  v_MenuID        integer default 10;
  v_sdCount       integer;
  v_gwfseq        number(12);
  --Type strArray  is table of varchar2(10);
  --Type numArray  Is table of number;
  --v_StCode        strArray:=strArray();
  --v_StTotl        numArray:=numArray();
  v_WkNo          integer default 1;
  v_affair_config_count number;

Begin
--1、初始化自定义类型
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);

    Select apptype,co_seq_work.nextval into Menu_Type,v_WkNo
      From Appdefine Where bseq=app_bseq;

    Insert into My_SDList(NO,sd_id) Select distinct v_WkNo,hid From tu_house t1,my_worksdlist t2
     Where (t1.sid=t2.SD_ID or t1.lid=t2.SD_ID or t1.hid=t2.SD_ID)
       --and nvl(t1.sattribute,0)!=145001
       and no=vm_wkno;

    --如果客体有业务在办
    Select Count(*) into v_recs From to_state a,appdefine b,My_SDList c
     Where a.bseq=b.bseq and apptype=Menu_Type and modality=1 and a.sid=c.sd_id and c.no=v_WkNo ;
     
     ---配置 在办状态检测开始 
v_affair_config_count:=0;
  select count(*) into v_affair_config_count from ta_affair_config where startbseq=app_bseq;
   if v_affair_config_count>0 then
   v_recs:=0;
  select count(*) into v_recs from to_state a,ta_affair_config b,my_sdlist c
   where b.startbseq=app_bseq and instr(checkstate,stype)>0   and a.modality=1 and a.sid=c.sd_id and c.no=v_WkNo;
    end if;
    --结束

    If v_Recs>0 Then
       Rollback;
       return ;
    End if;

    --计算客体数量->v_sdCount变量
    Select count(*) into v_sdCount From My_SDList Where no=v_WkNo;

    If v_sdCount=0 and (Menu_Type=2 or Menu_Type=5 or Menu_Type=12 or Menu_Type=57 or Menu_Type=1201 or
      Menu_Type=104 ) then
        Rollback;
        My_type.id:=1;
        My_type.KEY:='1';
        My_type.str_1:='单笔业务';
        My_type.num_1:=-1;
        My_type.num_2:=10000;
        PIPE ROW (My_Type);
        If Menu_Type=2 Then
            My_Type.id:=2;
            My_Type.key:='CL01';
            My_Type.str_1:='栋测量';
            My_Type.num_1:=1;
            My_Type.str_2:='22005';
            My_Type.str_3:='CL01';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
        End if;
        If Menu_Type=12 Then
            My_Type.id:=2;
            My_Type.key:='CL11';
            My_Type.str_1:='楼盘修改';
            My_Type.num_1:=1;
            My_Type.str_2:='100000003713';
            My_Type.str_3:='CL11';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
        End if;
        If Menu_Type=1201 Then
            My_Type.id:=2;
            My_Type.key:='CL1101';
            My_Type.str_1:='搭建手工楼盘';
            My_Type.num_1:=1;
            My_Type.str_2:='100009003713';
            My_Type.str_3:='CL1101';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);
        End if;
        If Menu_Type=5 Then
            My_Type.id:=2;
            My_Type.key:='CL02';
            My_Type.str_1:='栋预测量';
            My_Type.num_1:=1;
            My_Type.str_2:='1750000';
            My_Type.str_3:='CL02';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);

        End if;


        If Menu_Type=57 Then
            My_Type.id:=2;
            My_Type.key:='FWAQ12';
            My_Type.str_1:='房屋安全鉴定申请';
            My_Type.num_1:=1;
            My_Type.str_2:='2900026';
            My_Type.str_3:='FWAQ12';
            My_Type.num_2:=100001;
            PIPE ROW (My_Type);

            My_Type.id:=3;
            My_Type.key:='FWAQ05';
            My_Type.str_1:='完损等级鉴定';
            My_Type.num_1:=1;
            My_Type.str_2:='2900018';
            My_Type.str_3:='FWAQ05';
            My_Type.num_2:=100002;
            PIPE ROW (My_Type);

            My_Type.id:=4;
            My_Type.key:='FWAQ06';
            My_Type.str_1:='拆除鉴定';
            My_Type.num_1:=1;
            My_Type.str_2:='2900020';
            My_Type.str_3:='FWAQ06';
            My_Type.num_2:=100003;
            PIPE ROW (My_Type);

             My_Type.id:=5;
            My_Type.key:='FWAQ07';
            My_Type.str_1:='装修安全鉴定';
            My_Type.num_1:=1;
            My_Type.str_2:='2900021';
            My_Type.str_3:='FWAQ07';
            My_Type.num_2:=100004;
            PIPE ROW (My_Type);

             My_Type.id:=6;
            My_Type.key:='FWAQ08';
            My_Type.str_1:='安全纠纷鉴定';
            My_Type.num_1:=1;
            My_Type.str_2:='2900022';
            My_Type.str_3:='FWAQ08';
            My_Type.num_2:=100005;
            PIPE ROW (My_Type);


             My_Type.id:=7;
            My_Type.key:='FWAQ09';
            My_Type.str_1:='维修性质鉴定';
            My_Type.num_1:=1;
            My_Type.str_2:='2900023';
            My_Type.str_3:='FWAQ09';
            My_Type.num_2:=100006;
            PIPE ROW (My_Type);


             My_Type.id:=8;
            My_Type.key:='FWAQ11';
            My_Type.str_1:='司法仲裁鉴定';
            My_Type.num_1:=1;
            My_Type.str_2:='2900025';
            My_Type.str_3:='FWAQ11';
            My_Type.num_2:=100007;
            PIPE ROW (My_Type);


             My_Type.id:=9;
            My_Type.key:='FWAQ10';
            My_Type.str_1:='安全监护鉴定';
            My_Type.num_1:=1;
            My_Type.str_2:='2900024';
            My_Type.str_3:='FWAQ10';
            My_Type.num_2:=100008;
            PIPE ROW (My_Type);


             My_Type.id:=10;
            My_Type.key:='FWAQ01';
            My_Type.str_1:='房屋安全鉴定';
            My_Type.num_1:=1;
            My_Type.str_2:='2900015';
            My_Type.str_3:='FWAQ01';
            My_Type.num_2:=100009;
            PIPE ROW (My_Type);

           End if;
           
            If Menu_Type=104 Then
            My_Type.id:=11;
            My_Type.key:='ZSGL63';
            My_Type.str_1:='补助卡发放(特殊)';
            My_Type.num_1:=1;
            My_Type.str_2:='130030162273';
            My_Type.str_3:='ZSGL63';
            My_Type.num_2:=100010;
            PIPE ROW (My_Type);
        End if;


        Return ;
    End if;

    If v_sdCount=0 Then
       Rollback;
       Return ;
    end if;

    --计算所有状态和客体数my_stlist）
    Insert into my_stlist(NO,stcode,stcount) Select v_WkNo,stype,count(*) totl
                            From (Select distinct sid,stype from tu_state t1,My_SDList t2
                                   Where sid=sd_id and (stype>'3' or stype='13')
                                   and no=v_WkNo)
                           Group by Stype;
    --生命周期状态
    Insert into my_stlist(NO,stcode,stcount) Select v_WkNo,bstate,count(*) From tu_bldg t1,tu_house t2,my_sdlist t3
                           Where t1.sid=t2.sid and hid=sd_id and no=v_WkNo
                           Group by bstate;
    --测量状态
    Insert into my_stlist(NO,stcode,stcount) Select v_WkNo,t0.sstate,count(*) From tu_bldg t0,tu_house t1,my_sdlist t2
                           Where t0.sid=t1.sid and t1.hid=t2.sd_id and no=v_WkNo
                           Group by sstate;


    Commit;

    DECLARE CURSOR MyCur IS
/*            Select tt0.BSEQ,BID,tt0.BNAME,tt0.needs,tt0.unneeds,Replace(','||bugroup||',',' ',''),isbath,Gwfseq
              From Appdefine tt0,ts_state tt2,
                   (Select distinct bseq from sv_budefine t1,my_stlist t2
                     Where t2.stcode like nvl(t1.stcode,'%') and apptype=Menu_Type and type=0 and stcount>=1 and no=v_WkNo) tt1
             Where tt0.bseq=tt1.bseq and tt0.apptype=Menu_Type and tt0.bseq!=v_sdCount
               and tt0.state_id=tt2.st_code
               and tt0.bseq not in (Select distinct bseq From sv_budefine t1,my_stlist t2
                                     Where t2.stcode like t1.stcode and apptype=Menu_Type and type=1 and no=v_WkNo)
              Order by tt2.st_order,decode(Optmod,'01',1,'10',9,2),bid;
*/
            Select tt0.BSEQ,BID,tt0.BNAME,tt0.needs,tt0.unneeds,Replace(','||bugroup||',',' ','') bugroup,isbath,Gwfseq
              From Appdefine tt0,ts_state tt2
             Where tt0.state_id=tt2.st_code and CO_GET_SDSTATE_NEW(tt0.BSEQ,v_WkNo,v_sdCount)=1
               and tt0.BSEQ!=App_bseq and tt0.apptype=Menu_Type
               and not exists(
               select  1 from sysfunction t4 where  tt0.bid=t4.fparam
               )
               
             Order by tt2.st_order,decode(Optmod,'01',1,'10',9,2),bid;

    Begin
       OPEN MyCur;
       LOOP
           FETCH MyCur INTO v_bseq,v_bid,v_bname,v_needs,v_unneeds,v_group,v_bath,v_gwfseq;
           EXIT WHEN MyCur%NOTFOUND;

           My_Type.id:=v_MenuID;
           My_Type.key:=v_bid;
           My_Type.str_1:=v_bname;
           My_Type.num_1:=1;
           My_Type.str_2:=to_char(v_bseq);
           My_Type.str_3:=v_bid;
           My_Type.num_2:=v_Single+v_MenuID;
           My_Type.num_5:=null;
           PIPE ROW (My_Type);
           v_MenuID:=v_MenuID+1;

           if v_bath=1 Then
              v_More:=200000;
              My_Type.id:=v_MenuID;
              My_Type.key:=v_bid;
              My_Type.str_1:=v_bname;
              My_Type.num_1:=2;
              My_Type.str_2:=to_char(v_bseq);
              My_Type.str_3:=v_bid;
              My_Type.num_2:=v_More+v_MenuID;
              My_Type.num_5:=null;
              PIPE ROW (My_Type);
              v_MenuID:=v_MenuID+1;
          End if;

          If  v_group!=',,' Then
              Select co_get_sumstr(bseq),co_get_sumstr(bid),co_get_sumstr(bname)
                Into My_Type.str_2,My_Type.str_3,My_Type.str_1
                From appdefine Where instr(','||v_group||',',','||to_char(bseq)||',')>0;
              My_Type.id:=v_MenuID;
              My_Type.key:=v_bid;
              My_Type.str_1:=v_bname||'＋'||replace(My_Type.str_1,',','＋');
              My_Type.str_2:=to_char(v_bseq)||','||My_Type.str_2;
              My_Type.str_3:=v_bid||','||My_Type.str_3;
              My_Type.num_1:=1;
              My_Type.num_2:=v_Single+10000+v_MenuID;
              My_Type.num_5:=v_gwfseq;
              PIPE ROW (My_Type);
              v_MenuID:=v_MenuID+1;
              If v_bath=1 Then
                 My_Type.num_1:=2;
                 My_Type.num_2:=v_More+10000+v_MenuID;
                 PIPE ROW (My_Type);
                 v_MenuID:=v_MenuID+1;
              End if;
          End if;
       END loop;
       CLOSE MyCur;
    End;
    My_type.str_2:=null;
    My_type.str_3:=null;
    If v_Single=100000 Then
      My_type.id:=1;
      My_type.KEY:='1';
      My_type.str_1:='单笔业务';
      My_type.num_1:=-1;
      My_type.num_2:=100000;
      PIPE ROW (My_Type);
    End if;
    If v_More=200000 Then
      My_type.id:=2;
      My_type.KEY:='2';
      My_type.str_1:='批量业务';
      My_type.num_1:=-1;
      My_type.num_2:=200000;
      PIPE ROW (My_Type);
    End if;
    Return ;
end ;
/
