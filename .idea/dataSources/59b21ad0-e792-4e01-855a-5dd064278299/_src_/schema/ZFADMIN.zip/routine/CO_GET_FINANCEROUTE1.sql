CREATE function co_get_financeRoute1(WFNO in number,tag number) Return integer is
  v_resu integer;
  v_apply_num number(15,2);
  v_item_id varchar2(100);
  v_useq number;
  v_deptid number;
  v_ifinance number;
begin
    select apply_num,item_id,useq  into v_apply_num,v_item_id,v_useq from tf_apply_bu a,ta_bscommon b where a.sseq=b.sseq and b.appseq=WFNO;
    select co_get_getDept(v_useq) into v_deptid from dual;
    select ifinance into v_ifinance from sysorgan where oseq=v_deptid;
    --是独立财务
    IF (v_ifinance=1) then 
    --会议费
    IF (v_item_id='5040102') then 
      --部门领导提交
       If (tag=1) then
         IF (v_apply_num<2000) then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管领导提交
       If (tag=2) then
         IF ((v_apply_num>=2000) and (v_apply_num<3000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管局长提交
       If (tag=3) then
         IF ((v_apply_num>=3000) and (v_apply_num<5000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
    End IF;
    --购置费、汽车费、物业、水电、绿化、维修
    IF ((v_item_id='5040109') or (v_item_id='5040106') or (v_item_id='5040108') or (v_item_id='5040107')) then 
      --部门领导提交
       If (tag=1) then
         IF (v_apply_num<1000) then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管领导提交
       If (tag=2) then
         IF ((v_apply_num>=1000) and (v_apply_num<2000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管局长提交
       If (tag=3) then
         IF ((v_apply_num>=2000) and (v_apply_num<5000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
    End IF;
    --招待费
    IF (v_item_id='5040104') then 
      --部门领导提交
       If (tag=1) then
         IF (v_apply_num<1000) then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管领导提交
       If (tag=2) then
         IF ((v_apply_num>=1000) and (v_apply_num<2000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管局长提交
       If (tag=3) then
         IF ((v_apply_num>=2000) and (v_apply_num<3000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
    End IF;
    --办公费、培训费、差旅费
    IF ((v_item_id='5040101') or (v_item_id='5040103') or (v_item_id='5040105')) then 
      --部门领导提交
       If (tag=1) then
         IF (v_apply_num<1000) then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管领导提交
       If (tag=2) then
         IF ((v_apply_num>=1000) and (v_apply_num<2000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管局长提交
       If (tag=3) then
         IF ((v_apply_num>=2000) and (v_apply_num<5000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
    End IF;
   End IF;
   
   
   
    --非独立财务
    IF (v_ifinance=0) then 
    --会议费
    IF (v_item_id='5040102') then 
       --分管局长提交
       If (tag=2) then
         IF (v_apply_num<3000)  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管财务局长提交
       If (tag=3) then
         IF ((v_apply_num>=3000) and (v_apply_num<5000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
    End IF;
    --购置费、汽车费、物业、水电、绿化、维修
    IF ((v_item_id='5040109') or (v_item_id='5040106') or (v_item_id='5040108') or (v_item_id='5040107')) then 
       --分管局长提交
       If (tag=2) then
         IF (v_apply_num<2000)  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管财务局长提交
       If (tag=3) then
         IF ((v_apply_num>=2000) and (v_apply_num<5000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
    End IF;
    --招待费
    IF (v_item_id='5040104') then 
       --分管领导提交
       If (tag=2) then
         IF (v_apply_num<2000)  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管局长提交
       If (tag=3) then
         IF ((v_apply_num>=2000) and (v_apply_num<3000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
    End IF;
    --办公费、培训费、差旅费
    IF ((v_item_id='5040101') or (v_item_id='5040103') or (v_item_id='5040105')) then 

       --分管局长提交
       If (tag=2) then
         IF (v_apply_num<2000)  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
       --分管财务局长提交
       If (tag=3) then
         IF ((v_apply_num>=2000) and (v_apply_num<5000))  then
             v_resu:=1;
         else
             v_resu:=0;
          End IF;
       End If;
    End IF;
   End IF;  
    return v_resu;
end co_get_financeRoute1;


/
