CREATE function co_joinstr(cname varchar2) return varchar2 is


  Result varchar2(400);
  v_a clob;
/*代码转换
  输入:
     cid—代码ID
     ckey—装换
  输出
     Result—代码说明
*/
begin
  select wm_concat(cname) into v_a from dual ;
  Result:=to_char(v_a);
  Return(Result);
  --Exception when others then return '未指定';
end co_joinstr;
/
