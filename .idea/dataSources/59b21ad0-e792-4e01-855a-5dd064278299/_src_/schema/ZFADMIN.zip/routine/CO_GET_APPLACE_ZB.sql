CREATE function CO_GET_applace_zb(v_iaparent in number) return
 --varchar2 is
    co_table PIPELINED is
    My_Type     co_basic;
    v_IAID    varchar2(100);
    v_IALoc    varchar2(100);
    v_IANo       varchar2(6000);


Begin
--1、初始化自定义类型

     My_Type:=co_basic(null,null,null,null,null,null,0,null,null,null,null,null,null,null);



             Select * Into v_IAID,v_IALoc,v_IANo From (
       Select iaseq,iadesc,maxid+1  From sys_daia
        Where connect_by_isleaf=1 and usermark=1 and ycy<kcy
        Start with IASEQ=v_iaparent
           Connect by prior iaseq = iaparent order by iadesc) Where rownum<2;
            My_Type.id:=v_IAID;
       My_Type.key:=v_IALoc||'.'||substr('000'||to_char(v_IANo),-3);
         My_Type.STR_1:=v_IANo;
          PIPE ROW (My_Type);
    Return ;
end CO_GET_applace_zb;
/
