CREATE function co_get_Barea_sgm(v_barea in number) return varchar2 is
  Result varchar2(20);
  v_val  number;
begin
  v_val:=nvl(v_barea,0);
  If v_val<=90 then
     Result:=' <90㎡';
     return(Result);
  End if;
  If v_val>90 and v_val<=120 then
     Result:=' 90-120㎡';
     return(Result);
  End if;
  If v_val>120 and v_val<=144 then
     Result:='120-144㎡';
     return(Result);
  End if;  
  return '>144㎡';
end co_get_Barea_sgm;


/
