CREATE function co_get_btru_one(str in varchar2) Return varchar2 is
  v_resu varchar2(4000);
begin
  If str is null Then Return '其他';end if;
  if (instr(str,'，')>0) then
     v_resu:=substr(str,1,instr(str,'，')-1);
  else
     v_resu:=str;
  end if;

    return v_resu;
end co_get_btru_one;
/
