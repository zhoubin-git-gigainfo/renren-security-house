CREATE function CO_GET_INFO(BU_No in Number,Info_Type varchar2)
RETURN co_table PIPELINED
  /*输入参数说明：
  BU_No：业务号
  Info_Type：需要获取的业务数据类型
             AGENT-代理人
             APPLY-申请(委托)人
             RECEIVE-收件目录
             RECEIVE-收件目录
             FRUIT-提交成果(仅用于项目测量)
             GIST-计算依据和工具(仅用于项目测量) 
             TAQ_INFO-登记权利信息       
  */
IS
  My_Type   co_basic;
  v_first   Integer;
  v_name    varchar2(80);
  v_addr    varchar2(80);
  v_icno    varchar2(80);
  v_tel     varchar2(80);
  v_info    varchar2(80);
  v_xh      Integer;
begin
--一、初始化自定义类型
  My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
  v_first:=0;
  v_info:=UPPER(Info_Type);
  
--二、通用业务信息

--1、取代理人或申请人信息(姓名、证件、电话、地址)
  If v_info='AGENT' Or v_info='APPLY' Then 
      DECLARE
         CURSOR MyCur IS
                Select agentname,ic_type||' '||ic_no,agenttelephone,agentaddress
                  From ta_agent Where sseq=BU_No and maintypeid=Decode(v_info,'AGENT',0,1);
         BEGIN
            OPEN MyCur;
            LOOP
               FETCH MyCur INTO v_name,v_icno,v_tel,v_addr;
               EXIT WHEN MyCur%NOTFOUND;
               If v_first=0 Then
                  My_Type.Str_2:=v_icno;
                  My_Type.Str_3:=v_tel;
                  My_Type.Str_4:=v_addr;
                  v_first:=1;
               End if;
               If length(My_Type.Str_1)>0 then
                  My_Type.Str_1:=My_Type.Str_1||'，';
               End if;
               If length(My_Type.Str_1||v_name)<=2048 then
                  My_Type.Str_1:=My_Type.Str_1||v_name;
               End if;
            END loop;
            CLOSE MyCur;
            My_Type := co_basic(0,v_info,null,null,null,null,null,My_Type.Str_1,My_Type.Str_2,My_Type.Str_3,My_Type.Str_4,null,null,null);
            PIPE ROW (My_Type);
         End;
     End if;
--2、业务收件清单[序号,名称]
     If v_info='RECEIVE' Then
      DECLARE
         CURSOR MyCur IS
                Select dno,Dname From TU_Dlist Where sseq=BU_No order by dno;
         BEGIN
            OPEN MyCur;
            LOOP
               FETCH MyCur INTO v_first,v_name;
               EXIT WHEN MyCur%NOTFOUND;
               My_Type := co_basic(v_first,v_info,null,null,null,null,null,v_name,null,null,null,null,null,null);
               PIPE ROW (My_Type);
             END loop;
            CLOSE MyCur;
         End;
     End if;
     
--三、专用信息

--1、提交的测量成果清单收件名称
     If v_info='FRUIT' Then
      v_xh:=1;
      DECLARE
         CURSOR MyCur IS
                Select Fname From ta_FRUIT Where sseq=BU_No;
         BEGIN
            OPEN MyCur;
            LOOP
               FETCH MyCur INTO v_name;
               EXIT WHEN MyCur%NOTFOUND;
               My_Type := co_basic(v_xh,v_info,null,null,null,null,null,v_name,null,null,null,null,null,null);
               PIPE ROW (My_Type);
               v_xh:=v_xh+1;
             END loop;
            CLOSE MyCur;
         End;
     End if;
     
--2、测量依据[计算依据和测量工具名称]
     If v_info='GIST' Then
      v_first:=1;
      DECLARE
         CURSOR MyCur IS
                Select aname From ta_calculate Where sseq=BU_No;
         BEGIN
            OPEN MyCur;
            LOOP
               FETCH MyCur INTO v_name;
               EXIT WHEN MyCur%NOTFOUND;
               My_Type := co_basic(v_first,v_info,null,null,null,null,null,v_name,null,null,null,null,null,null);
               PIPE ROW (My_Type);
               v_first:=v_first+1;
             END loop;
            CLOSE MyCur;
         End;
     End if;
     
     
--三、返回结果（）
     return;
end co_get_info;


/
