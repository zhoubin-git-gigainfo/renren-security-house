CREATE function CO_GET_SCOPE(strScope in varchar2) return varchar2 is
  Result varchar2(2000);
begin
  If length(trim(strScope))<2 or strScope is null Then
     return '“无数据”';
  End if;
  Result:=strScope;
  While instr(strScope,'  ')>0 loop
    Result:=Replace(strScope,' ','');
  End loop;
  Result:=Replace(Result,'+','% and %');
  Result:=Replace(Result,',','% or %');
  Result:='%'||Replace(Result,'-','% not %')||'%';

  Result:=Replace(Result,'"%','');
  Result:=Replace(Result,'%"','');
  return(Result);
end co_get_scope;


/
