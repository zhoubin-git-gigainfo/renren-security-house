CREATE function encrypt (in_string varchar2,shift number) return varchar2 is 
    lv_out_string varchar2(100); 
    lv_in_string varchar2(100); 
    lv_length number(5); 
    lv_count number(5); 
    lv_temp varchar2(1); 
    lv_shift number(5); 
begin 
    lv_shift := mod(shift,26); 
    lv_in_string := lower(in_string); 
    select LENGTH(lv_in_string),1,'' into lv_length,lv_count,lv_out_string from dual; 
     
    for lv_count in    1.. lv_length loop 
                             lv_temp := substr(lv_in_string,lv_count,1); 
                             if ascii(lv_temp) <97    or ascii(lv_temp) >122 then 
                                    lv_out_string := lv_out_string || lv_temp; 
                             else 
                                    if ascii(lv_temp)+lv_shift>122 then 
                                         lv_temp :=chr(ascii(lv_temp)+lv_shift - 26); 
                                    else 
                                         lv_temp := chr(ascii(lv_temp)+lv_shift); 
                                    end if; 
                                     lv_out_string := lv_out_string || lv_temp; 
                             end if; 
    end loop; 
    return lv_out_string; 
end encrypt ;
/
