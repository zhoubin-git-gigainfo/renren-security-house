CREATE function co_get_MyOrgan(Vm_OrgLists in Varchar2, vm_Useq in number) return number is
  Result number;
begin
  If (Vm_OrgLists is null) or Instr(','||Vm_OrgLists||',',','||to_char(vm_Useq)||',')>0 Then
     Result:=1;
  Else
     Select count(*) into Result From sv_orglevel,sysuserorg
      Where sseq=oseq
        and (Instr(','||Vm_OrgLists||',',','||to_char(pseq)||',')>0 or Instr(','||Vm_OrgLists||',',','||to_char(sseq)||',')>0)
        and useq=vm_Useq;
  End if;
  Return  Result;
end co_get_MyOrgan;


/
