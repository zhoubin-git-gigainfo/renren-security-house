CREATE function co_get_RegDate(v_BuNo in number) return date is
  Result date;
begin
  Select to_date(to_char(max(v_date),'yyyy-mm-dd'),'yyyy-mm-dd') into Result 
    From to_state Where modality!=1 and bid=v_BuNo;
  If Result is null then
     Select regbookdate into Result From taq_enrol  Where sseq=v_BuNo;
  End if;
  return(Result); 
end co_get_RegDate;


/
