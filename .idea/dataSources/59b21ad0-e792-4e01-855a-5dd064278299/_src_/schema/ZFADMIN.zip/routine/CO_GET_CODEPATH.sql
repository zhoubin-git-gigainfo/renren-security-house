CREATE function co_Get_codePath(Code_Val in number) return varchar2 is
  Result varchar2(2000);
begin
   Select max(SYS_CONNECT_BY_PATH(to_char(id),'/'))||'/' into Result
     from ts_code start with id=Code_Val
    Connect by NOCYCLE prior parentid= id ;
  return(Result);
end co_Get_codePath;


/
