CREATE function CO_GET_FEEList_TEST(BU_SEQ in number)
RETURN number 
--co_table PIPELINED
IS
    My_Type        co_basic;
    v_Parm         dbms_sql.Number_Table ;
    v_BSEQ         number(12);
    v_BuType       Integer;
    IsFound        integer;
    IsLeaf         integer;
    type rc is ref cursor;
    cur    rc;
    l_Sql    varchar2(6000);  
    v_recs   integer;   
    --计费标准
    p_MoreUse     Integer default -1 ;--(1=多用途；0=单用途）
    p_UseType     Integer default -1 ;--(1=住宅；0=非住宅）  
    p_DroitType   Integer default -1 ;--(1=私产；0=其他）
    p_RealType    Integer default -1 ;--(1=新建商品房；2=存量房；3=房改房；4=经济适用房；5=双限房）
    p_AreaSegm    integer default -1 ;--(1=0~200平；2=200~500平；3=500~1000平;4=1000~)
    p_GageSegm    Integer default -1 ;--(1=0~2K万；2=2~5K万；3=2.5~5K万;4=10K万~)
    p_Corps       Integer default -1 ;--(1=普通住宅；0=其他住宅）

    vp_User       char(2);
    p_lcount      integer;

 v_ptype number;
  v_huse  number;

  v_servertype integer default - 1; --白蚁灭治服务类型（有偿服务，无偿服务，包治期服务；）
  --v_deraterat number(15,2); --白蚁预防减免金额
  --v_sje number(15,2); --白蚁预防实收金额

Begin
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    --key=缴费方（1=申请方；2=转让方）
    --
    Select a.bseq,b.apptype into v_BSEQ,v_BuType from sv_bulists a,appdefine b Where a.sseq=BU_SEQ and a.bseq=b.bseq;
--一、计费依据 
    v_Parm(1):=1;--缺省（业务数）
    v_Parm(2):=0;--确定价值
    v_Parm(3):=0;--贷款额
    v_Parm(4):=0;--客体数
    v_Parm(5):=0;--面积
    v_Parm(6):=1;
    v_Parm(7):=1;--发证数
        
    If (v_BuType=2 or v_BuType=5) Then   --测量收费
        Select Decode(count(distinct useid),1,'U1','U2') into vp_User from ta_hxx where sseq=BU_SEQ;
        l_Sql:='Select Decode(Count(distinct b.useid),1,0,1) Is_MoreUse,';
        l_Sql:=l_Sql||'Decode(Instr(co_get_codepath(min(b.useid)),''/110''),0,0,1) is_usetype,';
        l_Sql:=l_Sql||'0 Is_Corps,max(to_number(a.zjzmj)) barea,Count(distinct c.cc) Icount,0';
        l_Sql:=l_Sql||' From ta_zxx a,ta_hxx b,ta_cxx c';
        l_Sql:=l_Sql||' Where a.sseq='||to_char(BU_SEQ)||' and a.sseq=b.sseq and a.sseq=c.sseq';
    End if;
    
      If  v_BSEQ=1001733  Then
        select 1,1 into v_Parm(2),v_Parm(3) from dual;
        -- and sattribute=145003;
        l_sql:='Select 1,1,1,1,1,1 From dual';
    End if;

    If v_BuType=7 and v_BSEQ=100000004180 Then   --担保测量收费       
        --Select totalpay into v_Parm(2) From ta_scale  Where sseq=BU_SEQ;
        l_sql:='Select 1,1,1,1,1,1 From ta_scale Where sseq='||to_char(BU_SEQ);
    End if;
    
    
   If v_BuType = 63 and v_BSEQ = 1001613 Then
    --阶段性担保收费      
    --Select totalpay into v_Parm(2) From ta_scale  Where sseq=BU_SEQ;
    Select 1, loanmoney, PTYPE, huse
      into v_Parm(2), v_Parm(3), v_ptype, v_huse
      From tat_security_bu
     Where sseq = BU_SEQ; 
     
     if   v_ptype is null or v_ptype=0 then
       v_ptype:=92102;
     end if;
      
  --商业贷款
    if v_ptype = 92102 then
      --住宅
      if v_huse = 99212 then
        If (v_Parm(3) * 0.01 > 2800) then
          v_Parm(3) := 2800;
        elsif (v_Parm(3) * 0.01 <= 2800) then
          v_Parm(3) := v_Parm(3) * 0.01;
        End If;   
       --非住宅    
      elsif v_huse = 99213 then      
        if v_Parm(3) < 1000000 then        
          v_Parm(3) := v_Parm(3) * 0.005;        
        elsif v_Parm(3) > 1000000 then
          v_Parm(3) := 1000000 * 0.005 + (v_Parm(3) - 1000000) * 0.002;        
        end if;      
      end if;
    end if;
  
    if v_ptype = 92103 then
      v_Parm(3) := v_Parm(3) * 0.01;
    end if;  
    l_sql := 'Select 1,1,1,' || v_Parm(3) ||
             ',1,1 From ta_bscommon Where sseq=' || to_char(BU_SEQ);  
             
    -- v_Parm(2):=v_Parm(3);       
       
  End if;
    
    If v_BuType=7 and (v_BSEQ=2591001 or v_BSEQ=2591013  ) Then   --担保预收费,经纪费      
        --Select totalpay,loannumber*decode(term,0,1,term) into v_Parm(2),v_Parm(3) From ta_suretyagent  Where sseq=BU_SEQ;
        Select totalpay,loannumber into v_Parm(2),v_Parm(3) From ta_suretyagent  Where sseq=BU_SEQ;
        l_sql:='Select 1,1,case when a.barea<144 then 1 else 2 end,0,0,0 
        From tac_sdlist a,tu_house b,ta_suretyagent c Where a.sseq=c.sseq and a.sd_id=b.hid and c.sseq='||to_char(BU_SEQ);             
        --My_Type.num_4:=15;
        --If (v_Parm(3)*0.001<400) then v_Parm(3):=400000; End If;
        --If (v_Parm(3)*0.001>2800) then v_Parm(3):=2800000; End If;
    End if;

    If v_BuType=71 and v_BSEQ=100000004177  Then   --担保预收费,经纪费      
        --Select totalpay,loannumber*decode(term,0,1,term) into v_Parm(2),v_Parm(3) From ta_suretyagent  Where sseq=BU_SEQ;
        Select totalpay,loannumber into v_Parm(2),v_Parm(3) From ta_suretyagent  Where sseq=BU_SEQ;
        l_sql:='Select 1,1,case when a.barea<144 then 1 else 2 end,0,0,0 
        From tac_sdlist a,tu_house b,ta_suretyagent c Where a.sseq=c.sseq and a.sd_id=b.hid and c.sseq='||to_char(BU_SEQ);             
        --My_Type.num_4:=15;
        --If (v_Parm(3)*0.001<400) then v_Parm(3):=400000; End If;
        --If (v_Parm(3)*0.001>2800) then v_Parm(3):=2800000; End If;
    End if;
    
    If v_BuType=16 and (v_BSEQ=2591001 or v_BSEQ=2591013 ) Then   --经纪费      
        Select totalpay,loannumber into v_Parm(2),v_Parm(3) From ta_suretyagent  Where sseq=BU_SEQ;
        l_sql:='Select 1,1,case when a.barea<144 then 1 else 2 end,0,0,0 
        From tac_sdlist a,tu_house b,ta_suretyagent c Where a.sseq=c.sseq and a.sd_id=b.hid and c.sseq='||to_char(BU_SEQ);             
    End if;
    
    If v_BuType=17 and (v_BSEQ=100000029481) Then   --补缴预收费    
        Select totalpay,loannumber into v_Parm(2),v_Parm(3) From ta_suretyagent  Where sseq=BU_SEQ;
        l_sql:='Select 1,1,case when a.barea<144 then 1 else 2 end,0,0,0 
        From tac_sdlist a,tu_house b,ta_suretyagent c Where a.sseq=c.sseq and a.sd_id=b.hid and c.sseq='||to_char(BU_SEQ);             
    End if;
    
    If v_BuType=7 and (v_BSEQ=100000004181 or v_BSEQ=100000004182) Then   --担保本登记       
        Select cardcount-1 into v_Parm(7) From taq_enrol Where sseq=BU_SEQ;
        Select sum(nvl(pawnmoney,0))+sum(nvl(tiptopcreditor,0)) Into v_Parm(3) From taq_enrol Where sseq=BU_SEQ;--贷款额
        Select sum(nvl(pprice,0)) Into v_Parm(2) From taq_sdlist Where sseq=BU_SEQ;  --确认价 
        
        l_Sql:='Select 0,Decode(Instr(co_get_codepath(b.huse),''/''||''110''),0,0,1),';
        l_Sql:=l_Sql||'case when a.barea<144 Or a.parea<120 then 1 else 0 end Is_Corps,';
        l_Sql:=l_Sql||'sum(b.barea) Barea,sum(1) ICount,max(decode(c.protype,230,1,0)) ';
        l_Sql:=l_Sql||'From taq_sdlist a,tu_house b,taq_enrol c ';
        l_Sql:=l_Sql||'Where a.sseq='||to_char(BU_SEQ)||' and (a.sd_id=b.hid or a.sd_id=b.sid or a.sd_id=b.lid) and c.sseq=a.sseq ';
        l_Sql:=l_Sql||'Group by 0,Decode(Instr(co_get_codepath(b.huse),''/''||''110''),0,0,1),';
        l_Sql:=l_Sql||'case when a.barea<144 Or a.parea<120 then 1 else 0 end';
    End if;
        
    If v_BuType=6 Then   --档案收费
        Select decode(cb_type,230,1,0) into p_DroitType From ta_qarchives Where sseq=BU_SEQ;
        l_Sql:='Select 0,0,0,0,1,1 From ta_qarchives Where sseq='||to_char(BU_SEQ);
    End if;
    
   If v_BuType=603 OR v_BuType=604  Then   --核档查询收费
        Select decode(cb_type,230,1,0) into p_DroitType From ta_bsarch Where sseq=BU_SEQ;
    
        l_Sql:='Select 0,0,0,0,1,1 From ta_bsarch Where sseq='||to_char(BU_SEQ);
    End if;
     If v_BuType=611 or v_BuType=610 Then   --租赁管理
      --  Select decode(cb_type,230,1,0) into p_DroitType From ta_bsarch Where sseq=BU_SEQ;
    l_Sql:='select  1,decode(a0.id,110,1,decode(a0.parentid,110,1,0)) ,1,a1.tarea,1,1 from 
   (select   a1.id,parentid from ta_tenancy a0,ts_code a1 where sseq='||to_char(BU_SEQ)
   ||' and  a0.tuse=a1.id ) a0,ta_tenancy_contract a1  where rownum=1  and a1.sseq='||to_char(BU_SEQ);
       -- l_Sql:='Select 1,1,1,502,1,1 From ta_tenancy Where sseq='||to_char(BU_SEQ);
    End if;  
    
       If v_BuType=129 OR v_BuType=139  Then   --住房保障收取租金    
        l_Sql:='Select 0,0,0,0,1,1 From HS_RENTSUM_BU Where sseq='||to_char(BU_SEQ);
    End if;
      
     If (v_BuType=55 and ((v_BSEQ=100000049973) or (v_BSEQ=100010152059))) Then   ----补交退款计费     
         Select 1,1 into v_Parm(2),v_Parm(3) From TFB_UPDATETAX_BU  Where sseq=BU_SEQ;
        l_sql:='Select 1,1,1,1,1,1 From ta_bscommon Where sseq='||to_char(BU_SEQ);
    End if;    
    --当为预售信息公示收费
    --If v_BuType=3  Then         
     --   select count(*) into v_Parm(2) from tu_house where sid=(select sid from tas_pslist where sseq=BU_SEQ);
        -- and sattribute=145003;
     --   l_sql:='Select 1,1,1,0,0,0 From dual';
   -- End if; 
   ---楼盘公示费
  If  v_BSEQ=100000076942  Then
        select count(*) into v_Parm(2) from tu_house where sid=(select sid from tas_pslist where sseq=BU_SEQ);
        -- and sattribute=145003;
        l_sql:='Select 1,1,1,0,0,0 From dual';
    End if;
    If v_BuType=3  and ( --v_bseq=100000004803 or 
      v_bseq=1903000 or v_bseq=1930007 or v_bseq=2409000) Then   --维修基金费用计算  
     begin
        select distinct cprice into v_Parm(2) from sales_contract where sseq in (select bid from  tu_state  where stype in ('32','33') and bid=BU_SEQ);     
        l_sql:='Select 1,1,case when a.lcout<8 then 1 else 2 end,0,0,0 From tu_bldg a,tu_house b,tu_state c Where a.sid=b.sid and b.hid=c.sid and stype in (''32'',''33'') and c.bid='||to_char(BU_SEQ);            
        select distinct lcout  into p_lcount from  tu_bldg a,tu_house b,tu_state c Where a.sid=b.sid and b.hid=c.sid and stype in ('32','33') and c.bid=to_char(BU_SEQ);                   
     end;
    End if;
 
    If v_BuType=4  or v_BuType=80 Then   --登记收费
        Select cardcount-1 into v_Parm(7) From taq_enrol Where sseq=BU_SEQ;
        Select sum(nvl(pawnmoney,0))+sum(nvl(tiptopcreditor,0)) Into v_Parm(3) From taq_enrol Where sseq=BU_SEQ;--贷款额
        Select sum(nvl(pprice,0)) Into v_Parm(2) From taq_sdlist Where sseq=BU_SEQ;  --确认价 
        
        l_Sql:='Select 0,Decode(Instr(co_get_codepath(b.huse),''/''||''110''),0,0,1),';
        l_Sql:=l_Sql||'case when a.barea<144 Or a.parea<120 then 1 else 0 end Is_Corps,';
        l_Sql:=l_Sql||'sum(b.barea) Barea,sum(1) ICount,max(decode(c.protype,230,1,0)) ';
        l_Sql:=l_Sql||'From taq_sdlist a,tu_house b,taq_enrol c ';
        l_Sql:=l_Sql||'Where a.sseq='||to_char(BU_SEQ)||' and (a.sd_id=b.hid or a.sd_id=b.sid or a.sd_id=b.lid) and c.sseq=a.sseq ';
        l_Sql:=l_Sql||'Group by 0,Decode(Instr(co_get_codepath(b.huse),''/''||''110''),0,0,1),';
        l_Sql:=l_Sql||'case when a.barea<144 Or a.parea<120 then 1 else 0 end';
        
    End if;
    
    
    
    
    
If  v_BSEQ=100000004803  Then
        --select sum(barea) into v_Parm(5) from tu_house where hid=(select sd_id from taq_sdlist where sseq=BU_SEQ);
        -- av_Parmnd sattribute=145003;
       -- l_sql:='Select 1,1,1,0,'||v_Parm(5)||',0 From dual';
      -- select distinct lcout  into p_lcount from  tu_bldg a,tu_house b,tu_state c Where a.sid=b.sid and b.hid=c.sid and stype in ('32','33') and c.bid=to_char(BU_SEQ);
      -- p_lcount:='1';
        -- l_sql:='Select 1,1,1,0,0,0 From dual';     
      
         --测试交易备案手续费登记收费
        Select 0 into v_Parm(7) From dual;
        Select 0 Into v_Parm(3) From dual;
        Select sum(nvl(cprice,0)) Into v_Parm(2) From sales_contract Where sseq=BU_SEQ;  --确认价

        l_Sql:='Select 0,Decode(Instr(co_get_codepath(b.huse),''/''||''110''),0,0,1),';
        l_Sql:=l_Sql||'case when a.barea<144 Or a.parea<120 then 1 else 0 end Is_Corps,';
        l_Sql:=l_Sql||'sum(b.barea) Barea,sum(1) ICount,max(decode(c.protype,230,1,0)) ';
        l_Sql:=l_Sql||'From taq_sdlist a,tu_house b,sales_contract c ';
        l_Sql:=l_Sql||'Where a.sseq='||to_char(BU_SEQ)||' and (a.sd_id=b.hid or a.sd_id=b.sid or a.sd_id=b.lid) and c.sseq=a.sseq ';
        l_Sql:=l_Sql||'Group by 0,Decode(Instr(co_get_codepath(b.huse),''/''||''110''),0,0,1),';
        l_Sql:=l_Sql||'case when a.barea<144 Or a.parea<120 then 1 else 0 end';

    End if;   
    
    
       
   If (v_BuType=570 or v_BuType=572) and  (v_bseq =100010163991 or v_bseq =100010163992 or v_bseq=100010164028 or v_bseq=100010164030) Then   --白蚁新建预防   
        l_sql:='Select 1,1,1,barea,1,1 from tas_bldg where sseq='||to_char(BU_SEQ);
        
        --select 32 into v_deraterat from tc_contract_bu where sseq=to_char(BU_SEQ);
        --update taq_taxapp set deraterat=v_deraterat where sseq=to_char(BU_SEQ);
        
        
    End if;  
    If v_BuType=570 and  (v_bseq =100010163995 or v_bseq=100010163996) Then   --白蚁装饰装修预防    
       
     l_sql:='Select 1,decode(spid,1,1,2,0,null,0),1,sum(barea),1,1 from taq_sdlist where sseq='||to_char(BU_SEQ)||' group by spid';
       
    End if; 
      If v_BuType=570 and  (v_bseq =100010163993 or v_bseq=100010163994) Then   --白蚁灾害灭治    
       
         select count(servertype) into v_servertype from tc_killingplan_bu where servertype=722049 and sseq=to_char(BU_SEQ);
     
         if v_servertype=1 then
       
           l_sql:='Select 1,1,1,sum(money),1,1 from tc_killingplanlist_bu where sseq='||to_char(BU_SEQ);
         end if;
    
    End if; 
  
    
    
    
    
    
    If l_Sql is null then 
       l_Sql:='Select null,null,null,null,null,null from dual where 1=2';
    End if;
    Open cur for l_Sql ;
    --返回结果按顺序为：是否多用途；是否住宅；是否普通住宅；面积；客体数
    Loop

        Fetch cur into p_MoreUse,p_UseType,p_Corps,v_Parm(5),v_Parm(4),p_DroitType;
        Exit when cur%notfound;
        
        --面积分段
        If v_Parm(5)<=200 Then p_AreaSegm:=1; End if;
        If v_Parm(5)>200 and v_Parm(5)<=500 Then p_AreaSegm:=2; End if;
        If v_Parm(5)>500 and v_Parm(5)<=1000 Then p_AreaSegm:=3; End if;
        If v_Parm(5)>1000 Then p_AreaSegm:=4; End if;
        --租赁管理面积分段
         If v_BuType=611 or v_BuType=610 Then
           If v_Parm(5)<=20 Then p_AreaSegm:=1; End if;
           If v_Parm(5)>20 and v_Parm(5)<=100 Then p_AreaSegm:=2; End if;
           If v_Parm(5)>100 and v_Parm(5)<=500 Then p_AreaSegm:=3; End if;
           If v_Parm(5)>500 and v_Parm(5)<=1000 Then p_AreaSegm:=4; End if;
            If v_Parm(5)>1000 Then p_AreaSegm:=5; End if;
         end if;                         
        --贷款额分段
        If v_Parm(3)<=20000000 Then p_GageSegm:=1; End if;
        If v_Parm(3)>20000000 and v_Parm(3)<=25000000 Then p_GageSegm:=2; End if;
        If v_Parm(3)>25000000 and v_Parm(3)<=990000000 Then p_GageSegm:=3; End if;

        Declare CURSOR cur_TItem IS
                        Select b.cid,a.cfml From ts_tariff a,ts_titem b 
                         Where a.bseq=v_BSEQ and a.iid=b.cid Order by b.cid; 
        Begin
            Open cur_TItem;
            Loop
               Fetch cur_TItem Into My_Type.ID,My_Type.key;
               Exit When cur_TItem%NotFound;
               
                     If v_BuType=603 OR v_BuType=604   Then 
           --将ta_bsarch的业务类型 转换成ts_titem的收费项ID
           --房屋登记信息查询(84101)--档案查询、验证(185002)
           --核档证明(84102)--产权证明(含查阅费)(185000)
           --保障性住房证明(84103)--产权证明（保障性住房）185001
          select nvl(to_char(wm_concat(iid)),0) into My_Type.ID from (select  iid   
          from ta_bsarch a0,ts_tariff a1 where a0.causeid=a1.bseq and sseq=BU_SEQ) where iid=My_Type.ID;
                --  My_Type.ID:=0;       
                        --  select COPYNUM into My_Type.num_4 from ta_bsarch where sseq=BU_SEQ;
             End if; 
               
               IsFound:=0;
                 DBMS_OUTPUT.put_line('ver_id===='||My_Type.ID);
               Declare CURSOR Cur_Sel IS
                         Select ver_val,mod_bas,bas_val,icode,udesc,connect_by_isleaf,
                               ltrim(sys_connect_by_path(ver_name,'/'),'/'),
                               ltrim(sys_connect_by_path('{'||substr(ver_mod,1,instr(ver_mod,',')-1)||'}','='),'='),
                               ltrim(sys_connect_by_path('{'||substr(ver_mod,instr(ver_mod,',')+1)||'}','='),'=')
                          from ts_price start with ver_id=My_Type.ID connect by nocycle prior ver_id = parentid;
                          
                        
/*                        Select ver_val,mod_bas,bas_val,icode,udesc,connect_by_isleaf,
                               ltrim(sys_connect_by_path(ver_name,'/'),'/'),
                               ltrim(sys_connect_by_path('{'||substr(ver_mod,1,instr(ver_mod,',')-1)||'}','='),'='),
                               ltrim(sys_connect_by_path('{'||substr(ver_mod,instr(ver_mod,',')+1)||'}','='),'=')
                          from ts_price start with ver_id=My_Type.ID connect by nocycle prior ver_id = parentid;
*/                Begin
                    Open Cur_Sel;
                    Loop
                       Fetch Cur_Sel Into My_Type.num_1,My_Type.num_5,My_Type.num_3,My_Type.STR_2,My_Type.STR_3,IsLeaf,My_Type.STR_1,My_Type.STR_4,My_Type.STR_5;
                       Exit When Cur_Sel%NotFound;
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_DroitType',to_char(p_DroitType));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_MoreUse',to_char(p_MoreUse));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_UseType',to_char(p_UseType));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_RealType',to_char(p_RealType));                       
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_AreaSegm',to_char(p_AreaSegm));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_GageSegm',to_char(p_GageSegm));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_Corps',to_char(p_Corps));
                       My_Type.num_4:=1;
                       
                       
                       
                       If My_Type.STR_4=My_Type.STR_5 and IsLeaf=1 and v_Parm(My_Type.num_5)>=0 Then 
                          My_Type.num_2:=v_Parm(My_Type.num_5);
                       --当为预售信息公示收费
                       If v_BuType=3  Then 
                       begin
                          My_Type.num_2:=v_Parm(2);
                             If (p_lcount<8) then 
                              My_Type.STR_2:='多层';
                             else
                             My_Type.STR_2:='高层';
                             end if;
                        end;
                       End if;
                        if My_Type.ID=199100 and ( v_BuType=129 or v_BuType=139 )      then
                         select parent into My_Type.NUM_1 from hs_rentsum_bu where sseq=BU_SEQ;
                       --  My_Type.NUM_1:=1000;
                         
                         end if;
                        if My_Type.ID=186005 and v_bseq not in(1793006,1793003,1793097) then
                          My_Type.num_4:=v_Parm(7) ;                         
                       end if;
                       
                       
                         if My_Type.ID=185014 and v_bseq   in(1793013,1793014,1793015,1793017,1793019,1793020,1793021,1793022,1793018,1793023)
                          then
                          My_Type.num_1:=4 ;                         
                       end if;
                       
                 
                       --拆分缴费方（1、申请方；2、转让方）拆分后
                          If My_Type.key='3' Then My_Type.key:='1'; end if;
/*                          If My_Type.key='3' Then                          
                             My_Type.num_4:=0.5;
                             My_Type.key:='1';
                             Select t.agentname into My_Type.STR_4 From ta_agent t
                              Where t.aseq=(Select min(aseq) From ta_agent t2 Where t2.maintypeid=1 and t2.sseq=BU_SEQ)
                                and t.maintypeid=1 and t.sseq=BU_SEQ;
                             PIPE ROW (My_Type);
                             My_Type.key:='2';
                             Select t.agentname into My_Type.STR_4 From ta_agent t
                              Where t.aseq=(Select min(aseq) From ta_agent t2 Where t2.maintypeid=2 and t2.sseq=BU_SEQ)
                                and t.maintypeid=2 and t.sseq=BU_SEQ;                             
                             PIPE ROW (My_Type);
                          Else*/
                         --  Select count(*) into v_recs From ta_agent t
                       --     Where t.maintypeid=to_number(My_Type.KEY) and t.sseq=BU_SEQ;
                            
                          Select count(*) into v_recs   from (
              select 1 From ta_agent t Where t.maintypeid = to_number(My_Type.KEY) and t.sseq = BU_SEQ union
              select 1 From ta_mainbody t Where t.apptype = to_number(My_Type.KEY) and t.sseq = BU_SEQ ) ;
                           If v_recs=0 Then --是否填写了委托人
                              My_Type.STR_4:='　';
                           Else
                            /*Select wm_concat(t.agentname) into My_Type.STR_4 From 
                            
                            (
                            select agentname from 
                            ta_agent t
                             Where t.maintypeid=to_number(My_Type.KEY) and t.sseq=BU_SEQ 
                             order by ano 
                             ) t where rownum<4;*/
                             
      select to_char(wm_concat( agentname)) into My_Type.STR_4 from ( Select  agentname  From (select agentname
      from ta_agent t Where t.maintypeid = to_number(My_Type.KEY) and t.sseq = BU_SEQ order by ano) t 
      union Select  md_name   From (select md_name from ta_mainbody t Where t.apptype = to_number(My_Type.KEY) and t.sseq = BU_SEQ
             order by ano) t 
                       )     
                       
               where rownum < 4;                        
                             
                    
                           End if;
                             --PIPE ROW (My_Type);
                           --End if;
--                          End if;
                          
                          IsFound:=1;
                          --If My_Type.num_5=2 or My_Type.num_5=3 Then
                          --   v_Parm(My_Type.num_5):=-1;
                          --End if;
                       End if;
                    End loop;
                    If IsFound=0 Then 
                       --If My_Type.key='3' Then
                       --    My_Type.num_4:=0.5;
                           My_Type.key:='1';
                       --    PIPE ROW (My_Type);
                       --    My_Type.key:='2';                             
                       --    PIPE ROW (My_Type);
                       --Else
                         Select count(*) into v_recs   from (
              select 1 From ta_agent t Where t.maintypeid = to_number(My_Type.KEY) and t.sseq = BU_SEQ union
              select 1 From ta_mainbody t Where t.apptype = to_number(My_Type.KEY) and t.sseq = BU_SEQ ) ;
                                
                           If v_recs=0 Then --是否填写了委托人
                              My_Type.STR_4:='　';
                           Else                       
                              
       select to_char(wm_concat( agentname)) into My_Type.STR_4 from ( Select  agentname  From (select agentname
      from ta_agent t Where t.maintypeid =to_number(My_Type.KEY) and t.sseq = BU_SEQ order by ano) t 
      union Select  md_name   From (select md_name from ta_mainbody t Where t.apptype =to_number(My_Type.KEY) and t.sseq = BU_SEQ
             order by ano) t  )  where rownum < 4;                        
                             
                     --保障租金
                      
                               
                              --t.aseq=(Select min(aseq) From ta_agent t2 Where t2.maintypeid=to_number(My_Type.KEY) and t2.sseq=BU_SEQ)
--                                and t.maintypeid=1 and t.sseq=BU_SEQ;
                             --PIPE ROW (My_Type);
                           end if;
                       --End if;
                    End if;
                    Close Cur_Sel;
                End;                       
            End loop;
            Close cur_TItem;               
        End;
    End loop;
    Close cur;
  Return 1;
End CO_GET_FEEList_TEST;


/
