CREATE function cre_regdata(v_SdId in number) return clob is
  Result clob;
  v_tmp  varchar2(2000);
begin
  --v_tmp:='select sid 房屋编号,METNO 用户码,DDESC 行政区,LNAME 坐落,BNO 栋号,BDESC 房名,null 户号,lcout 层数,null 所在层,BSTRU 结构,BSTRUNAME 结构说明,BUSE 用途,HUSENAME 用途说明,null 房型,BAREA 建筑面积,PAREA 套内面积,GAREA 分摊面积,BPRIC 分摊系数,SAREA 阳台面积,BFETE 建成年代,co_convert_code(BKIND,null) 房屋性质,co_convert_code(BQUT,null) 建筑质量,DQ 东墙,NQ 南墙,XQ 西墙,BQ 北墙,MEMO 备注 From tu_bldg where sid='||v_SdId;

  v_tmp:='select t2.hid 房屋编号,t1.METNO 用户码,t1.DDESC 行政区,t1.LNAME 坐落,t1.BNO 栋号,t1.BDESC 房名,decode(t2.hno,t2.hdesc,t2.hno,t2.hno||''/''||t2.hdesc) 户号,t1.lcout 层数,t3.lno 所在层,co_convert_code(t2.BSTRU,null) 结构,t2.BSTRUNAME 结构说明,co_convert_code(huse,null) 用途,t2.HUSENAME 用途说明,co_convert_code(htype,null) 房型,t2.BAREA 建筑面积,t2.PAREA 套内面积,t2.GAREA 分摊面积,t2.BPRIC 分摊系数,t2.SAREA 阳台面积,t1.BFETE 建成年代,co_convert_code(t1.BKIND,null) 房屋性质,co_convert_code(t1.BQUT,null) 建筑质量,t2.DQ 东墙,t2.NQ 南墙,t2.XQ 西墙,t2.BQ 北墙,null 备注 From tu_bldg t1,tu_house t2,tu_layer t3 where t1.sid=t2.sid and t2.lid=t3.lid and t2.hid='||v_SdId;
  Result:=co_get_xml(v_tmp,'房屋信息','房屋');
  Result:=replace(Result,'<?xml version = ''1.0''?>','');

    Result:='<?xml version="1.0" encoding="UTF-8"?>'||chr(13)||'<SD_Info>'||Result||chr(13)||'</SD_Info>';
  return(Result);
end cre_regdata;


/
