CREATE function co_get_UserDept(v_useq in number,v_DeptLev varchar2) return varchar2 is
  Result varchar2(1024);
  v_no   number;
  v_name varchar2(60);

Begin
  Select distinct max(oname) into Result
                   From sv_organ Where otype=v_DeptLev 
                  Start with oseq=v_useq
                  Connect by nocycle prior sv_organ.OPARENT=sv_organ.OSEQ;
/*  Declare CURSOR cur_Org IS
                 Select distinct oseq,oname
                   From sv_organ Where otype=v_DeptLev 
                  Start with oseq=v_useq
                  Connect by nocycle prior sv_organ.OPARENT=sv_organ.OSEQ;
  Begin
     Open cur_Org;
     Loop
         Fetch cur_Org Into v_no,v_name;
         Exit When cur_Org%NotFound;
         If not Result is null Then Result:=Result||'/'; End if;
         Result:=Result||v_name;
     End loop;
     Close cur_Org;
  End;*/
  Return(Result);
  --Exception when others then return '未指定';
end co_get_UserDept;


/
