CREATE function CO_GET_INTEREST_ONE(intAccount in NUMBER,interest in number,strDate  in varchar2,buno in number) Return number
is
   recs integer;
   accountid NUMBER;
   vdate date;        --费用产生时间
   ddate date;        --上次派息时间
   v_ftype number;    --收支类别
   v_js number;       --每条明细的积数
   pdate date;        --派息日期
   s_js number;        --总积数
   v_lx number(15,4);  --利息
   v_je number(15,4);  --每笔明细金额
begin
  pdate:=to_date(strDate,'yyyy-mm-dd');
  s_js:=0;
  DECLARE
     CURSOR my_paixi IS
         select paccount,v_date,ddate,ftype,bamount  from taw_fee_bu  t where sseq=buno and t.paccount=intAccount and v_date<=pdate;
     BEGIN
        OPEN my_paixi;
        LOOP
           FETCH my_paixi INTO accountid,vdate,ddate,v_ftype,v_je;
           EXIT WHEN my_paixi%NOTFOUND;
              If (ddate is null) then
                 v_js:=trunc(pdate-vdate)*v_je*v_ftype;
              Else
                 v_js:=trunc(pdate-ddate)*v_je*v_ftype;
              End If;
              s_js:=s_js+v_js;
        END loop;
        CLOSE my_paixi;
     End;
     v_lx:=interest*s_js/360;
     return v_lx;
end CO_GET_INTEREST_ONE;
/
