CREATE function CO_get_MultiHid(v_hid in varchar2)
--取得合户租户号，单户的返回0
return varchar2 is
  Result varchar2(1000);
  v_sseq Number;
  v_int Number(2);
begin
  If length(trim(v_hid))=0 or v_hid is null Then
     return '0';
  End if;
  select nvl(u1.sseq,0) sseq into v_sseq from gf_bldg_house u1 where hid=v_hid;
  if(v_sseq>0) then
  select count(*) into v_int from gf_bldg_house where sseq=v_sseq;
  if v_int>1 then
  select to_char(wm_concat(hid)) into Result from gf_bldg_house where sseq=v_sseq;
  else
  Result:='0';
  end if;
  else
  Result:='0';
  end if;

  return(Result);
end CO_get_MultiHid;


/
