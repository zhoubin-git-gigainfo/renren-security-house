CREATE function GIS_GET_NEWFWYHM(strTF  in varchar2,strQiu in varchar2,strSeq in varchar2)
return varchar2 is
  Result varchar2(512);
  PRAGMA AUTONOMOUS_TRANSACTION; 
  n_qiu varchar2(100);
  i number;
  maxqiuid number;
  totalqiu number;
  newQiuID varchar2(10);
  newYhm varchar2(100);
begin
  Result:='';
  newYhm:='';
  newQiuID:='';
  i:=0;
  select max(fwn) into maxqiuid  from gis_fwinfo where TFN=strTF and qiun=strQiu;
  select count(*) into totalqiu from gis_fwinfo where TFN=strTF and qiun=strQiu;
  if (maxqiuid='000'||totalqiu) then
  begin
     --insert into GIS_QIUINFO(tfn,qiun) values('723030','006');
     newQiuID:=substr('000'||to_char(to_number(maxqiuid)+1),-4);
     newYhm:=strTF||strQiu||'000'||to_char(to_number(maxqiuid)+1);
     insert into gis_fwinfo(tfn,qiun,fwn,source) values(strTF,strQiu,newQiuID,strSeq);
     commit;

  end;
  else
  begin
  DECLARE
     CURSOR c_emp IS
          select fwn from  gis_fwinfo where TFN=strTF and qiun=strQiu order by fwn;
     BEGIN
        OPEN c_emp;
        LOOP
           FETCH c_emp INTO n_qiu;
           EXIT WHEN c_emp%NOTFOUND;
           i:=i+1;
           if (n_qiu<>'000'||to_char(i)) then
           begin
              newQiuID:=substr('000'||to_char(to_number(maxqiuid)+1),-4);
              newYhm:=strTF||strQiu||'000'||to_char(to_number(maxqiuid)+1);
              insert into gis_fwinfo(tfn,qiun,fwn,source) values(strTF,strQiu,newQiuID,strSeq);
              commit;
           end;
           End if;
        END loop;
        CLOSE c_emp;
     End;
  end;
  end if;
  Result:=newYhm;
  return(Result);
end GIS_GET_NEWFWYHM;


/
