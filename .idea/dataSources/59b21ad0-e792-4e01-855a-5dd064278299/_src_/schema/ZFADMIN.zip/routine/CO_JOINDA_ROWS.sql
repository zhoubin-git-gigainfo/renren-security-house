CREATE function CO_Joinda_Rows(Bu_No number,MinRows integer)
  RETURN co_table PIPELINED is
    --Return number is
    v_Rows   Integer;
    My_Type   co_basic;
    v_pages   integer;
Begin
    My_Type:=co_basic(0,null,null,null,null,null,null,null,null,null,null,null,null,null);
    Select count(*) into v_Rows From tu_dlist Where sseq=Bu_No;
    v_pages:=Ceil(v_Rows/MinRows);
    v_pages:=v_pages*MinRows-v_Rows;
    DECLARE CURSOR MyCur IS
            Select dno,dname,pages
              From tu_dlist  Where sseq=BU_No Order by dno;
    Begin
       Open MyCur;
       Loop
          fetch MyCur INTO My_Type.num_1,My_Type.str_1,My_Type.str_2;
          EXIT WHEN MyCur%NOTFOUND;
          pipe row(My_Type);
       End loop;
       Close MyCur;
    End;
    For i in 1 .. v_pages loop
          My_Type.num_1:=v_Rows+i;
          My_Type.str_1:=lpad(' ',i,' ');
          My_Type.str_2:=null;
          pipe row(My_Type);
    end loop;
    Return ;
End CO_Joinda_Rows;


/
