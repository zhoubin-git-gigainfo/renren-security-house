CREATE function CO_GET_FUNCTRANS(area in VARCHAR2,strclh in number,strcc in VARCHAR,inttag integer)
return VARCHAR2 is
   strtemp varchar2(4000);
   strtemp1 varchar2(4000);
   strone  varchar2(2000);
   strlayer  varchar2(20);
   strshouse varchar2(50);
   strehouse varchar2(50);
   strhousetemp varchar2(50);
   formatarea varchar2(4000);
   intfhlen integer;
   i integer;
begin
  i:=0;
  strtemp:=area;
  strone:=strtemp;
  strtemp1:=strtemp;
  strlayer:=to_char(to_number(strcc));
  intfhlen:=-co_get_fhlen(strclh);
  /*带层的头*/
  if (instr(strone,'@',1,1)>0) then
  begin
       strshouse:=substr(strone,instr(strone,'@',1,1)+1,length(strone)-instr(strone,'@',1,1)+1);
       /*strshouse:=substr('000'||strshouse,intfhlen);*/
       strtemp1:=strshouse;
       if instr(strshouse,'&',1,1)>0 then
       begin
         while instr(strtemp1,'&',1,1)>0
         loop
            strshouse:=substr(strtemp1,1,instr(strtemp1,'&',1,1)-1);
            strhousetemp:=strhousetemp||strlayer||substr('000'||strshouse,intfhlen)||'、';
            strtemp1:=substr(strtemp1,instr(strtemp1,'&',1,1)+1,length(strtemp1)-instr(strtemp1,'&',1,1));        
         end loop;
            strhousetemp:=strhousetemp||strlayer||substr('000'||strtemp1,intfhlen);  
       if (inttag=0) then
          formatarea:=strlayer||'层'||strhousetemp;
       else
          formatarea:=strlayer||'层'||strhousetemp||'--';
       end if;        
       end;
       else
       begin
       strshouse:=substr('000'||strshouse,intfhlen);
       if (inttag=0) then
          formatarea:=strlayer||'层'||strlayer||strshouse;
       else
          formatarea:=strlayer||'层'||strlayer||strshouse||'--';
       end if;       
       end;
       end if;
   end;
   else
   /*不带层的*/
   begin
     /*strlayer:=to_char(to_number(substr(strone,1,instr(strone,'@',1,1)-1)));*/
     strshouse:=strone;
     strtemp:=strone;
     if instr(strtemp,'&',1,1)>0 then
     begin
     while instr(strtemp,'&',1,1)>0
     loop
        strshouse:=substr(strtemp,1,instr(strtemp,'&',1,1)-1);
        formatarea:=formatarea||strlayer||substr('000'||strshouse,intfhlen)||'、';
        strtemp:=substr(strtemp,instr(strtemp,'&',1,1)+1,length(strtemp)-instr(strtemp,'&',1,1));        
     end loop;
        formatarea:=formatarea||strlayer||substr('000'||strtemp,intfhlen)||'、';
     end;
     else
     begin
        formatarea:=formatarea||strlayer||substr('000'||strtemp,intfhlen);
     end;
     end if;
   end;
     /*formatarea:=replace(formatarea,'&','、'||strlayer);*/
   end if;
  return formatarea;
end;


/
