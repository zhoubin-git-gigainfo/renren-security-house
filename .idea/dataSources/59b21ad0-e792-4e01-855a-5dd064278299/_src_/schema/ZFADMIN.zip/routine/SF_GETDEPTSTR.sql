CREATE function SF_GETDEPTSTR(OrgType in integer)
return varchar2 as

Begin
 If OrgType=1 Then Return '1'; End if;
 If OrgType=2 Then Return '1,2,3,5,6'; End if;
 If OrgType=3 Then Return '1,2,3,5,6,8'; End if;
 If OrgType=4 Then Return '1,2,3,4,5,6,8'; End if;
 If OrgType=5 Then Return '1,3,5'; End if;
 If OrgType=6 Then Return '1,3,5,6'; End if;
 If OrgType=8 Then Return '1,2,3,5,6,8'; End if;
 If OrgType=9 Then Return '1,2,3,4,5,6,8,9'; End if;
 Return '~';
End ;


/
