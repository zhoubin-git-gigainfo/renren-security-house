CREATE function CO_compareDateForRent(edate in varchar2,sdate in varchar2)
return int is
  Result integer;
  --0 在租 1 停租 2未起租

begin

  If length(trim(sdate))=0 or sdate is null Then
     return '-1';
  End if;
  If (to_date(nvl(edate,'2200-01-01'),'yyyy-mm-dd')-sysdate)>0 then
    if (to_date(sdate,'yyyy-mm-dd')-sysdate)>0 then
    Result:=2;
    else
    Result:=0;
    end if;

  else
  Result:=1;
  end if;
  return(Result);
end CO_compareDateForRent;


/
