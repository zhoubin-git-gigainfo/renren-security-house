CREATE function CO_GET_TAWFEE2(v_paccount in varchar2,V_TYPE in NUMBER)
return varchar2 is

  AMOUNT      NUMBER(15,3);

Begin
--1、初始化自定义类型
--3、获取用途组合名称和主用途编码
  --DECLARE
  ---
  ---1.初始额度
   IF(V_TYPE=1 ) THEN

 select distinct   sum(ftype*bamount) bamount into AMOUNT from to_state t1,to_relation t2,taw_fee t3 where
            t1.sid=t2.sid  and t2.mid=t3.paccount
            and t1.modality=0 and t1.f_date is null  and ptype=1 and t1.stype='64'
            and  t3.paccount = v_paccount;

END IF;

---2.余额
  IF(V_TYPE=2 ) THEN


 select distinct   sum(ftype*bamount) bamount into AMOUNT from to_state t1,to_relation t2,taw_fee t3 where
 t1.sid=t2.sid  and t2.mid=t3.paccount
             and t1.modality=0 and t1.f_date is null and t1.stype='64'
            and  t3.paccount = v_paccount;

END IF;

---3.利息
  IF(V_TYPE=3 ) THEN
select   sum(t2.bamount) into AMOUNT
           from taw_fee t2
          where t2.ptype = 4
            and  t2.paccount = v_paccount;
END IF;
--4.已使用
IF(V_TYPE=4 ) THEN
select   sum(t2.bamount) into AMOUNT
           from taw_fee t2
          where t2.Ftype = -1
            and  t2.paccount = v_paccount;
END IF;

  return(AMOUNT);
end CO_GET_TAWFEE2;


/
