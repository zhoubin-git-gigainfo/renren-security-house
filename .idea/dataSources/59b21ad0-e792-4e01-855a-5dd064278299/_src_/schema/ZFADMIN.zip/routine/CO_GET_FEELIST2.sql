CREATE function CO_GET_FEEList2(BU_SEQ in number)
RETURN --number
co_table PIPELINED
IS
    My_Type        co_basic;
    v_Parm         dbms_sql.Number_Table ;
    v_BSEQ         number(12);
    v_BuType       Integer;
    IsFound        integer;
    IsLeaf         integer;
    type rc is ref cursor;
    cur    rc;
    l_Sql    varchar2(6000);

    --计费标准
    p_MoreUse     Integer default -1 ;--(1=多用途；0=单用途）
    p_UseType     Integer default -1 ;--(1=住宅；0=非住宅）
    p_DroitType   Integer default -1 ;--(1=私产；0=其他）
    p_RealType    Integer default -1 ;--(1=新建商品房；2=存量房；3=房改房；4=经济适用房；5=双限房）
    p_AreaSegm    integer default -1 ;--(1=0~200平；2=200~500平；3=500~1000平;4=1000~)
    p_GageSegm    Integer default -1 ;--(1=0~2K万；2=2~5K万；3=2.5~5K万;4=10K万~)
    p_Corps       Integer default -1 ;--(1=普通住宅；0=其他住宅）

    vp_User       char(2);


Begin
    My_Type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    --key=缴费方（1=申请方；2=转让方）
    --
    Select a.bseq,b.apptype into v_BSEQ,v_BuType from sv_bulists a,appdefine b Where a.sseq=BU_SEQ and a.bseq=b.bseq;
--一、计费依据
    v_Parm(1):=1;--缺省（业务数）
    v_Parm(2):=0;--确定价值
    v_Parm(3):=0;--贷款额
    v_Parm(4):=0;--客体数
    v_Parm(5):=0;--面积
    v_Parm(6):=1;
    v_Parm(7):=1;--发证数

    If v_BuType=2 or v_BuType=5 Then   --测量收费
        Select Decode(count(distinct useid),1,'U1','U2') into vp_User from ta_hxx where sseq=BU_SEQ;
        l_Sql:='Select Decode(Count(distinct b.useid),1,0,1) Is_MoreUse,';
        l_Sql:=l_Sql||'Decode(Instr(co_get_codepath(min(b.useid)),''/110''),0,0,1) is_usetype,';
        l_Sql:=l_Sql||'0 Is_Corps,max(to_number(a.zjzmj)) barea,Count(distinct c.cc) Icount,0';
        l_Sql:=l_Sql||' From ta_zxx a,ta_hxx b,ta_cxx c';
        l_Sql:=l_Sql||' Where a.sseq='||to_char(BU_SEQ)||' and a.sseq=b.sseq and a.sseq=c.sseq';
    End if;

    If v_BuType=6 Then   --档案收费
        Select decode(cb_type,230,1,0) into p_DroitType From ta_qarchives Where sseq=BU_SEQ;
        l_Sql:='Select 0,0,0,0,1,1 From ta_qarchives Where sseq='||to_char(BU_SEQ);
    End if;

    If v_BuType=4 Then   --登记收费
        Select cardcount-1 into v_Parm(7) From taq_enrol Where sseq=BU_SEQ;
        Select sum(nvl(pawnmoney,0)) Into v_Parm(3) From taq_enrol Where sseq=BU_SEQ;--贷款额
        Select sum(nvl(pprice,0)) Into v_Parm(2) From taq_sdlist Where sseq=BU_SEQ;  --确认价

        l_Sql:='Select 0,Decode(Instr(co_get_codepath(b.huse),''/''||''110''),0,0,1),';
        l_Sql:=l_Sql||'case when a.barea<144 Or a.parea<120 then 1 else 0 end Is_Corps,';
        l_Sql:=l_Sql||'sum(a.barea) Barea,sum(1) ICount,max(decode(c.protype,230,1,0)) ';
        l_Sql:=l_Sql||'From taq_sdlist a,tu_house b,taq_enrol c ';
        l_Sql:=l_Sql||'Where a.sseq='||to_char(BU_SEQ)||' and (a.sd_id=b.hid or a.sd_id=b.sid or a.sd_id=b.lid) and c.sseq=a.sseq ';
        l_Sql:=l_Sql||'Group by 0,Decode(Instr(co_get_codepath(b.huse),''/''||''110''),0,0,1),';
        l_Sql:=l_Sql||'case when a.barea<144 Or a.parea<120 then 1 else 0 end';

    End if;

    Open cur for l_Sql ;
    --返回结果按顺序为：是否多用途；是否住宅；是否普通住宅；面积；客体数
    Loop

        Fetch cur into p_MoreUse,p_UseType,p_Corps,v_Parm(5),v_Parm(4),p_DroitType;
        Exit when cur%notfound;

        --面积分段
        If v_Parm(5)<=200 Then p_AreaSegm:=1; End if;
        If v_Parm(5)>200 and v_Parm(5)<=500 Then p_AreaSegm:=2; End if;
        If v_Parm(5)>500 and v_Parm(5)<=1000 Then p_AreaSegm:=3; End if;
        If v_Parm(5)>1000 Then p_AreaSegm:=4; End if;

        --贷款额分段
        If v_Parm(3)<=20000000 Then p_GageSegm:=1; End if;
        If v_Parm(3)>20000000 and v_Parm(3)<=25000000 Then p_GageSegm:=2; End if;
        If v_Parm(3)>25000000 and v_Parm(3)<=100000000 Then p_GageSegm:=3; End if;

        Declare CURSOR cur_TItem IS
                        Select b.cid From ts_tariff a,ts_titem b
                         Where a.bseq=v_BSEQ and a.iid=b.cid Order by b.cid;
        Begin
            Open cur_TItem;
            Loop
               Fetch cur_TItem Into My_Type.ID;
               Exit When cur_TItem%NotFound;
               IsFound:=0;
               Declare CURSOR Cur_Sel IS
                        Select mod_tax,ver_val,mod_bas,bas_val,icode,udesc,connect_by_isleaf,
                               ltrim(sys_connect_by_path(ver_name,'/'),'/'),
                               ltrim(sys_connect_by_path('{'||substr(ver_mod,1,instr(ver_mod,',')-1)||'}','='),'='),
                               ltrim(sys_connect_by_path('{'||substr(ver_mod,instr(ver_mod,',')+1)||'}','='),'=')
                          from ts_price start with ver_id=My_Type.ID connect by nocycle prior ver_id = parentid;
                Begin
                    Open Cur_Sel;
                    Loop
                       Fetch Cur_Sel Into My_Type.key,My_Type.num_1,My_Type.num_5,My_Type.num_3,My_Type.STR_2,My_Type.STR_3,IsLeaf,My_Type.STR_1,My_Type.STR_4,My_Type.STR_5;
                       Exit When Cur_Sel%NotFound;
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_DroitType',to_char(p_DroitType));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_MoreUse',to_char(p_MoreUse));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_UseType',to_char(p_UseType));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_RealType',to_char(p_RealType));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_AreaSegm',to_char(p_AreaSegm));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_GageSegm',to_char(p_GageSegm));
                       My_Type.STR_4:=replace(My_Type.STR_4,'p_Corps',to_char(p_Corps));
                       My_Type.num_4:=1;
                       If My_Type.STR_4=My_Type.STR_5 and IsLeaf=1 and v_Parm(My_Type.num_5)>=0 Then
                          My_Type.num_2:=v_Parm(My_Type.num_5);

                       --拆分缴费方（1、申请方；2、转让方）拆分后
                          If My_Type.key='3' Then
                             My_Type.num_4:=0.5;
                             My_Type.key:='1';
                             PIPE ROW (My_Type);
                             My_Type.key:='2';
                             PIPE ROW (My_Type);
                          Else
                             PIPE ROW (My_Type);
                          End if;
                          IsFound:=1;
                          If My_Type.num_5=2 or My_Type.num_5=3 Then
                             v_Parm(My_Type.num_5):=-1;
                          End if;
                       End if;
                    End loop;
                    If IsFound=0 Then
                       If My_Type.key='3' Then
                           My_Type.num_4:=0.5;
                           My_Type.key:='1';
                           PIPE ROW (My_Type);
                           My_Type.key:='2';
                           PIPE ROW (My_Type);
                       Else
                           PIPE ROW (My_Type);
                       End if;
                    End if;
                    Close Cur_Sel;
                End;
            End loop;
            Close cur_TItem;
        End;
    End loop;
    Close cur;
  Return  ;
End CO_GET_FEEList2;


/
