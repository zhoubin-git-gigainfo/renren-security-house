CREATE function   getchinesenum( p_input   number)   return   varchar2   as
      rv           varchar2(4000);
      tmpstr   varchar(4000);
      m             varchar(4000);
      k             varchar(4000);
      i             numeric(38,   2);
      j             int;
      lastj     int;
      lastv     varchar(10);
      lastf     varchar(10);
      laste     varchar(10);
      lastve   varchar(10);
  begin

      return   rv;
  end   getchinesenum;


/
