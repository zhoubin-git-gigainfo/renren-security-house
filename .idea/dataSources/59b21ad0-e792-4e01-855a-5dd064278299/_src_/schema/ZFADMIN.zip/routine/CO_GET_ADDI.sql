CREATE function co_get_Addi(vSdId in number,dvdate in varchar2,dfdate in varchar2)
  return varchar2 is
  Result varchar2(6000);
  v_tmp  varchar2(20);
  v_recs integer;
begin
  If dvdate is null Then
  begin
     Result:='Select 0 No,''建筑区划内'' 类别,idesc 名称,gdesc 部位,iexte 面积大小,icut 数量,to_char(v_date,''yyyy-mm-dd'') 生效时间,to_char(f_date,''yyyy-mm-dd'') 失效时间 from tu_addi where f_date is null and sid=#PROJ_ID#';
     Result:=Result||' union select 0,''建筑区划内'',co_convert_code(sattribute,null),lname||hno,to_char(b.barea),1,to_char(a.v_date,''yyyy-mm-dd''),to_char(a.f_date,''yyyy-mm-dd'') from to_state a,tu_house b,tu_bldg c,tu_pbldg d where a.sid=b.hid and b.sid=c.sid and c.sid=d.sid and a.stype=''91'' and a.f_date is null and d.pid=#PROJ_ID#';
     Result:=Result||' union select 1,''栋内共有'' atype,idesc,gdesc,iexte,icut,to_char(v_date,''yyyy-mm-dd'') 生效时间,to_char(f_date,''yyyy-mm-dd'') 失效时间 from tu_addi where f_date is null and  sid=#BLDG_ID#';
  end;
  Else
  begin
     Result:='Select 0 No,''建筑区划内'' 类别,idesc 名称,gdesc 部位,iexte 面积大小,icut 数量,to_char(v_date,''yyyy-mm-dd'') 生效时间,to_char(f_date,''yyyy-mm-dd'') 失效时间 from tu_addi where v_date<=to_date('''||dvdate||''',''yyyyMMddHH24miss'') and  sid=#PROJ_ID#';
     Result:=Result||' union select 0,''建筑区划内'',co_convert_code(sattribute,null),lname||hno,to_char(b.barea),1,to_char(a.v_date,''yyyy-mm-dd''),to_char(a.f_date,''yyyy-mm-dd'') from to_state a,tuh_house b,tu_bldg c,tu_pbldg d where a.sid=b.hid and b.sid=c.sid and c.sid=d.sid and a.stype=''91'' and a.v_date<b.f_date and b.f_date=to_date('''||dfdate||''',''yyyyMMddHH24miss'') and d.pid=#PROJ_ID#';
     Result:=Result||' union select 1,''栋内共有'' atype,idesc,gdesc,iexte,icut,to_char(v_date,''yyyy-mm-dd'') 生效时间,to_char(f_date,''yyyy-mm-dd'') 失效时间 from tu_addi where v_date<=to_date('''||dvdate||''',''yyyyMMddHH24miss'') and sid=#BLDG_ID#';
  end;
  End if;
  Select count(*) into v_recs From tu_pbldg
       Where tu_pbldg.sid=(Select max(parentid) From sv_reals where oseq=vSdId or PARENTID=vSdId);
  If v_recs=0 Then
     v_tmp:='-9876512345'; --房屋没有属于一个项目
  Else
     Select to_char(max(nvl(pid,0))) into v_tmp From tu_pbldg
      Where tu_pbldg.sid=(Select max(parentid) From sv_reals where oseq=vSdId or PARENTID=vSdId);
  End if;
  Result:=replace(Result,'#PROJ_ID#',v_tmp);
  Select count(*) into v_recs From sv_reals where oseq=vSdId or PARENTID=vSdId;
  If v_recs=0 Then
     v_tmp:='0';
  Else
     Select max(parentid) into v_tmp From sv_reals where oseq=vSdId or PARENTID=vSdId;
  End if;
  Result:=replace(Result,'#BLDG_ID#',v_tmp);
  Return(Result);
end co_get_Addi ;


/
