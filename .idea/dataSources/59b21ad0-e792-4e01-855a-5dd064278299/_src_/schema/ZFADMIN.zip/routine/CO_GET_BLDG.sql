CREATE function co_get_Bldg(Result in varchar2) Return varchar2 is
  v_tmp  number;
begin
  If Result is null Then Return '找不到数据！！！';end if;
  v_tmp:=to_number(substr(nvl(Result,'0'),1,4));
  return(Result);
  Exception when others then 
  return('%'||Result||'%');
end co_get_Bldg;


/
