CREATE function CO_Get_SDINFO(SD_ID number,SD_Type number)
 RETURN clob
/*建立房屋客体的全文索引数据
   当房屋的自然状况（测量成果提交），业务办结影响到状态、关系变化启动。
   参数：SD_ID—房屋对象的id
         SSD_Type—房屋对象类型（1=栋，2=户）
*/
is
  vd_xml   clob;
  v_Tag    varchar2(20);
  l_Sql    varchar2(6000);
  
Begin
   If SD_Type=1 Then
      l_Sql:='Select Distinct ''ID''||to_char(SID) 编号,metno 用户码,ddesc 区,lname 坐落,bdesc 栋名,bstru 结构,buse 用途,lcout 层数,bfete 建设年代 From tuh_bldg Where sid=#SD_ID#';
      v_Tag:='栋';
   End if;
   If SD_Type=4 Then
      l_Sql:='Select Distinct ''ID''||to_char(Hid) 编号,b.metno 用户码,ddesc 区,lname 坐落,bdesc 栋名,Decode(hno,hdesc,hno,hno||''/''||hdesc) 房号,co_convert_code(a.bstru,null) 结构,co_convert_code(a.huse,null) 用途,lcout 层数,c.lno 层次,bfete 建设年代  From tuh_house a,tuh_bldg b,tuh_layer c where a.hid=#SD_ID# and a.sid=b.sid and a.v_date=b.v_date and a.lid=c.lid and a.v_date=c.v_date';
      v_Tag:='户';      
   End if;
   
   l_sql:=Replace(l_Sql,'#SD_ID#',to_char(nvl(SD_ID,0)));
   vd_xml:=co_get_xml(l_Sql,'房屋',v_Tag);

/*
--2、建立房屋对象—栋XML信息
Select From 
   Select vd_xml||'<房屋>'||chr(13)||
          '<编号>'||'ID'||to_char(SD_ID)||'</编号>'||chr(13)||
          '<用户码>'||co_get_strlists('sid',vd_id,'metno','tuh_bldg','')||'</用户码>'||chr(13)||
          '<区>'||co_get_strlists('sid',vd_id,'ddesc','tuh_bldg','')||'</区>'||chr(13)||
          '<坐落>'||co_get_strlists('sid',vd_id,'lname','tuh_bldg','')||'</坐落>'||chr(13)||
          '<栋名>'||co_get_strlists('sid',vd_id,'bdesc','tuh_bldg','')||'</栋名>'||chr(13)||
          '<状态>'||Decode(co_get_strlists('sid',vd_id,'BSTATE','tu_bldg',''),'11','期房','12','现房','13','待拆','14','灭失','')||'</状态>'||chr(13)||
          Decode(SD_Type,2,'<户名>'||co_get_strlists('hid',vh_id,'Decode(hno,hdesc,hno,hno||''/''||hdesc)','tuh_house','')||'</户名>'||chr(13),'')||          
          '<结构>'||co_get_strlists('sid',vd_id,'bstru','tuh_bldg','')||'</结构>'||chr(13)||
          '<用途>'||co_get_strlists('sid',vd_id,'buse','tuh_bldg','')||'</用途>'||chr(13)||
          '<层数>'||co_get_strlists('sid',vd_id,'to_char(lcout)','tu_bldg','')||'</层数>'||chr(13)||
          '<建设年代>'||co_get_strlists('sid',vd_id,'to_char(bfete)','tu_bldg','')||'</建设年代>'||chr(13)||
--          '<建筑面积>'||co_get_strlists('sid',vd_id,'to_char(barea)','tu_bldg','')||'</建筑面积>'||chr(13)||
--          '<专有面积>'||co_get_strlists('sid',vd_id,'to_char(parea)','tu_bldg','')||'</专有面积>'||chr(13)||
--          '<层>'||co_get_strlists('sid',vd_id,'ldesc||''层''','tuh_layer','')||'</层>'||chr(13)||
--          '<户>'||co_get_strlists('sid',vd_id,'Decode(hno,hdesc,hno,hno||''/''||hdesc)','tuh_house','')||'</户>'||chr(13)||
          '</房屋>'||chr(13)||'<宗地>'||chr(13)||
          '<地号>'||co_get_strlists('sid',vd_id,'pno','tuh_bldg,tu_plot','tuh_bldg.plotid=tu_plot.plotid(+)')||'</地号>'||chr(13)||
          '<证号>'||co_get_strlists('sid',vd_id,'pcardno','tuh_bldg,tu_plot','tuh_bldg.plotid=tu_plot.plotid(+)')||'</证号>'||chr(13)||
          '<用途>'||co_get_strlists('sid',vd_id,'co_convert_code(PUID,'''')','tuh_bldg,tu_plot','tuh_bldg.plotid=tu_plot.plotid(+)')||'</用途>'||chr(13)||
          '<取得方式>'||co_get_strlists('sid',vd_id,'co_convert_code(PYID,'''')','tuh_bldg,tu_plot','tuh_bldg.plotid=tu_plot.plotid(+)')||'</取得方式>'||chr(13)||
          '<使用年限>'||co_get_strlists('sid',vd_id,'to_char(UYEAR)','tuh_bldg,tu_plot','tuh_bldg.plotid=tu_plot.plotid(+)')||'</使用年限>'||chr(13)||
          '</宗地>'||chr(13)||'</房屋属性>' 
          into vd_xml
     From dual;
*/
   Return (vd_xml);
End CO_get_SDINFO;



/
