CREATE function co_get_ParentObj (vSdId in number)
  return varchar2 is
  Result varchar2(6000);
  v_tmp  varchar2(20);
begin
  Result:='Select 0 No,''建筑区划内'' 类别,idesc 名称,gdesc 部位,iexte 面积大小,icut 数量 from tu_addi where sid=#PROJ_ID#';
  Result:=Result||' union Select 0,''建筑区划内'',co_convert_code(sattribute,null),lname||oname,to_char(barea),1 From sv_reals t1,tu_pbldg t2 Where sattribute=145001 and t1.PARENTID=t2.sid and t2.pid=#PROJ_ID#';
  Result:=Result||' union select 1,''栋内共有'' atype,idesc,gdesc,iexte,icut from tu_addi where sid=#BLDG_ID#';
  Select to_char(max(nvl(pid,0))) into v_tmp From tu_pbldg 
       Where tu_pbldg.sid=(Select parentid From sv_reals where oseq=vSdId or PARENTID=vSdId);
  Result:=replace(Result,'#PROJ_ID#',v_tmp);
  Select parentid into v_tmp From sv_reals where oseq=vSdId or PARENTID=vSdId;
  Result:=replace(Result,'#BLDG_ID#',v_tmp);
  return(Result);
end co_get_ParentObj ;


/
