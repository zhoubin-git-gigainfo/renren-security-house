CREATE function co_get_repeat(v_char in varchar2, v_num number) return varchar2 is
  Result varchar2(1000);
begin
  For x in 1..v_num loop
      Result:=Result||v_char;
  End loop;
  return(Result);
end co_get_repeat;


/
