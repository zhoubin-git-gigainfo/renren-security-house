CREATE function getVerify_ISO7064(idcard in varchar2) return varchar
as
type vi_TYPE is varray(11) of varchar2(1);
vi vi_TYPE := vi_TYPE('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
v_num number;
v_sum number;
begin
if idcard is null then return null ; end if;
v_sum := 0;
v_num := length(idcard);
for i in 1 .. v_num loop
v_sum := v_sum + (power(2,v_num -i+1) mod 11 ) * to_number(substr(idcard,i,1));
-- DBMS_OUTPUT.PUT_LINE(v_sum);
end loop;
v_sum := v_sum mod 11;
return vi(v_sum+1);
end getVerify_ISO7064;


/
