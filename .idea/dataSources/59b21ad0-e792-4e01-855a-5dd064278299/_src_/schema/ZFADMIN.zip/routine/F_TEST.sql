CREATE function f_test
return co_table pipelined
is
begin
  declare
  my_type co_basic;
  
  cursor my_cur is 
  select bname from appdefine where rownum<20;
  
  begin
      my_type:=co_basic(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
      
      open my_cur;
           loop 
               fetch my_cur into my_type.STR_1;
               exit when my_cur%notfound;
               my_type.NUM_1 := 123456;
               pipe row(my_type);
           end loop;
      close my_cur;
    return;
  end;
end f_test;
/
