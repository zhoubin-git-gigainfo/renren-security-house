CREATE function Isnumber(P_column in varchar2) return number
  is
  l_t number;
 begin
   l_t := to_number(P_column);
       return 1;
  exception when others then
       return 0;
  end;


/
